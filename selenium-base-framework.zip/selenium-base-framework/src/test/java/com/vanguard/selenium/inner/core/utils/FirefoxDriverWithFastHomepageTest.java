/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/FirefoxDriverWithFastHomepageTest.java $
 $LastChangedRevision: 5706 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-14 15:51:31 -0400 (Fri, 14 Jul 2017) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.SystemUtils;
import org.junit.Test;
import org.openqa.selenium.firefox.FirefoxDriver;


public class FirefoxDriverWithFastHomepageTest {

	FirefoxDriverWithFastHomepage firefoxDriverWithFastHomepage = new FirefoxDriverWithFastHomepage();

	@Test
	public void getDriver() throws IOException {
		if ( SystemUtils.IS_OS_WINDOWS ) {
			String originalConfigFile = FileUtils.readFileToString(FirefoxDriverWithFastHomepage.CONFIG_FILE);
			System.setProperty("webdriver.gecko.driver","C:\\Program Files\\Mozilla Firefox\\GeckoDriver\\geckodriver.exe");
			FirefoxDriver driver = FirefoxDriverWithFastHomepage.getFirefoxDriverWithFasterHomepage();

			assertConfigFileUnchanged(originalConfigFile);
			assertEquals("about:blank", driver.getCurrentUrl());

			driver.quit();
		}
	}

	private void assertConfigFileUnchanged(String originalConfigFile) throws IOException {
		assertEquals(originalConfigFile, FileUtils.readFileToString(FirefoxDriverWithFastHomepage.CONFIG_FILE));
	}

}
