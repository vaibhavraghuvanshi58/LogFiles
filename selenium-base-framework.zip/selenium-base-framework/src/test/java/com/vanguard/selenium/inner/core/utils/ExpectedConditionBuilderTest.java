/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/ExpectedConditionBuilderTest.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

import com.vanguard.selenium.inner.core.seleniummockbuilders.WebDriverMockBuilder;
import com.vanguard.selenium.inner.core.seleniummockbuilders.WebElementMockBuilder;
import com.vanguard.selenium.inner.core.utils.ExpectedConditionBuilder;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;

/**
 * @author utcl
 *
 */
public class ExpectedConditionBuilderTest {

    /**
     * 
     */
    private static final String ANY_ID = "anyId";
    private WebDriverMockBuilder<RemoteWebDriver> mockDriverBuilder = new WebDriverMockBuilder<RemoteWebDriver>(RemoteWebDriver.class);
    private WebDriver mockDriver;
    private ExpectedConditionBuilder conditionBuilder;

    @Before
    public void setup() {
        mockDriverBuilder = new WebDriverMockBuilder<RemoteWebDriver>(RemoteWebDriver.class);
        mockDriver = mockDriverBuilder.getMock();
        conditionBuilder = new ExpectedConditionBuilder();
    }

    @Test
    public void givenElementIsNotEnabledWhenApplyingBuiltConditionReturnFalse() throws Exception {
        final String anyElementId = ANY_ID;
        mockDriverBuilder.findElement(By.id(anyElementId)).andReturnBuilder().isEnabled().andThrow(new StaleElementReferenceException(""));
        mockDriverBuilder.buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForElementDisplay(anyElementId, mockDriver);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenElementIsEnabledWhenApplyingBuiltConditionReturnTrue() throws Exception {
        final String anyElementId = ANY_ID;
        mockDriverBuilder.findElement(By.id(anyElementId)).andReturnBuilder().isEnabled().andReturn(true);
        mockDriverBuilder.buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForElementDisplay(anyElementId, mockDriver);

        assertEquals(true, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenAjaxIsRunningWhenApplyingConditionThenReturnFalse() throws Exception {
        mockDriverBuilder.executeScript(ExpectedConditionBuilder.CBD_AJAX_PROGRESS_JS).andReturn(new Boolean(true)).buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForAjaxWait(mockDriver);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenAjaxIsCompletedWhenApplyingConditionThenReturnTrue() throws Exception {
        mockDriverBuilder.executeScript(ExpectedConditionBuilder.CBD_AJAX_PROGRESS_JS).andReturn(new Boolean(false)).buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForAjaxWait(mockDriver);

        assertEquals(true, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenAjaxCheckReturnsNullWhenApplyingConditionThenReturnFalse() throws Exception {
        mockDriverBuilder.executeScript(ExpectedConditionBuilder.CBD_AJAX_PROGRESS_JS).andReturn(null).buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForAjaxWait(mockDriver);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenAjaxCheckReturnsObjectOtherThanBooleanWhenApplyingConditionThenReturnFalse() throws Exception {
        mockDriverBuilder.executeScript(ExpectedConditionBuilder.CBD_AJAX_PROGRESS_JS).andReturn(new Object()).buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForAjaxWait(mockDriver);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenAjaxCheckThrowsExceptionWhenApplyingConditionThenReturnFalse() throws Exception {
        final IllegalArgumentException anyException = new IllegalArgumentException();
        mockDriverBuilder.executeScript(ExpectedConditionBuilder.CBD_AJAX_PROGRESS_JS).andThrow(anyException).buildMockTree();

        final ExpectedCondition<Boolean> expectedCondition = SeleniumWaitHelper.buildExpectedConditionForAjaxWait(mockDriver);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenElementIsDisplayedWhenApplyingConditionThenReturnTrue() throws Exception {
        final WebElementMockBuilder elementMockBuilder = new WebElementMockBuilder(WebElement.class);
        elementMockBuilder.isDisplayed(true);
        final ExpectedCondition<Boolean> expectedCondition = conditionBuilder.buildElementDisplayedCondition(elementMockBuilder.buildMockTree());

        assertEquals(true, expectedCondition.apply(mockDriverBuilder.buildMockTree()));
    }

    @Test
    public void givenElementIsNotDisplayedWhenApplyingConditionThenReturnFalse() throws Exception {
        final WebElementMockBuilder elementMockBuilder = new WebElementMockBuilder(WebElement.class);
        elementMockBuilder.isDisplayed(false);
        final ExpectedCondition<Boolean> expectedCondition = conditionBuilder.buildElementDisplayedCondition(elementMockBuilder.buildMockTree());

        assertEquals(false, expectedCondition.apply(mockDriverBuilder.buildMockTree()));
    }

    @Test
    public void givenElementIsNotDisplayedWhenApplyingIsDisplayedConditionThenReturnFalse() throws Exception {
        mockDriverBuilder.findElement(By.id(ANY_ID)).andReturnBuilder().isDisplayed(false).buildMockTree();

        ExpectedCondition<Boolean> expectedCondition = conditionBuilder.buildIsDisplayedConditionById(mockDriver, ANY_ID);

        assertEquals(false, expectedCondition.apply(mockDriver));
    }

    @Test
    public void givenElementIsDisplayedWhenApplyingIsDisplayedConditionThenReturnTrue() throws Exception {
        mockDriverBuilder.findElement(By.id(ANY_ID)).andReturnBuilder().isDisplayed(true).buildMockTree();

        ExpectedCondition<Boolean> expectedCondition = conditionBuilder.buildIsDisplayedConditionById(mockDriver, ANY_ID);

        assertEquals(true, expectedCondition.apply(mockDriver));
    }
}
