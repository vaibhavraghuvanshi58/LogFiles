/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/PropertiesManagerTest.java $
 $LastChangedRevision: 3343 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 17:46:14 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.base;


import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PropertiesManagerTest {

    PropertiesManager propertiesManager;
    
    //Property Names
    String REGION = "region";
    String BASE_UNIX_INTERNAL = "baseUnixInternalUrl";
    String E_ONLY_PROP = "EonlyProp";
    String F_ONLY_PROP = "FonlyProp";
    String DB_TABLE_NAME = "DBTableName";
    
    //Default Values from .properties files in src/test/resources
    String DEFAULT_REGION_VALUE_E = "E";
    String F_REGION_VALUE = "F";
    String DEFAULT_E_INTERNAL_URL_VALUE = "http://devoedesktop.vanguard.com:9443";
    String DEFAULT_F_INTERNAL_URL_VALUE = "http://satoedesktop.vanguard.com:9443";
    String DEFAULT_E_ONLY_PROP_VALUE = "Evalue";
    String DEFAULT_F_ONLY_PROP_VALUE = "Fvalue";
    String DEFAULT_DB_TABLE_NAME_VALUE = "unknownTable";
    String E_DB_TABLE_NAME_VALUE = "\"ETable\"";
    
    //Values from Override files created in this class
    String E_Override_Expected_URL = "http://e.region.overide/url";
    String F_Override_Expected_URL = "http://f.region.overide/url";
    String E_ONLY_PROP_OVERRIDE_VALUE = "EOnlyOverride";
    String F_ONLY_PROP_OVERRIDE_VALUE = "FOnlyOverride";

    
    @Before
    public void setup() {
        simulateRemovingAnyRegressionConfigFilesThatMightExist();
        propertiesManager = new PropertiesManager();
        reInitializeProperties();
    }


    @Test
    public void givenNoOverridesValidatePropertyValuesFromSrcTestResourcesFilesTest() {
        Assert.assertEquals(DEFAULT_REGION_VALUE_E, PropertiesManager.getProperty(REGION));
        Assert.assertEquals(DEFAULT_E_INTERNAL_URL_VALUE, PropertiesManager.getProperty(BASE_UNIX_INTERNAL));
    }

    @Test
    public void setPropertyTest() {
        Assert.assertEquals(DEFAULT_REGION_VALUE_E, PropertiesManager.getProperty(REGION));
        PropertiesManager.setProperty(REGION, F_REGION_VALUE, RegionProperties.DEFAULT, PropertiesManager.BASE_DIRECTORY);
        Assert.assertEquals(F_REGION_VALUE, PropertiesManager.getProperty(REGION));
    }
    
    @Test
    public void givenWeChangeTheRegionWeWillAlsoChangeTheURLtoUseTest() {
        changeResourceFileRegionProperty(F_REGION_VALUE, RegionProperties.DEFAULT);
        Assert.assertEquals(DEFAULT_F_INTERNAL_URL_VALUE, PropertiesManager.getProperty(BASE_UNIX_INTERNAL));
    }
    
    @Test
    public void givenNoChangeToTheRegionWeWillOnlyLoadERegionPropsTest() {
        Assert.assertEquals(DEFAULT_E_ONLY_PROP_VALUE, PropertiesManager.getProperty(E_ONLY_PROP));
        Assert.assertEquals(null, PropertiesManager.getProperty(F_ONLY_PROP));
        Assert.assertEquals(null, PropertiesManager.getProperty(F_ONLY_PROP, RegionProperties.F));
    }
    
    @Test
    public void ensureWeLookAtRegionBeforeDefaultsFileTest() {
        Assert.assertNotEquals(DEFAULT_DB_TABLE_NAME_VALUE, PropertiesManager.getProperty(DB_TABLE_NAME));
        Assert.assertEquals(E_DB_TABLE_NAME_VALUE, PropertiesManager.getProperty(DB_TABLE_NAME));
    }
    
    @Test
    public void givenWeChangeTheRegionToFWeWillOnlyLoadFRegionPropsTest() {
        changeResourceFileRegionProperty(F_REGION_VALUE, RegionProperties.DEFAULT);
        Assert.assertEquals(null, PropertiesManager.getProperty(E_ONLY_PROP));
        Assert.assertEquals(null, PropertiesManager.getProperty(E_ONLY_PROP, RegionProperties.E));
        Assert.assertEquals(DEFAULT_F_ONLY_PROP_VALUE, PropertiesManager.getProperty(F_ONLY_PROP));
    }
    
    @Test
    public void givenRegressionOverridesValidateRegionValueTest() {
        simulateloadingDefaultOverrideFileRegionEqualsF();
        
        Assert.assertEquals(F_REGION_VALUE, PropertiesManager.getProperty(REGION));
        Assert.assertEquals(F_Override_Expected_URL, PropertiesManager.getProperty(BASE_UNIX_INTERNAL));
        Assert.assertEquals(F_ONLY_PROP_OVERRIDE_VALUE, PropertiesManager.getProperty(F_ONLY_PROP));
        Assert.assertEquals(null, PropertiesManager.getProperty(E_ONLY_PROP));
    }
    
    @Test
    public void givenWeChangeToFRegionDefaultButRegressionOverrideToERegionValidateRegionValueTest() {
        changeResourceFileRegionProperty(F_REGION_VALUE, RegionProperties.DEFAULT);
        simulateloadingDefaultOverrideFileRegionEqualsE();
        
        Assert.assertEquals(DEFAULT_REGION_VALUE_E, PropertiesManager.getProperty(REGION));
        Assert.assertEquals(E_Override_Expected_URL, PropertiesManager.getProperty(BASE_UNIX_INTERNAL));
        Assert.assertEquals(E_ONLY_PROP_OVERRIDE_VALUE, PropertiesManager.getProperty(E_ONLY_PROP));
        Assert.assertEquals(null, PropertiesManager.getProperty(F_ONLY_PROP));
    }
    
    @Test
    public void parseJenkinsTestPropertiesIntoSystemPropertyValues_MultiValueTest() {
        System.setProperty(PropertiesManager.JENKINS_STRING_PARAM_TEST_PROPERTIES_KEY, "grid=www.grid.com;myID=someIDvalue;region=F");
        Assert.assertTrue("System property should not be set yet", StringUtils.isBlank(System.getProperty("region")));
        PropertiesManager.parseJenkinsTestPropertiesIntoSystemPropertyValues();
        Assert.assertTrue("System property should not be set yet", "F".equals(System.getProperty("region")));
    }

    @Test
    public void parseJenkinsTestPropertiesIntoSystemPropertyValues_SingleValueTest() {
        System.setProperty(PropertiesManager.JENKINS_STRING_PARAM_TEST_PROPERTIES_KEY, "region=F");
        Assert.assertTrue("System property should not be set yet", StringUtils.isBlank(System.getProperty("region")));
        PropertiesManager.parseJenkinsTestPropertiesIntoSystemPropertyValues();
        Assert.assertTrue("System property should not be set yet", "F".equals(System.getProperty("region")));
    }

    private void simulateloadingDefaultOverrideFileRegionEqualsE() {
        System.setProperty(REGION, DEFAULT_REGION_VALUE_E);
        reInitializeProperties();
        simulateLoadingOverrideRegionFilesToClasspath();
        reInitializeProperties();
    }
    private void simulateloadingDefaultOverrideFileRegionEqualsF() {
        System.setProperty(REGION, F_REGION_VALUE);
        reInitializeProperties();
        simulateLoadingOverrideRegionFilesToClasspath();
        reInitializeProperties();
    }

    private void simulateLoadingOverrideRegionFilesToClasspath() {
        String region = PropertiesManager.getProperty(REGION);
        if(region.equals(DEFAULT_REGION_VALUE_E)) {
            simulateloadingOverrideRegionFileForE();
        } else if(region.equals(F_REGION_VALUE)) {
            simulateloadingOverrideRegionFileForF();
        } else {
            Assert.fail("Override file for region: " + region + ", has not been configured yet.  Please add it to the simulateLoadingOverrideFilesToClasspath() method.");
        }
    }

    private void simulateloadingOverrideRegionFileForE() {
        System.setProperty(BASE_UNIX_INTERNAL, E_Override_Expected_URL);
        System.setProperty(E_ONLY_PROP, E_ONLY_PROP_OVERRIDE_VALUE);
    }
    private void simulateloadingOverrideRegionFileForF() {
        System.setProperty(BASE_UNIX_INTERNAL, F_Override_Expected_URL);
        System.setProperty(F_ONLY_PROP, F_ONLY_PROP_OVERRIDE_VALUE);
    }

    
    private void simulateRemovingAnyRegressionConfigFilesThatMightExist() {
        System.setProperty(REGION, "");
        System.setProperty(BASE_UNIX_INTERNAL, "");
        System.setProperty(E_ONLY_PROP, "");
        System.setProperty(F_ONLY_PROP, "");
    }
    
    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void changeResourceFileRegionProperty(String propertyValue, RegionProperties resourceFile){
        PropertiesManager.setProperty(REGION, propertyValue, resourceFile, PropertiesManager.BASE_DIRECTORY);
        try {
            propertiesManager.reInitializePropertiesAfterRegionChange();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Assert.fail("Failed in trying to reInitialize Properties After Region Change");
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failed in trying to reInitialize Properties After Region Change");
        }
    }
}
