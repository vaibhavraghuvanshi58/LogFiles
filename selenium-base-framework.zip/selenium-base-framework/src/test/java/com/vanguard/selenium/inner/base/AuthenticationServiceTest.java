/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/AuthenticationServiceTest.java $
 $LastChangedRevision: 5695 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-06 17:01:20 -0400 (Thu, 06 Jul 2017) $
 */
package com.vanguard.selenium.inner.base;

import static org.easymock.EasyMock.createMock;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Timeouts;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.vanguard.selenium.inner.base.AuthenticationService.StatusMessageContainer;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;

@RunWith(PowerMockRunner.class)
@PrepareForTest(AuthenticationService.class)
public class AuthenticationServiceTest {
    
    private static final long TWENTY_SECONDS = 20000;
    private static final long TEN_MINUTES = 600000;

    private static final String ANY_PW = "password";
    private static final String ANY_USERNAME = "userName";
    public static final String VALID_USERNAME = "TCOE001";
    public static final String VALID_PASSWORD = "Spring66";//NOTE: Passwords may change over time.
    private static final String INVALD_USERNAME = "INVALD";
    private static final String INVALID_PASS = "000000";
    private AuthenticationService service;
    
    JSONParserService jsonParserService = new JSONParserService();

    @Before
    public void setup() {
        service = AuthenticationService.getInstance();
    }

    @Test
    public void givenBlankUserNameWhenWebDriverIsCreatedThenThrowIllegalArgumentWithBlankNameMessage() throws Exception {
        buildWebDriverToFailWithExceptionMessage(createMock(WebDriver.class), "", ANY_PW, AuthenticationService.USER_NAME_BLANK_EXCEPTION);
    }

    @Test
    public void givenBlankPasswordWhenWebDriverIsCreatedThenThrowIllegalArgumentWithBlankPasswordMessage() throws Exception {
        buildWebDriverToFailWithExceptionMessage(createMock(WebDriver.class), ANY_USERNAME, "", AuthenticationService.PASSWORD_BLANK_EXCEPTION);
    }

    @Test
    public void givenNullWebDriverInputWhenWebDriverIscreatedThenThrowIllegalArgumentWithNullDriverMessage() throws Exception {
        buildWebDriverToFailWithExceptionMessage(null, ANY_USERNAME, ANY_PW, VgiAuthenticatedWebDriver.DRIVER_NULL_EXCEPTION);
    }

    @Test
    public void SMOKE_getPOSTAuthenticationRequestResponseSUCCESSFULTest() throws IOException {
        JSONObject jsonResponse = service.getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,VALID_USERNAME, VALID_PASSWORD);
        
        assertEquals("Successful status should be the value [0]", "0", jsonParserService.getStringFromJSONObject(jsonResponse, JSONParserService.STATUS));
        assertEquals(1, jsonParserService.getJSONArrayFromJSONObject(jsonResponse, CookieService.TOKEN_SET).length());
    }
    @Test
    public void SMOKE_getPOSTAuthenticationRequestResponseFAILURETest() throws IOException {
        JSONObject jsonResponse = service.getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,INVALD_USERNAME, INVALID_PASS);
        assertEquals("The un-successful status we expect is [201]", "201", jsonParserService.getStringFromJSONObject(jsonResponse, JSONParserService.STATUS));
        //NOTE: Trying to get a TOKEN_SET that doesn't exist will add red fail lines in the console.  This is ok.
        LoggingUtility.logError("IGNORE THE NEXT ERROR: For trying to retrieve JSON ARRAY of TokenSet.  WE'RE EXPECTING IT NOT TO BE THERE FOR THIS TEST.");
        assertEquals(0, jsonParserService.getJSONArrayFromJSONObject(jsonResponse, CookieService.TOKEN_SET).length());
    }

    private void buildWebDriverToFailWithExceptionMessage(WebDriver parentWebDriver, String userName, String password, String exceptionMessage) {
        try{
            new VgiAuthenticatedWebDriver(parentWebDriver, userName, password);
            fail();
        } catch (IllegalArgumentException e) {
            assertEquals(exceptionMessage, e.getMessage());
        }
    }
    
    @Test 
    public void testNavigatingToAVanguardDomainSiteSuccessfulFirstAttempt() throws IOException {
        WebDriver driver = Mockito.mock(WebDriver.class);
        
        Options options = Mockito.mock(Options.class);
        Mockito.when(driver.manage()).thenReturn(options);
        
        Timeouts timeouts = Mockito.mock(Timeouts.class);
        Mockito.when(options.timeouts()).thenReturn(timeouts);
        
        Timeouts returnTimeouts = Mockito.mock(Timeouts.class);
        Mockito.when(timeouts.pageLoadTimeout(TWENTY_SECONDS, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        Mockito.when(timeouts.pageLoadTimeout(TEN_MINUTES, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        
        AuthenticationService authenticationServiceSUT = AuthenticationService.getInstance();
        
        authenticationServiceSUT.navigateToAVanguardDomainSite(driver);
        
        
        Mockito.verify(driver,Mockito.times(2)).manage();
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(options,Mockito.times(2)).timeouts();
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
    }
    
    @Test 
    public void testNavigatingToAVanguardDomainSiteSuccessfulSecondAttempt() throws IOException {
        WebDriver driver = Mockito.mock(WebDriver.class);
        
        Options options = Mockito.mock(Options.class);
        Mockito.when(driver.manage()).thenReturn(options);
        
        Timeouts timeouts = Mockito.mock(Timeouts.class);
        Mockito.when(options.timeouts()).thenReturn(timeouts);
        
        Timeouts returnTimeouts = Mockito.mock(Timeouts.class);
        Mockito.when(timeouts.pageLoadTimeout(TWENTY_SECONDS, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        Mockito.when(timeouts.pageLoadTimeout(TEN_MINUTES, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        
        Mockito.doThrow(new RuntimeException()).when(driver).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        
        AuthenticationService authenticationServiceSUT = AuthenticationService.getInstance();
        
        authenticationServiceSUT.navigateToAVanguardDomainSite(driver);
        
        
        Mockito.verify(driver,Mockito.times(2)).manage();
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.DEV_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(options,Mockito.times(2)).timeouts();
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
    }
    
    @Test 
    public void testNavigatingToAVanguardDomainSiteFailureOnSecondAttemptThrowsException() throws IOException {
        WebDriver driver = Mockito.mock(WebDriver.class);
        
        Options options = Mockito.mock(Options.class);
        Mockito.when(driver.manage()).thenReturn(options);
        
        Timeouts timeouts = Mockito.mock(Timeouts.class);
        Mockito.when(options.timeouts()).thenReturn(timeouts);
        
        Timeouts returnTimeouts = Mockito.mock(Timeouts.class);
        Mockito.when(timeouts.pageLoadTimeout(TWENTY_SECONDS, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        Mockito.when(timeouts.pageLoadTimeout(TEN_MINUTES, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        
        Mockito.doThrow(new RuntimeException()).when(driver).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.doThrow(new RuntimeException()).when(driver).get(AuthenticationService.DEV_INTERNAL_VANGUARD_DOMAIN);
        
        AuthenticationService authenticationServiceSUT = AuthenticationService.getInstance();
        
        boolean throwException = false;
        try{
            authenticationServiceSUT.navigateToAVanguardDomainSite(driver);
        }catch (PageNavigationException seleniumAuthenticationException) {
            throwException = true;
        }
        
        Assert.assertTrue("navigate to a Vanguard Domain site did not throw an exception as expected",throwException);
        Mockito.verify(driver,Mockito.times(1)).manage();
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.DEV_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(options,Mockito.times(1)).timeouts();
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(timeouts,Mockito.never()).pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
    }
    
    public void testSomething2() throws IOException {
        String username = "username";
        String password = "password";
        WebDriver driver = Mockito.mock(WebDriver.class);
        
        Options options = Mockito.mock(Options.class);
        Mockito.when(driver.manage()).thenReturn(options);
        driver.get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        
        Timeouts timeouts = Mockito.mock(Timeouts.class);
        Mockito.when(options.timeouts()).thenReturn(timeouts);
        
        Timeouts returnTimeouts = Mockito.mock(Timeouts.class);
        Mockito.when(timeouts.pageLoadTimeout(TWENTY_SECONDS, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        Mockito.when(timeouts.pageLoadTimeout(TEN_MINUTES, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        
        PowerMockito.mockStatic(AuthenticationService.class);
        AuthenticationService authenticationService = Mockito.mock(AuthenticationService.class);
        Mockito.when(AuthenticationService.getInstance()).thenReturn(authenticationService);
        
        JSONObject returnJsonObject = new JSONObject();
        StatusMessageContainer returnJsonResponse =  authenticationService.new StatusMessageContainer("message", AuthenticationService.SUCCESSFUL_STATUS);
        Mockito.doCallRealMethod().when(authenticationService).navigateToAVanguardDomainSite(driver);
        
        
        Mockito.when(authenticationService.getJSONResponseFromJSONOject(returnJsonObject)).thenReturn(returnJsonResponse);
        
        
        
       
        VgiAuthenticatedWebDriver vgiAuthenticatedWebDriver = new VgiAuthenticatedWebDriver();
        vgiAuthenticatedWebDriver.setAuthenticationService(authenticationService);
        vgiAuthenticatedWebDriver.constuctAuthenticatedWebDriver(driver, username, password);
        
        Mockito.verify(driver,Mockito.times(2)).manage();
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(options,Mockito.times(2)).timeouts();
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(authenticationService, Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,username, password);
//        Mockito.verify(mock)
    }
}
