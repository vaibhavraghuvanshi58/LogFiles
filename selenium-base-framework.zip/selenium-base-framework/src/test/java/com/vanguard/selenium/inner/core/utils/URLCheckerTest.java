/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/URLCheckerTest.java $
 $LastChangedRevision: 5207 $
 $Author: uz0s $
 $LastChangedDate: 2017-01-23 09:32:18 -0500 (Mon, 23 Jan 2017) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.vanguard.selenium.inner.core.rule.RetryRule;
import com.vanguard.selenium.inner.core.utils.URLChecker;

public class URLCheckerTest {

    private URLChecker fakeUrlChecker = null;
    private URLChecker goodUrlChecker = new URLChecker("https://investor.vanguard.com/corporate-portal", "Vanguard");
    private String testName = "sample test";
    private String testAssertion = "bar assertion";
    private String sampleUrl = "sample url";

    @Before
    public void setup(){
        fakeUrlChecker = new URLChecker(testName, sampleUrl, testAssertion, "ucud@vanguard.com", "bad url", new RetryRule(3), true);
    }

//    @Test
//    @Ignore/*Can no longer access prod sites on Jenkins due to segmentation*/
//    public void checkUrlTest() {
//        assertTrue(goodUrlChecker.checkURL());
//        goodUrlChecker.setAssertion("Welcome to Fidelity");
//        assertFalse(goodUrlChecker.checkURL());
//    }

    @Test
    public void generateSubjectError1Test() {
        fakeUrlChecker.setConnectionError(true);
        String subject = fakeUrlChecker.generateSubject();
        assertTrue(subject.equals("Connection failure for " + testName));
    }

    @Test
    public void generateSubjectError2Test() {
        fakeUrlChecker.setTimeoutError(true);
        String subject = fakeUrlChecker.generateSubject();
        assertTrue(subject.equals("Timeout error for " + testName));
    }

    @Test
    public void generateSubjectError3Test() {
        fakeUrlChecker.setConnectionError(false);
        fakeUrlChecker.setAssertionError(true);
        String subject = fakeUrlChecker.generateSubject();
        assertTrue(subject.equals("Assertion failure for " + testName));
    }

    @Test
    public void generateSubjectError4Test() {
        String subject = fakeUrlChecker.generateSubject();
        assertTrue(subject.equals("Connection failure for " + testName));
    }

    @Test
    public void generateCauseOfError1Test() {
        String cause = fakeUrlChecker.generateCauseOfError();
        assertTrue(cause.equals("Test " + testName + " failed.  Unable to connect to: sample url"));
    }

    @Test
    public void generateCauseOfError2Test() {
        fakeUrlChecker.setConnectionError(false);
        fakeUrlChecker.setAssertionError(true);
        String cause = fakeUrlChecker.generateCauseOfError();
        assertTrue(cause.equals("Assertion failed for test " + testName + ".  The response did not contain \"" + testAssertion + "\"."));
    }

    @Test
    public void generateCauseOfError3Test() {
        fakeUrlChecker.setTimeoutError(true);
        String cause = fakeUrlChecker.generateCauseOfError();
        assertTrue(cause.equals("Test " + testName + " timed out while attempting to connect to " + sampleUrl + " within 5000 milliseconds."));
    }

    @Test
    public void responseContainsTrueTest() {
        fakeUrlChecker.setResponse("Some fake response");
        assertTrue(fakeUrlChecker.responseContains("fake response"));
    }

    @Test
    public void responseContainsFalseTest() {
        fakeUrlChecker.setResponse("Some fake response");
        assertFalse(fakeUrlChecker.responseContains("good"));
    }

}
