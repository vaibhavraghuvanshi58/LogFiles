/*
 ****************************************************************************
 * 
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/environments/SafariConfigurationTest.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author uz0s
 *
 */
public class SafariConfigurationTest {
    SafariConfiguration config;
    
    @Before
    public void setup() {
        config = new SafariConfiguration();
    }
    
    @Test
    public void constructorForSafariTest(){
        DesiredCapabilities expectedCapabilities = DesiredCapabilities.safari();
        expectedCapabilities.setCapability(BrowserConfiguration.PLATFORM, "Mac");
        expectedCapabilities.setCapability(BrowserConfiguration.VERSION, "latest");
        
        DesiredCapabilities actualCapabilities = config.getDesiredCapabilities();
        Assert.assertEquals(expectedCapabilities, actualCapabilities);
    }
}
