/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/NestedMockBuilderExpectationSetter.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import org.easymock.IAnswer;
import org.easymock.IExpectationSetters;

/**
 * @author utcl
 *
 */
public class NestedMockBuilderExpectationSetter<M extends VgiMockBuilder<?>, T, Z extends VgiMockBuilder<T>> implements MockBuilderExpectationSetter<M, T> {

    private final M callingMockBuilder;
    private final IExpectationSetters<T> expectationSetters;
    private final Z nestedMockBuilder;

    public NestedMockBuilderExpectationSetter(M callingMockBuilder, IExpectationSetters<T> expectationSetters, Z nestedMockBuilder) {
        this.callingMockBuilder = callingMockBuilder;
        this.expectationSetters = expectationSetters;
        this.nestedMockBuilder = nestedMockBuilder;
    }

    public M andReturn(T value) {
        expectationSetters.andReturn(value);
        return callingMockBuilder;
    }

    public Z andReturnBuilder() {
        expectationSetters.andReturn(nestedMockBuilder.getMock());
        return nestedMockBuilder;
    }

    public M andReturn(T value, int ... times) {
        final IExpectationSetters<T> expectationForTimes = expectationSetters.andReturn(value);
        addTimes(expectationForTimes, times);

        return callingMockBuilder;
    }

    public M andThrow(Throwable throwable, int ... times) {
        final IExpectationSetters<T> expectationForTimes = expectationSetters.andThrow(throwable);
        addTimes(expectationForTimes, times);

        return callingMockBuilder;
    }

    public M andAnswer(IAnswer<? extends T> answer, int ... times) {
        final IExpectationSetters<T> expectationForTimes = expectationSetters.andAnswer(answer);
        addTimes(expectationForTimes, times);

        return callingMockBuilder;
    }

    public M andDelegateTo(Object delegateTo, int ... times) {
        final IExpectationSetters<T> expectationForTimes = expectationSetters.andDelegateTo(delegateTo);
        addTimes(expectationForTimes, times);

        return callingMockBuilder;
    }

    private void addTimes(IExpectationSetters<T> expectationForTimes, int... times) {
        if(times.length > 0) {
            expectationForTimes.times(times[0]);
        }
    }

    public IExpectationSetters<T> times(int count) {
        return expectationSetters.times(count);
    }

    public IExpectationSetters<T> times(int min, int max) {
        return expectationSetters.times(min, max);
    }

    public IExpectationSetters<T> once() {
        return expectationSetters.once();
    }

    public IExpectationSetters<T> atLeastOnce() {
        return expectationSetters.atLeastOnce();
    }

    public IExpectationSetters<T> anyTimes() {
        return expectationSetters.anyTimes();
    }

    public void buildMock() {
        callingMockBuilder.buildMockTree();
    }

}
