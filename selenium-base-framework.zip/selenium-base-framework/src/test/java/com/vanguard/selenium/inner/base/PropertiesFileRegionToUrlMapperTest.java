/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/PropertiesFileRegionToUrlMapperTest.java $
 $LastChangedRevision: 4631 $
 $Author: uz0s $
 $LastChangedDate: 2016-10-05 18:57:09 -0400 (Wed, 05 Oct 2016) $
 */
package com.vanguard.selenium.inner.base;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.vanguard.selenium.inner.logon.user.ChannelType;

public class PropertiesFileRegionToUrlMapperTest {

    PropertiesFileRegionToUrlMapper urlMapper;

    @Before
    public void setup() {
        urlMapper = new PropertiesFileRegionToUrlMapper();
    }

    @Test
    public void givenRetailWebChannelWhenTestIsSetToRunInTestRegionThenBaseUnixRetailExternalUrlTest() {
        ChannelType channel = ChannelType.RETAIL_WEB;
        String expectedUrl = PropertiesManager.BASE_UNIX_RETAIL_EXTERNAL_URL;
        boolean isSetToRunInTestRegion = true;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test
    public void givenRetailMailChannelWhenTestIsSetToRunInTestRegionThenBaseUnixRetailInternalUrlTest() {
        ChannelType channel = ChannelType.RETAIL_PHONE;
        String expectedUrl = PropertiesManager.BASE_UNIX_RETAIL_INTERNAL_URL;
        boolean isSetToRunInTestRegion = true;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test
    public void givenSbsInternalChannelWhenTestIsSetToRunInTestRegionThenBaseUnixSbsInternalUrlTest() {
        ChannelType channel = ChannelType.SBS_INTERNAL;
        String expectedUrl = PropertiesManager.BASE_UNIX_SBS_INTERNAL_URL;
        boolean isSetToRunInTestRegion = true;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test
    public void givenSbsExternalChannelWhenTestIsSetToRunInTestRegionThenBaseUnixSbsExternalUrlTest() {
        ChannelType channel = ChannelType.SBS_EXTERNAL;
        String expectedUrl = PropertiesManager.BASE_UNIX_SBS_EXTERNAL_URL;
        boolean isSetToRunInTestRegion = true;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test
    public void givenInstExternalChannelWhenTestIsSetToRunInTestRegionThenBaseUnixSbsExternalUrlTest() {
        ChannelType channel = ChannelType.INST_EXTERNAL;
        String expectedUrl = PropertiesManager.BASE_UNIX_INST_EXTERNAL_URL;
        boolean isSetToRunInTestRegion = true;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

    @Test
    public void givenTestsSetToRunLocallyWhenGettingPropertyUrlThenBaseWindowsUrl() throws Exception {
        ChannelType anyChannel = ChannelType.INST_EXTERNAL;
        String expectedUrl = PropertiesManager.BASE_WINDOWS_URL;
        boolean isSetToRunInTestRegion = false;

        String actualUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(anyChannel, isSetToRunInTestRegion);

        Assert.assertEquals(expectedUrl, actualUrl);
    }

}
