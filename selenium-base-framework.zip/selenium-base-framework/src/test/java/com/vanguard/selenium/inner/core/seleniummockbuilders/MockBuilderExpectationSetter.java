/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/MockBuilderExpectationSetter.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import org.easymock.IAnswer;
import org.easymock.IExpectationSetters;

/**
 * @author utcl
 *
 * @param <M>
 * @param <T>
 */
public interface MockBuilderExpectationSetter<M extends VgiMockBuilder<?>, T> {

    public abstract M andReturn(T value);

    public abstract M andReturn(T value, int... times);

    public abstract M andThrow(Throwable throwable, int... times);

    public abstract M andAnswer(IAnswer<? extends T> answer, int... times);

    public abstract M andDelegateTo(Object delegateTo, int... times);

    public abstract IExpectationSetters<T> times(int count);

    public abstract IExpectationSetters<T> times(int min, int max);

    public abstract IExpectationSetters<T> once();

    public abstract IExpectationSetters<T> atLeastOnce();

    public abstract IExpectationSetters<T> anyTimes();

    public abstract void buildMock();

}