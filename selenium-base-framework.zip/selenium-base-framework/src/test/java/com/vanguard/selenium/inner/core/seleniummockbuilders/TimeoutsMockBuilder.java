/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/TimeoutsMockBuilder.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
*/
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import java.util.concurrent.TimeUnit;

import org.easymock.EasyMock;
import org.openqa.selenium.WebDriver.Timeouts;

/**
 * @author utcl
 *
 */
public class TimeoutsMockBuilder extends VgiMockBuilder<Timeouts> {

    public TimeoutsMockBuilder(Class<Timeouts> classToMock) {
        super(classToMock);
    }

    public MockBuilderExpectationSetter<TimeoutsMockBuilder, Timeouts> implicitlyWait(int time, TimeUnit timeUnit) {
        return chain(EasyMock.expect(mock.implicitlyWait(time, timeUnit)));
    }

}
