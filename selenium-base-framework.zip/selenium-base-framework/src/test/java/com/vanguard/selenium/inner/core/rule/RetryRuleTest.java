/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/rule/RetryRuleTest.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.rule;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runners.model.Statement;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.rule.RetryRule;

/**
 * @author utcl
 *
 */
public class RetryRuleTest {

    private RetryRule retryRule;

    @Before
    public void setup() {
        retryRule = new RetryRule(0);
    }

    @Test
    public void givenZeroMaxRetriesWhenRetryRunThenNoStatementsEvaluatedOrDriverInteraction() throws Throwable {
        Statement mockStatement = createMock(Statement.class);
        replay(mockStatement);

        retryRule.apply(mockStatement, null).evaluate();

        verify(mockStatement);
        assertEquals(new Integer(1), retryRule.getRetryCount());
    }

    @Test
    public void given1MaxRetriesWhenRetryRunThenNoStatementsEvaluatedOrDriverInteraction() throws Throwable {
        retryRule = new RetryRule(1);

        Statement mockStatement = createMock(Statement.class);
        mockStatement.evaluate();
        expectLastCall().atLeastOnce();
        replay(mockStatement);

        WebDriver mockDriver = createMock(WebDriver.class);
        mockDriver.quit();
        expectLastCall().atLeastOnce();
        replay(mockDriver);

        retryRule.setDriver(mockDriver);

        retryRule.apply(mockStatement, null).evaluate();

        verify(mockStatement);
        verify(mockDriver);
    }

    @Test
    public void givenScreenshotDisabledWhenRetryUnsuccessfulThenDeliverException() throws Throwable {
        retryRule = new RetryRule(1);

        Statement mockStatement = createMock(Statement.class);
        Throwable mockThrowable = createMock(Throwable.class);
        replay(mockThrowable);

        mockStatement.evaluate();
        expectLastCall().andThrow(mockThrowable);
        replay(mockStatement);

        WebDriver mockDriver = createMock(WebDriver.class);
        mockDriver.quit();
        expectLastCall().atLeastOnce();
        replay(mockDriver);

        retryRule.setDriver(mockDriver);

        try {
            retryRule.apply(mockStatement, null).evaluate();
            fail();
        } catch (Throwable e) {
            assertEquals(mockThrowable, e);
        }
    }

    @Test
    public void givenMaxRetriesLargerThanOneWhenSuccessWithinMaxRetriesThenNoExceptionThrown() throws Throwable {
        retryRule = new RetryRule(4);

        Statement mockStatement = createStrictMock(Statement.class);
        Throwable mockThrowable = createMock(Throwable.class);
        replay(mockThrowable);

        mockStatement.evaluate();
        expectLastCall().andThrow(mockThrowable).times(2);

        mockStatement.evaluate();
        expectLastCall();

        replay(mockStatement);

        WebDriver mockDriver = createMock(WebDriver.class);
        mockDriver.quit();
        expectLastCall().atLeastOnce();
        replay(mockDriver);

        retryRule.setDriver(mockDriver);

        retryRule.apply(mockStatement, null).evaluate();
        verify(mockStatement);
        verify(mockDriver);
    }
}
