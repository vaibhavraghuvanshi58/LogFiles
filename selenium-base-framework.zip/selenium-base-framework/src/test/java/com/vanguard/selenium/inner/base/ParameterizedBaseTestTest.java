/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/ParameterizedBaseTestTest.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
*/
package com.vanguard.selenium.inner.base;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.rules.TestWatcher;

import com.vanguard.selenium.inner.testdata.TestCase;

/**
 * @author utcl
 *
 */
public class ParameterizedBaseTestTest {
    
    private TestableParameterizedBaseTest baseTest;
    private TestCase mockTestCase;
    
    @Before
    public void setup() {
        mockTestCase = createMock(TestCase.class);
        baseTest = new TestableParameterizedBaseTest(mockTestCase);
    }

    @Test
    public void givenNullTestCaseWhenConstructedThenNullTestCaseOnParameterizedTest() throws Exception {
        baseTest = new TestableParameterizedBaseTest(null);
        assertEquals(null, baseTest.getTestCase());
    }
    
    @Test
    public void givenTestCaseWhenConstructedThenAddTestCaseToParameterizedTest() throws Exception {
        replay(mockTestCase);
        assertEquals(mockTestCase, baseTest.getTestCase());
    }

    private class TestableParameterizedBaseTest extends ParameterizedBaseTest {

        /**
         * @param testCase
         */
        public TestableParameterizedBaseTest(TestCase testCase) {
            super(testCase);
        }
        
        public TestWatcher getParameterizedMethodRule() {
            return parameterizedMethodRule;
        }
        
    }

}
