/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/ExampleConfigFile.java $
 $LastChangedRevision: 1130 $
 $Author: ubhj $
 $LastChangedDate: 2015-02-10 17:39:18 -0500 (Tue, 10 Feb 2015) $
 */
package com.vanguard.selenium.inner.core.utils;


public class ExampleConfigFile {
	public static final String EXAMPLE_CONFIG_FILE = "// custom config file\r\n" +
			"lockPref(\"network.proxy.type\",3);\r\n" +
			"lockPref(\"network.proxy.http\", \"http-proxy2\");\r\n" +
			"lockPref(\"network.proxy.http_port\", 81);\r\n" +
			"lockPref(\"network.proxy.no_proxies_on\", \".vanguard.com\", \".vanguard.info\");\r\n" +
			"\r\n" +
			"lockPref(\"browser.startup.homepage\", \"http://www.vanguard.com/\");\r\n" +
			"lockPref(\"browser.startup.page\", 1);\r\n" +
			"lockPref(\"browser.shell.checkDefaultBrowser\", false);\r\n" +
			"lockPref(\"browser.search.update\", false);\r\n" +
			"lockPref(\"browser.link.open_external\", 1);\r\n" +
			"lockPref(\"browser.link.open_newwindow\", 1);\r\n" +
			"lockPref(\"browser.tabs.warnOnClose\", false);\r\n" +
			"lockPref(\"browser.tabs.autoHide\", false);\r\n" +
			"lockPref(\"browser.search.update\", false);\r\n" +
			"lockPref(\"browser.formfill.enable\", false);\r\n" +
			"lockPref(\"browser.download.manager.retention\", 0);\r\n" +
			"lockPref(\"browser.safebrowsing.enabled\", true);\r\n" +
			"\r\n" +
			"lockPref(\"dom.disable_open_during_load\", true);\r\n" +
			"lockPref(\"permissions.default.image\", 1);\r\n" +
			"\r\n" +
			"lockPref(\"xpinstall.whitelist.required\", true);\r\n" +
			"\r\n" +
			"lockPref(\"signon.rememberSignons\", false);\r\n" +
			"lockPref(\"pref.privacy.disable_button.view_passwords\", true);\r\n" +
			"\r\n" +
			"lockPref(\"layout.spellcheckDefault\", 1);\r\n" +
			"\r\n" +
			"lockPref(\"extensions.update.enabled\", false);\r\n" +
			"lockPref(\"extensions.update.autoUpdateDefault\", false);\r\n" +
			"\r\n" +
			"lockPref(\"app.update.auto\", false);\r\n" +
			"lockPref(\"app.update.autoUpdateEnabled\", false);\r\n" +
			"lockPref(\"app.update.enabled\", false);\r\n" +
			"lockPref(\"app.update.mode\", 1);\r\n" +
			"\r\n" +
			"pref(\"browser.download.useDownloadDir\", false);\r\n" +
			"";
}
