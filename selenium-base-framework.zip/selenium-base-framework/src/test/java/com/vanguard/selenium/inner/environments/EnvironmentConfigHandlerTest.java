package com.vanguard.selenium.inner.environments;

import org.junit.Assert;
import org.junit.Test;

import com.vanguard.selenium.inner.base.PropertiesManager;


public class EnvironmentConfigHandlerTest {

    @Test
    public void testOverrideCapabilityWhenValueIsPresent() {
        EnvironmentConfiguration expectedEnvironment = new IPhoneConfiguration();
        String capabilityName = "MyCap";
        String capabilityValue = "AnyNonBlankValue";
        expectedEnvironment.addCapability(capabilityName, capabilityValue);
        
        EnvironmentConfiguration actualEnvironment = new IPhoneConfiguration();
        EnvironmentConfigHandler.overrideCapabilityIfValueIsPresent(actualEnvironment, capabilityName, capabilityValue);
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testNoOverrideToCapabilityWhenNoValueIsPresent() {
        String blankValue = "";
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandler.overrideCapabilityIfValueIsPresent(actualEnvironment, "anyNonSetCapability", blankValue);
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    public void testOverrideAllCapabilityValuesForSafariBrowser() {
        EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("[\"safariTestTag\"]", "anyBrowserVersion", "anyOSType", 
                "anyOSVersion", "anyChromDriverVersion", "anyIEDriverVersion", "anyDeviceName", "anyDeviceOrientation", 
                "anyDevicePlatformVersion", "60", "1920x1080");
        EnvironmentConfiguration expectedConfig = new SafariConfiguration();
        EnvironmentConfiguration actualConfig = new SafariConfiguration();
        expectedConfig.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, values.getTags());
        expectedConfig.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, values.getIdleTimout());
        expectedConfig.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, values.getScreenResolution());        
        expectedConfig.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, values.getIdleTimout());
        expectedConfig.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, values.getScreenResolution());
        expectedConfig.addCapability(EnvironmentConfiguration.VERSION, values.getBrowserVersion());
        expectedConfig.addCapability(EnvironmentConfiguration.PLATFORM, values.getOsType() + " " + values.getOsVersion());
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
        Assert.assertEquals(expectedConfig.getDesiredCapabilities(), actualConfig.getDesiredCapabilities());
    }
    @Test
    public void testOverrideAllCapabilityValuesForMobile() {
        EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("[\"mobileTestTag\"]", "anyBrowserVersion", "anyOSType", 
                "anyOSVersion", "anyChromDriverVersion", "anyIEDriverVersion", "anyDeviceName", "anyDeviceOrientation", 
                "anyDevicePlatformVersion", "60", "1920x1080");
        EnvironmentConfiguration expectedConfig = new IPhoneConfiguration();
        EnvironmentConfiguration actualConfig = new IPhoneConfiguration();
        expectedConfig.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, values.getTags());
        expectedConfig.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, values.getIdleTimout());
        expectedConfig.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, values.getScreenResolution());
        expectedConfig.addCapability(MobileConfiguration.DEVICE_NAME, values.getDeviceName());
        expectedConfig.addCapability(MobileConfiguration.DEVICE_ORIENTATION, values.getDeviceOrientation());
        expectedConfig.addCapability(MobileConfiguration.PLATFORM_VERSION, values.getDevicePlatformVersion());
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
        Assert.assertEquals(expectedConfig.getDesiredCapabilities(), actualConfig.getDesiredCapabilities());
    }
    
    @Test(expected=RuntimeException.class)
    public void testSetSauceLabsSpecicDesiredCapabilitiesThrowsRuntimeExceptionWhenSettingIdleTimeoutToSomethingNonParsable() throws NoSuchMethodException, SecurityException {
    	EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("", "", "", 
                "", "", "", "", "", "", "anyNonParsable-IdleTimeout", "");
        EnvironmentConfiguration expectedConfig = new FirefoxConfiguration();
        EnvironmentConfiguration actualConfig = new FirefoxConfiguration();
        expectedConfig.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, values.getIdleTimout());
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
    }
    @Test(expected=RuntimeException.class)
    public void testSetSauceLabsSpecicDesiredCapabilitiesThrowsRuntimeExceptionWhenSettingScreenResolutionToInvalidValue() {
    	EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("", "", "", 
                "", "", "", "", "", "", "", "anyScreenResolutionNotMatching####x####");
        EnvironmentConfiguration expectedConfig = new FirefoxConfiguration();
        EnvironmentConfiguration actualConfig = new FirefoxConfiguration();
        expectedConfig.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, values.getScreenResolution());
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
    }

    @Test
    public void testOverrideNoCapabilityValuesForChromeBrowser() {
        EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("", "", "", 
                "", "", "", "", "", "", "", "");
        EnvironmentConfiguration expectedConfig = new ChromeConfiguration();
        EnvironmentConfiguration actualConfig = new ChromeConfiguration();
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
        Assert.assertEquals(expectedConfig.getDesiredCapabilities(), actualConfig.getDesiredCapabilities());
    }
    @Test
    public void testOverrideNoCapabilityValuesForMobile() {
        EnvironmentConfigOverrideValues values = new EnvironmentConfigOverrideValues("", "", "", 
                "", "", "", "", "", "", "", "");
        EnvironmentConfiguration expectedConfig = new IPhoneConfiguration();
        EnvironmentConfiguration actualConfig = new IPhoneConfiguration();
        
        EnvironmentConfigHandler.overrideAnyCapabilityValuesPresent(actualConfig, values);
        Assert.assertEquals(expectedConfig.getDesiredCapabilities(), actualConfig.getDesiredCapabilities());
    }
}