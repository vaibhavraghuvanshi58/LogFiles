/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/WebElementMockBuilder.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import org.easymock.EasyMock;
import org.openqa.selenium.WebElement;

/**
 * @author utcl
 *
 */
public class WebElementMockBuilder extends VgiMockBuilder<WebElement> {

    public WebElementMockBuilder(Class<WebElement> classToMock) {
        super(classToMock);
    }

    public WebElementMockBuilder isDisplayed(boolean returnValue) {
        EasyMock.expect(mock.isDisplayed()).andReturn(returnValue);
        return this;
    }

    public MockBuilderExpectationSetter<WebElementMockBuilder, String> getAttribute(String attributeName) {
        return chain(EasyMock.expect(mock.getAttribute(attributeName)));
    }

    public MockBuilderExpectationSetter<WebElementMockBuilder, Boolean> isEnabled() {
        return chain(EasyMock.expect(mock.isEnabled()));
    }

}
