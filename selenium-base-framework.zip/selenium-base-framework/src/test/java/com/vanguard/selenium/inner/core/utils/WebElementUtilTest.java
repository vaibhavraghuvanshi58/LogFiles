/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/WebElementUtilTest.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.vanguard.selenium.inner.core.seleniummockbuilders.WebDriverMockBuilder;
import com.vanguard.selenium.inner.core.seleniummockbuilders.WebDriverWaitMockBuilder;
import com.vanguard.selenium.inner.core.seleniummockbuilders.WebElementMockBuilder;

/**
 * @author utcl
 *
 */
public class WebElementUtilTest {

    private static final String WINDOW_NAME = "windowName";
    private static final String ANY_WINDOW_HANDLE = "anyWindowHandle";
    private static final String HREF = "href";
    private static final String TICKER_TEXT = "ticker";
    private static final String LINK_TEXT = "linkText";
    private static final String ELEMENT_ID = "elementId";

    private WebDriverMockBuilder<RemoteWebDriver> mockDriverBuilder = new WebDriverMockBuilder<RemoteWebDriver>(RemoteWebDriver.class);
    private WebDriver mockDriver;

    @Before
    public void setup() {
        mockDriverBuilder = new WebDriverMockBuilder<RemoteWebDriver>(RemoteWebDriver.class);
        mockDriver = mockDriverBuilder.getMock();
    }

    @Test
    public void givenIdDoesNotExistOnPageAndNotIeWhenCheckingIfIdExistsThenFalse() throws Exception {
        final Object returnObject = null;
        final String inputValue = WebElementUtil.GET_ELEMENT_BY_ID_TEXT + ELEMENT_ID + "')";
        mockDriverBuilder.executeScript(inputValue).andReturn(returnObject).buildMockTree();

        assertEquals(false, WebElementUtil.doesIdExistOnPage(ELEMENT_ID, mockDriver));
    }

    @Test
    public void givenIdExistsOnPageAndNotIeWhenCheckingIfIdExistsThenTrue() throws Exception {
        final Object returnObject = new Object();
        final String inputValue = WebElementUtil.GET_ELEMENT_BY_ID_TEXT + ELEMENT_ID + "')";
        mockDriverBuilder.executeScript(inputValue).andReturn(returnObject).buildMockTree();

        assertEquals(true, WebElementUtil.doesIdExistOnPage(ELEMENT_ID, mockDriver));
    }

    @Test
    public void givenIdExistsOnPageAndIeBrowserWhenCheckingIfIdExistsThenTrue() throws Exception {
        final WebDriverMockBuilder<InternetExplorerDriver> mockDriverBuilder = new WebDriverMockBuilder<InternetExplorerDriver>(InternetExplorerDriver.class);
        mockDriver = mockDriverBuilder.getMock();

        mockDriverBuilder.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS).andReturn(null).implicitlyWait(30, TimeUnit.SECONDS).andReturn(null);
        mockDriverBuilder.findElementById(ELEMENT_ID).isDisplayed(true);
        mockDriverBuilder.buildMockTree();

        assertEquals(true, WebElementUtil.doesIdExistOnPage(ELEMENT_ID, mockDriver));
    }

    @Test
    public void givenExceptionThrownWhenCheckingIfIdExistsThenFalse() throws Exception {
        final WebDriverMockBuilder<InternetExplorerDriver> mockDriverBuilder = new WebDriverMockBuilder<InternetExplorerDriver>(InternetExplorerDriver.class);
        mockDriver = mockDriverBuilder.getMock();

        mockDriverBuilder.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS).andReturn(null).implicitlyWait(30, TimeUnit.SECONDS).andReturn(null);
        mockDriverBuilder.findElementByIdWithError(ELEMENT_ID);
        mockDriverBuilder.buildMockTree();

        assertEquals(false, WebElementUtil.doesIdExistOnPage(ELEMENT_ID, mockDriver));
    }

    @Test
    public void givenNoLinksFoundWhenSearchingForLinksThenDoNotReturnWebElementLink() throws Exception {
        final ArrayList<WebElement> webElements = new ArrayList<WebElement>();
        mockDriverBuilder.findElements(By.linkText(LINK_TEXT)).andReturn(webElements).buildMockTree();

        assertEquals(null, WebElementUtil.getLinkForText(mockDriver, LINK_TEXT, TICKER_TEXT));
    }

    @Test
    public void givenLinksFoundWithoutMatchingTickerWhenSearchingForLinksThenDoNotReturnWebElementLink() throws Exception {
        final List<WebElement> webElements = new ArrayList<WebElement>();
        final WebElementMockBuilder elementMockBuilder = new WebElementMockBuilder(WebElement.class);
        final WebElement linkMock = elementMockBuilder.getAttribute(HREF).andReturn("notTicker").buildMockTree();
        webElements.add(linkMock);

        mockDriverBuilder.findElements(By.linkText(LINK_TEXT)).andReturn(webElements).buildMockTree();

        assertEquals(null, WebElementUtil.getLinkForText(mockDriver, LINK_TEXT, TICKER_TEXT));
    }

    @Test
    public void givenLinksFoundWithMatchingTickerWhenSearchingForLinksThenReturnMatchedWebElementLink() throws Exception {
        final List<WebElement> webElements = new ArrayList<WebElement>();
        final WebElementMockBuilder elementMockBuilder = new WebElementMockBuilder(WebElement.class);
        final WebElement linkMock = elementMockBuilder.getAttribute(HREF).andReturn(TICKER_TEXT).buildMockTree();
        webElements.add(linkMock);

        mockDriverBuilder.findElements(By.linkText(LINK_TEXT)).andReturn(webElements).buildMockTree();

        assertEquals(linkMock, WebElementUtil.getLinkForText(mockDriver, LINK_TEXT, TICKER_TEXT));
    }

    @Test
    public void givenElementIsUnavailableWhenGettingSourceThenReturnEmptyString() throws Exception {
        final WebElement elementToGetSourceFrom = createMock(WebElement.class);
        mockDriverBuilder.executeScript(WebElementUtil.INNER_HTML_JS, elementToGetSourceFrom).andReturn(null).buildMockTree();

        assertEquals("", WebElementUtil.getSourceForWebElement(elementToGetSourceFrom, mockDriver));
    }

    @Test
    public void givenElementIsAvailableWhenGettingSourceThenReturnSourceCode() throws Exception {
        final String expectedValue = "expectedSourceCode";

        final WebElement elementToGetSourceFrom = createMock(WebElement.class);
        mockDriverBuilder.executeScript(WebElementUtil.INNER_HTML_JS, elementToGetSourceFrom).andReturn(expectedValue).buildMockTree();

        assertEquals(expectedValue, WebElementUtil.getSourceForWebElement(elementToGetSourceFrom, mockDriver));
    }

    @Test
    public void givenUnavailableElementWhenCheckingTextPresenceThenReturnFalse() throws Exception {
        final String searchText = "searchText";
        final By byXpath = By.xpath(WebElementUtil.XPATH_CONTAINS + searchText + WebElementUtil.XPATH_SUFFIX);

        mockDriverBuilder.findElement(byXpath).andThrow(new NoSuchElementException("anyString")).buildMockTree();

        assertEquals(false, WebElementUtil.isTextPresent(mockDriver, searchText));
    }

    @Test
    public void givenAvailableElementWhenCheckingTextPresenceThenReturnTrue() throws Exception {
        final String searchText = "searchText";
        final By byXpath = By.xpath(WebElementUtil.XPATH_CONTAINS + searchText + WebElementUtil.XPATH_SUFFIX);

        final WebElement anyWebElement = createMock(WebElement.class);
        replay(anyWebElement);

        mockDriverBuilder.findElement(byXpath).andReturn(anyWebElement).buildMockTree();

        assertEquals(true, WebElementUtil.isTextPresent(mockDriver, searchText));
    }

    @Test
    public void givenExceptionThrownWhenCheckingIfElementDisplayedThenReturnFalse() throws Exception {
        mockDriverBuilder.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS).andReturn(null)
        .implicitlyWait(WebElementUtil.defaultWaitInSeconds, TimeUnit.SECONDS).andReturn(null);
        mockDriverBuilder.buildMockTree();

        final WebDriverWaitMockBuilder waitMockBuilder = new WebDriverWaitMockBuilder(WebDriverWait.class);
		@SuppressWarnings("unchecked")
		final ExpectedCondition<Boolean> mockCondition = createMock(ExpectedCondition.class);
        waitMockBuilder.until(mockCondition).andThrow(new NoSuchElementException("")).buildMockTree();

        final boolean actualValue = WebElementUtil.isElementDisplayedWithWaitAndCondition(mockDriver, waitMockBuilder.getMock(), mockCondition);
        assertEquals(false, actualValue);
    }

    @Test
    public void givenElementDisplayedWhenCheckingIfElementDisplayedThenReturnTrue() throws Exception {
        mockDriverBuilder.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS).andReturn(null)
        .implicitlyWait(WebElementUtil.defaultWaitInSeconds, TimeUnit.SECONDS).andReturn(null);
        mockDriverBuilder.buildMockTree();

        final WebDriverWaitMockBuilder waitMockBuilder = new WebDriverWaitMockBuilder(WebDriverWait.class);
		@SuppressWarnings("unchecked")
		final ExpectedCondition<Boolean> mockCondition = createMock(ExpectedCondition.class);
        waitMockBuilder.until(mockCondition).andReturn(true).buildMockTree();

        final boolean actualValue = WebElementUtil.isElementDisplayedWithWaitAndCondition(mockDriver, waitMockBuilder.getMock(), mockCondition);
        assertEquals(true, actualValue);
    }

    @Test
    public void givenNoSuchWindowExceptionWhenCheckingIfWindowWithTextIsDisplayedThenFalse() throws Exception {
        mockDriverBuilder.getWindowHandle().andReturn(ANY_WINDOW_HANDLE).switchTo()
        .andReturnBuilder().window(WINDOW_NAME).andThrow(new NoSuchWindowException("it's not here")).buildMockTree();

        boolean actualValue = WebElementUtil.isPopUpWindowDisplayedWithText(mockDriver, WINDOW_NAME, "textToFind");

        assertEquals(false, actualValue);
    }

    @Test
    public void givenNoTextToSearchForAndWindowExistsWhenCheckingIfWindowWithTextIsDisplayedThenTrue() throws Exception {
        mockDriverBuilder.getWindowHandle().andReturn(ANY_WINDOW_HANDLE).switchTo().andReturnBuilder().window(WINDOW_NAME).andReturn(null);
        mockDriverBuilder.switchTo().andReturnBuilder().window(ANY_WINDOW_HANDLE).andReturn(null).buildMockTree();

        boolean actualValue = WebElementUtil.isPopUpWindowDisplayedWithText(mockDriver, WINDOW_NAME, "");

        assertEquals(true, actualValue);
    }

    @Test
    public void givenTextPresentAndWindowExistsWhenCheckingIfWindowWithTextIsDisplayedThenTrue() throws Exception {
        mockDriverBuilder.getWindowHandle().andReturn(ANY_WINDOW_HANDLE).switchTo().andReturnBuilder().window(WINDOW_NAME).andReturn(null);
        mockDriverBuilder.switchTo().andReturnBuilder().window(ANY_WINDOW_HANDLE).andReturn(null);
        mockDriverBuilder.findElement(By.xpath(WebElementUtil.XPATH_CONTAINS + "textToFind" + WebElementUtil.XPATH_SUFFIX)).andReturn(null).buildMockTree();

        boolean actualValue = WebElementUtil.isPopUpWindowDisplayedWithText(mockDriver, WINDOW_NAME, "");

        assertEquals(true, actualValue);
    }

}
