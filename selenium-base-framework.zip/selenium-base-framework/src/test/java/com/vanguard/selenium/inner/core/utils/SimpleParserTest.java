/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/SimpleParserTest.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.vanguard.selenium.inner.core.utils.SimpleParser;

public class SimpleParserTest {

    @Test
    public void parseFileTest(){
        String string = "a,b,c,d,e";
        List<String> stringList = SimpleParser.parseString(string);
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

    @Test
    public void parseFileTest2(){
        String string = "a,b,\"c,d\",e";
        List<String> stringList = SimpleParser.parseString(string);
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c,d"));
        assertTrue(stringList.get(3).equals("e"));
    }

    @Test
    public void parseFileTest3(){
        String string = "a|b|\"c|d\"|e||||";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c|d"));
        assertTrue(stringList.get(3).equals("e"));
    }

    @Test
    public void parseFileTest4(){
        String string = "a|b|c|d|e";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

    @Test
    public void parseFileTest5(){
        String string = "a|b|\"c|d\"|e";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c|d"));
        assertTrue(stringList.get(3).equals("e"));
    }

    @Test
    public void parseFileTest6(){
        String string = "|||a|b|\"c|d\"|e";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c|d"));
        assertTrue(stringList.get(3).equals("e"));
    }

    @Test
    public void parseFileTest7(){
        String string = "a,b,c,d,,,e";
        List<String> stringList = SimpleParser.parseString(string);
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

    @Test
    public void parseFileTest8(){
        String string = "a,b,c,d, , ,e";
        List<String> stringList = SimpleParser.parseString(string);
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

    @Test
    public void parseFileTest9(){
        String string = "a|b|c|d| | |e";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

    @Test
    public void parseFileTest10(){
        String string = "a|b|c|d|||e";
        List<String> stringList = SimpleParser.parseString(string, "|");
        assertTrue(stringList.get(0).equals("a"));
        assertTrue(stringList.get(1).equals("b"));
        assertTrue(stringList.get(2).equals("c"));
        assertTrue(stringList.get(3).equals("d"));
        assertTrue(stringList.get(4).equals("e"));
    }

}
