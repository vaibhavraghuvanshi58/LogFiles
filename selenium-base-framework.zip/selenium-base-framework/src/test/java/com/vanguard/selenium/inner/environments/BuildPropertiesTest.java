/*
 ****************************************************************************
 *
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/environments/BuildPropertiesTest.java $
 $LastChangedRevision: 5691 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-06 16:11:53 -0400 (Thu, 06 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.junit.Assert;
import org.junit.Test;

public class BuildPropertiesTest {

	private final String projectName = "name";
	private final String buildNum = "40";
	private final String svnRevision = "405734";
	private final String fulltag = "jenkins-" + projectName + "-" + buildNum;
	BuildProperties buildProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
	
	@Test
	public void verifyIfAllValuesAreSameThanObjectsAreEqualTest() {
		BuildProperties compareProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
		Assert.assertEquals(buildProperties, compareProperties);
	}
	
	@Test
	public void verifyObjectsNotEqualIfProjectNameDifferentTest() {
		BuildProperties compareProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
		compareProperties.setProjectName("somethingThatDoesNotMatch");
		
		Assert.assertNotEquals(buildProperties, compareProperties);
	}

	@Test
	public void verifyObjectsNotEqualIfBuildNumberDifferentTest() {
		BuildProperties compareProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
		compareProperties.setBuildNumber("somethingThatDoesNotMatch");
		
		Assert.assertNotEquals(buildProperties, compareProperties);
	}

	@Test
	public void verifyObjectsNotEqualIfSVNRevisionDifferentTest() {
		BuildProperties compareProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
		compareProperties.setSourceControlRevisionNum("somethingThatDoesNotMatch");
		
		Assert.assertNotEquals(buildProperties, compareProperties);
	}

	@Test
	public void verifyObjectsNotEqualIfTagsDifferentTest() {
		BuildProperties compareProperties = new BuildProperties(projectName, buildNum, svnRevision, fulltag);
		compareProperties.setEntireBuildTag("somethingThatDoesNotMatch");
		
		Assert.assertNotEquals(buildProperties, compareProperties);
	}
	
}
