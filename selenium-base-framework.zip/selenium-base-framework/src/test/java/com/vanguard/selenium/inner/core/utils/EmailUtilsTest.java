/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/EmailUtilsTest.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
*/
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Properties;

import org.junit.Test;

import com.vanguard.selenium.inner.core.utils.EmailUtils;

public class EmailUtilsTest {
    
    String test = "test email";
    
    @Test
    public void sendEmailPassTest(){
        assertTrue(EmailUtils.sendEmail("fake-email@vanguard.com", test, test));
    }
    
    @Test
    public void sendEmailFail1Test(){
        assertFalse(EmailUtils.sendEmail("bad-email@google.com", test, test));
    }
    
    @Test
    public void sendEmailFail2Test(){
        Properties properties = System.getProperties();
        properties.setProperty("fake.smtp.host", "mailwsd.vanguard.com");
        assertFalse(EmailUtils.sendEmail("bad-email@google.com", test, test));
    }

}
