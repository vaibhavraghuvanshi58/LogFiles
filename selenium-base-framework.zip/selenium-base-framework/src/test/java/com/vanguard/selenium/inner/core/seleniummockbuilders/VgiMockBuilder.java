/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/VgiMockBuilder.java $
 $LastChangedRevision: 349 $
 $Author: unyt $
 $LastChangedDate: 2013-12-06 10:53:16 -0500 (Fri, 06 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.easymock.IExpectationSetters;

/**
 * @author utcl
 *
 */
public abstract class VgiMockBuilder<T> {

    protected T mock;
    protected List<VgiMockBuilder<?>> childBuilders = new ArrayList<VgiMockBuilder<?>>();
    protected VgiMockBuilder<?> parentBuilder;
    protected boolean isRecording = true;

    protected void addChildBuilder(VgiMockBuilder<?> nestedBuilder) {
        childBuilders.add(nestedBuilder);
    }

    public VgiMockBuilder(Class<T> classToMock) {
        mock = EasyMock.createMock(classToMock);
    }

    public <M extends VgiMockBuilder<?>> VgiMockBuilder(Class<T> classToMock, M parentBuilder) {
        mock = EasyMock.createMock(classToMock);
        this.parentBuilder = parentBuilder;
    }

	@SuppressWarnings("unchecked")
	protected <X extends VgiMockBuilder<T>, M> MockBuilderExpectationSetter<X, M> chain(IExpectationSetters<M> expectationSetters) {
        return new BasicMockBuilderExpectationSetter<X, M>((X) this, expectationSetters);
    }

	@SuppressWarnings("unchecked")
	protected <X extends VgiMockBuilder<T>, M, Z extends VgiMockBuilder<M>> NestedMockBuilderExpectationSetter<X, M, Z> chainNestedMock(IExpectationSetters<M> expectationSetters, Z nestedBuilder) {
        return new NestedMockBuilderExpectationSetter<X, M, Z>((X) this, expectationSetters, nestedBuilder);
    }

    public T getMock() {
        return mock;
    }

    /**
     * Executes replay on all mocks built within the MockBuilder tree including parents and children.
     * Returns the mock associated with the builder buildMockTree was originally called on.
     * @return
     */
    public T buildMockTree() {
        EasyMock.replay(mock);
        isRecording = false;

        for(final VgiMockBuilder<?> mockBuilder : childBuilders) {
            if(mockBuilder.isRecording()) {
                mockBuilder.buildMockTree();
            }
        }

        if(!isParentNull() && parentBuilder.isRecording()) {
            parentBuilder.buildMockTree();
        }

        return mock;
    }

    protected boolean isRecording() {
        return isRecording;
    }

    private boolean isParentNull() {
        return parentBuilder == null;
    }

    protected <M extends VgiMockBuilder<?>> void setParentBuilder(M parentBuilder) {
        this.parentBuilder = parentBuilder;
    }

}