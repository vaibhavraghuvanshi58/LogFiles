/*
 ****************************************************************************
 *
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/FrameworkEndToEndTest.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.Cookie;

import com.vanguard.selenium.inner.core.pages.ExamplePageObject;
import com.vanguard.selenium.inner.core.pages.ExamplePageObject.PersonalInvestorPage;

public class FrameworkEndToEndTest extends VanguardBaseTest{

    //Run 1 "End-to-End" test to make sure the entire Framework is working successfully
    //Validate VanguardBaseTest correctly hooks to properties files and the browser gets launched
    //Site is successfully navigated to and links can be clicked.
	@Test
	public void verifyPersonalInvestorPageLoadsTest() {
	    ExamplePageObject examplePage = new ExamplePageObject(driver);
	    examplePage.navigateToPage();
		PersonalInvestorPage personalInvestorPage = examplePage.clickPersonalInvestorLink();
		Assert.assertTrue("Personal Investor Page should be loaded within 10 seconds", personalInvestorPage.isCurrentlyLoaded());
	}
	
	@Test
	public void verifyFullAuthenitcationTest() {
	    new VgiAuthenticatedWebDriver(driver, AuthenticationServiceTest.VALID_USERNAME, AuthenticationServiceTest.VALID_PASSWORD);
	    Set<Cookie> cookies = driver.manage().getCookies();
	    boolean cookieFound = false;
	    for (Cookie cookie : cookies) {
	        if( "VGSESSION".equalsIgnoreCase(cookie.getName()) ) {
	            cookieFound = true;
	            break;
	        }
	    }
	    
	    Assert.assertTrue("VGSESSION cookie not found in list", cookieFound);
	}
	
}



