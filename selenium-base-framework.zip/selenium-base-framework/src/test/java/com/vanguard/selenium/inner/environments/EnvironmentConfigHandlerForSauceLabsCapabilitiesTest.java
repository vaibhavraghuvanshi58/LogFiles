package com.vanguard.selenium.inner.environments;

import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import com.vanguard.selenium.inner.base.DriverFactory;
import com.vanguard.selenium.inner.base.PropertiesManager;


public class EnvironmentConfigHandlerForSauceLabsCapabilitiesTest {

    EnvironmentConfigHandlerForSauceLabsCapabilities sauceLabsCapabilitiesHandler;
    private static final String SAUCELABS_ROOT_GRID_URL = "http://VanguardRoot:553e6d44-d40b-4f2e-bcb9-e9e15cd97ec5@dvlna088.vanguard.com:4444/wd/hub";
    private static final String SAUCELABS_NON_ROOT_GRID_URL = "http://uz0s:xxxxxx-xxxxxxxxx-xxxx-xxxxxx@dvlna088.vanguard.com:4444/wd/hub";
    
    @Rule 
    public TestName name = new TestName();
    
    private PropertiesManager propertiesManager = new PropertiesManager();
    
    @After
    public void teardown() {
        reInitializeProperties();
    }
    
    @Test
    public void testSetSauceLabsCapabilitiesWhenRunningOnSauce() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability("name", name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        sauceLabsCapabilitiesHandler = new EnvironmentConfigHandlerForSauceLabsCapabilities(name.getMethodName());
        EnvironmentConfiguration actualEnvironment = sauceLabsCapabilitiesHandler.handleRequest(expectedEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testDoNotSetSauceLabsCapabilitiesWhenNotRunningOnSauce() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, DriverFactory.IN_HOUSE_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        sauceLabsCapabilitiesHandler = new EnvironmentConfigHandlerForSauceLabsCapabilities(name.getMethodName());
        EnvironmentConfiguration actualEnvironment = sauceLabsCapabilitiesHandler.handleRequest(expectedEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    @Test
    public void testSetParentTunnelWhenGridUrlDoesNotIncludeSauceRootUser() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_NON_ROOT_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.PARENT_TUNNEL, EnvironmentConfiguration.SAUCE_ROOT_ACCT_NAME);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        sauceLabsCapabilitiesHandler = new EnvironmentConfigHandlerForSauceLabsCapabilities(name.getMethodName());
        EnvironmentConfiguration actualEnvironment = sauceLabsCapabilitiesHandler.handleRequest(expectedEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testDoNotSetParentTunnelWhenGridUrlDoesIncludeSauceRootUser() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        sauceLabsCapabilitiesHandler = new EnvironmentConfigHandlerForSauceLabsCapabilities(name.getMethodName());
        EnvironmentConfiguration actualEnvironment = sauceLabsCapabilitiesHandler.handleRequest(expectedEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingIdleTimeout() throws NoSuchMethodException, SecurityException {
    	String validIdleTimeoutValue = "100";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.IDLE_TIMEOUT, validIdleTimeoutValue);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, validIdleTimeoutValue);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test(expected=RuntimeException.class)
    public void testSetSauceLabsSpecicDesiredCapabilitiesThrowsRuntimeExceptionWhenSettingIdleTimeoutToSomethingNonParsable() throws NoSuchMethodException, SecurityException {
    	String nonParsableIdleTimeout = "anyNonIntegerString";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.IDLE_TIMEOUT, nonParsableIdleTimeout);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, nonParsableIdleTimeout);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingScreenResolution() {
    	String screenResolution = "1920x1080";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SCREEN_RESOLUTION, screenResolution);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, screenResolution);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test(expected=RuntimeException.class)
    public void testSetSauceLabsSpecicDesiredCapabilitiesThrowsRuntimeExceptionWhenSettingScreenResolutionToInvalidValue() {
    	String badScreenResolution = "anyStringNotConformingTo#x#";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SCREEN_RESOLUTION, badScreenResolution);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, badScreenResolution);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingTags() {
    	String tags = "tag1,tag2,tag3";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, tags);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    public void testIsValidIdleTimeoutValueIsTrueFor1000() {
    	Assert.assertTrue(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidIdleTimeoutValue("1000"));
    }
    @Test
    public void testIsValidIdleTimeoutValueIsFalseFor1001() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidIdleTimeoutValue("1001"));
    }
    @Test
    public void testIsValidIdleTimeoutValueIsTrueFor0() {
    	Assert.assertTrue(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidIdleTimeoutValue("0"));
    }
    @Test
    public void testIsValidIdleTimeoutValueIsFalseForNegative1() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidIdleTimeoutValue("-1"));
    }
    @Test
    public void testIsValidIdleTimeoutValueIsFalseWhenNotParsable() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidIdleTimeoutValue("nonParsableString"));
    }

    @Test
    public void testIsValidScreenResolutionIsTrueFor1280x1024() {
    	Assert.assertTrue(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidScreenResolution("1280x1024"));
    }
    @Test
    public void testIsValidScreenResolutionIsFalseFor1280_1024() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidScreenResolution("1280_1024"));
    }
    @Test
    public void testIsValidScreenResolutionIsFalseFor1280x() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidScreenResolution("1280x"));
    }
    @Test
    public void testIsValidScreenResolutionIsFalseForAx1080() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidScreenResolution("Ax1080"));
    }
    @Test
    public void testIsValidScreenResolutionIsFalseFor1920xB() {
    	Assert.assertFalse(EnvironmentConfigHandlerForSauceLabsCapabilities.isValidScreenResolution("1920xB"));
    }

    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenNOTSettingAnySauceProperties() throws NoSuchMethodException, SecurityException {
    	EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
    	JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
    	
    	EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
    	EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
    	
    	Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingRecordVideo() throws NoSuchMethodException, SecurityException {
    	String recordVideoValue = "true";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SHOULD_RECORD_VIDEO, recordVideoValue);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SHOULD_RECORD_VIDEO, recordVideoValue);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingRecordSnapshots() throws NoSuchMethodException, SecurityException {
    	String recordSnapshotsValue = "false";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SHOULD_RECORD_SNAPSHOTS, recordSnapshotsValue);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SHOULD_RECORD_SNAPSHOTS, recordSnapshotsValue);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingSeleiumVersion() {
    	String seleniumVersion = "3.3.1";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SELENIUM_VERSION, seleniumVersion);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SELENIUM_VERSION, seleniumVersion);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingBuildLabel() {
    	String buildLabel = "myProjectName_myVersion";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, buildLabel);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, buildLabel);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingTimeZone() {
    	String timeZone = "London";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.TIME_ZONE, timeZone);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.TIME_ZONE, timeZone);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingChromeDriverVersionWhenUsingChrome() {
    	String chromeDriverVersion = "2.41.0";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.CHROME_DRIVER_VERSION, chromeDriverVersion);
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.CHROME_DRIVER_VERSION, chromeDriverVersion);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new ChromeConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSauceLabsSpecicDesiredCapabilitiesNOTUpdatedWhenSettingChromeDriverVersionWhenNOTUsingChrome() {
    	String chromeDriverVersion = "2.41.0";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.CHROME_DRIVER_VERSION, chromeDriverVersion);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    @Test
    public void testSetSauceLabsSpecicDesiredCapabilitiesWhenSettingIEDriverVersionWhenUsingIE() {
    	String ieDriverVersion = "1.34.0";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.IE_DRIVER_VERSION, ieDriverVersion);
        EnvironmentConfiguration expectedEnvironment = new InternetExplorerConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.IE_DRIVER_VERSION, ieDriverVersion);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new InternetExplorerConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testSauceLabsSpecicDesiredCapabilitiesNOTUpdatedWhenSettingIEDriverVersionWhenNOTUsingIE() {
    	String ieDriverVersion = "1.34.0";
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.IE_DRIVER_VERSION, ieDriverVersion);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = new FirefoxConfiguration();
        EnvironmentConfigHandlerForSauceLabsCapabilities.setSauceLabsSpecicDesiredCapabilities(actualEnvironment);
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}