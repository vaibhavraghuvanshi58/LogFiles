/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/environments/BrowserTypeTest.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
 */
package com.vanguard.selenium.inner.environments;

import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;

public class BrowserTypeTest {

    private PropertiesManager propertiesManager = new PropertiesManager();
    
    private EnvironmentConfiguration defaultEnvironment = new FirefoxConfiguration();
    @Rule public TestName testName = new TestName();
    
    @After
    public void teardown() {
        reInitializeProperties();
    }
    
    @Test
    public void getBrowserTypeFirefoxTest() {
        BrowserType expectedBrowserType = BrowserType.FIREFOX;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Firefox");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeChromeTest() {
        BrowserType expectedBrowserType = BrowserType.CHROME;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Chrome");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeGoogleChromeTest() {
        BrowserType expectedBrowserType = BrowserType.CHROME;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "GoogleChrome");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeGoogle_ChromeTest() {
        BrowserType expectedBrowserType = BrowserType.CHROME;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Google_Chrome");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeIETest() {
        BrowserType expectedBrowserType = BrowserType.INTERNET_EXPLORER;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "IE");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeInternet_ExplorerTest() {
        BrowserType expectedBrowserType = BrowserType.INTERNET_EXPLORER;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Internet_Explorer");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeInternetExplorerTest() {
        BrowserType expectedBrowserType = BrowserType.INTERNET_EXPLORER;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "InternetExplorer");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeEdgeTest() {
        BrowserType expectedBrowserType = BrowserType.EDGE;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Edge");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeMS_EdgeTest() {
        BrowserType expectedBrowserType = BrowserType.EDGE;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "MS_Edge");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeMicrosoft_EdgeTest() {
        BrowserType expectedBrowserType = BrowserType.EDGE;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Microsoft_Edge");
        BrowserType actualBrowserTYpe = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserTYpe);
    }
    @Test
    public void getBrowserTypeMicrosoftEdgeTest() {
        BrowserType expectedBrowserType = BrowserType.EDGE;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "MicrosoftEdge");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeSafariTest() {
        BrowserType expectedBrowserType = BrowserType.SAFARI;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Safari");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeAppleSafariTest() {
        BrowserType expectedBrowserType = BrowserType.SAFARI;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "AppleSafari");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeApple_SafariTest() {
        BrowserType expectedBrowserType = BrowserType.SAFARI;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Apple_Safari");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeOperaTest() {
        BrowserType expectedBrowserType = BrowserType.OPERA;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Opera");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeIPhoneTest() {
        BrowserType expectedBrowserType = BrowserType.IPHONE;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "iPhone");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeIPadTest() {
        BrowserType expectedBrowserType = BrowserType.IPAD;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "iPad");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }
    @Test
    public void getBrowserTypeAndroidTest() {
        BrowserType expectedBrowserType = BrowserType.ANDROID;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Android");
        BrowserType actualBrowserTYpe = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserTYpe);
    }
    @Test
    public void getBrowserTypeInvalidWillReturnFirefoxTest() {
        BrowserType expectedBrowserType = BrowserType.FIREFOX;
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Invalid_Selection");
        BrowserType actualBrowserType = BrowserType.getBrowserTypeFromPropertiesFile();
        Assert.assertEquals(expectedBrowserType, actualBrowserType);
    }

    
    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e){
            LoggingUtility.logError(e.getMessage());
        }
    }
}
