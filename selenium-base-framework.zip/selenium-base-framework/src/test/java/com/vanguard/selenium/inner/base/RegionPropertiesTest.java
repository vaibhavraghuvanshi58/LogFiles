/*
 ****************************************************************************
 * 
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/RegionPropertiesTest.java $
 $LastChangedRevision: 1758 $
 $Author: uz0s $
 $LastChangedDate: 2015-09-02 16:30:15 -0400 (Wed, 02 Sep 2015) $
*/
package com.vanguard.selenium.inner.base;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author uesr
 *
 */
public class RegionPropertiesTest {
    
    @Test
    public void testGetRegionFilename() {
        assertTrue("File name not correct!", RegionProperties.DEFAULT.getRegionFileName().equals("defaults.properties"));
        assertTrue("File name not correct!", RegionProperties.E.getRegionFileName().equals("e_region.properties"));
        assertTrue("File name not correct!", RegionProperties.F.getRegionFileName().equals("f_region.properties"));
        assertTrue("File name not correct!", RegionProperties.X.getRegionFileName().equals("x_region.properties"));
        assertTrue("File name not correct!", RegionProperties.M.getRegionFileName().equals("m_region.properties"));
        assertTrue("File name not correct!", RegionProperties.P.getRegionFileName().equals("p_region.properties"));
        assertTrue("File name not correct!", RegionProperties.S.getRegionFileName().equals("s_region.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_DEFAULT.getRegionFileName().equals("regionConfig.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_E.getRegionFileName().equals("regionConfig_e.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_F.getRegionFileName().equals("regionConfig_f.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_X.getRegionFileName().equals("regionConfig_x.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_M.getRegionFileName().equals("regionConfig_m.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_P.getRegionFileName().equals("regionConfig_p.properties"));
        assertTrue("File name not correct!", RegionProperties.REGRESSION_MULTIMODULE_S.getRegionFileName().equals("regionConfig_s.properties"));
    }
    
    @Test
    public void testToString() {
        assertEquals("toString is wrong!", "e_region.properties", RegionProperties.E.toString());
    }
    
    @Test
    public void testFromRegionString() {
        assertEquals(RegionProperties.DEFAULT, RegionProperties.fromRegionString("default"));
        assertEquals(RegionProperties.DEFAULT, RegionProperties.fromRegionString("DeFaUlT"));
        
        assertEquals(RegionProperties.E, RegionProperties.fromRegionString("e"));
        assertEquals(RegionProperties.E, RegionProperties.fromRegionString("E"));
    }
 
    @Test
    public void testCorrectIsClassPathValues() {
        assertEquals(false, RegionProperties.DEFAULT.isClassPathFile());
        assertEquals(false, RegionProperties.E.isClassPathFile());
        assertEquals(true, RegionProperties.REGRESSION_MULTIMODULE_DEFAULT.isClassPathFile());
        assertEquals(true, RegionProperties.REGRESSION_MULTIMODULE_X.isClassPathFile());
    }
 
    @Test
    public void testCorrectOverrideFileBasedOnRegionFile() {
        assertEquals(RegionProperties.REGRESSION_MULTIMODULE_DEFAULT, RegionProperties.DEFAULT.determinOverrideFileBasedOnRegionFile());
        assertEquals(RegionProperties.REGRESSION_MULTIMODULE_E, RegionProperties.E.determinOverrideFileBasedOnRegionFile());
        assertEquals(RegionProperties.REGRESSION_MULTIMODULE_F, RegionProperties.F.determinOverrideFileBasedOnRegionFile());
        assertEquals(RegionProperties.REGRESSION_MULTIMODULE_S, RegionProperties.S.determinOverrideFileBasedOnRegionFile());
        assertEquals(null, RegionProperties.REGRESSION_MULTIMODULE_DEFAULT.determinOverrideFileBasedOnRegionFile());
        assertEquals(null, RegionProperties.REGRESSION_MULTIMODULE_F.determinOverrideFileBasedOnRegionFile());
    }

}
