/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/HttpClientAuthenticatorTest.java $
 $LastChangedRevision: 682 $
 $Author: uz0s $
 $LastChangedDate: 2014-09-04 12:24:48 -0400 (Thu, 04 Sep 2014) $
 */
package com.vanguard.selenium.inner.base;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.client.CookieStore;
import org.apache.http.cookie.Cookie;
import org.junit.Before;
import org.junit.Test;

/**
 * @author utcl
 *
 */
public class HttpClientAuthenticatorTest {

    private static final String COOKIE_PATH = "expectedPath";
    private static final String COOKIE_DOMAIN = "expectedDomain";
    private static final String COOKIE_NAME = "expectedName";
    private static final String COOKIE_VALUE = "expectedValue";
    private HttpClientAuthenticator clientAuthenticator;

    @Before
    public void setup() {
        clientAuthenticator = new HttpClientAuthenticator();
    }

    @Test
    public void givenClientHasNullCookiesWhenTranslatingToSeleniumCookiesThenNoCookiesAssignedToclientAuthenticator() throws Exception {

        CookieStore cookieStoreMock = buildCookieStoreMockWithCookies(null);
        
        List<org.openqa.selenium.Cookie> seleniumCookies = clientAuthenticator.translateClientCookiesIntoSeleniumCookies(cookieStoreMock);

        assertEquals(null, seleniumCookies);
    }

    @Test
    public void givenClientHasEmptyCookiesWhenTranslatingToSeleniumCookiesThenNoCookiesAssignedToclientAuthenticator() throws Exception {
        List<Cookie> cookies = new ArrayList<Cookie>();

        CookieStore cookieStoreMock = buildCookieStoreMockWithCookies(cookies);

        List<org.openqa.selenium.Cookie> seleniumCookies = clientAuthenticator.translateClientCookiesIntoSeleniumCookies(cookieStoreMock);

        assertEquals(null, seleniumCookies);
    }

    @Test
    public void givenClientHasSingleCookieWhenTranslatingToSeleniumCookiesThenSeleniumCookieMatchesNameValueDomainPathDateAndSecurityIsAssignedToclientAuthenticator() throws Exception {
        List<Cookie> cookies = new ArrayList<Cookie>();
        Cookie mockCookie = buildDefaultMockCookie();
        cookies.add(mockCookie);
        CookieStore cookieStoreMock = buildCookieStoreMockWithCookies(cookies);

        List<org.openqa.selenium.Cookie> seleniumCookies =  clientAuthenticator.translateClientCookiesIntoSeleniumCookies(cookieStoreMock);

        assertEquals(1, seleniumCookies.size());

        org.openqa.selenium.Cookie seleniumCookie = seleniumCookies.get(0);
        verifySeleniumCookieHasDefaultValues(seleniumCookie);
    }

    @Test
    public void givenClientHasMultipleCookiesWhenTranslatingToSeleniumCookiesThenAllCookiesTranslatedToclientAuthenticator() throws Exception {
        List<Cookie> cookies = new ArrayList<Cookie>();
        Cookie mockCookie1 = buildDefaultMockCookie();
        cookies.add(mockCookie1);
        Cookie mockCookie2 = buildDefaultMockCookie();
        cookies.add(mockCookie2);
        CookieStore cookieStoreMock = buildCookieStoreMockWithCookies(cookies);

        List<org.openqa.selenium.Cookie> seleniumCookies = clientAuthenticator.translateClientCookiesIntoSeleniumCookies(cookieStoreMock);

        assertEquals(2, seleniumCookies.size());

        org.openqa.selenium.Cookie seleniumCookie = seleniumCookies.get(0);
        verifySeleniumCookieHasDefaultValues(seleniumCookie);
    }

    

    private void verifySeleniumCookieHasDefaultValues(org.openqa.selenium.Cookie seleniumCookie) {
        assertEquals(COOKIE_NAME, seleniumCookie.getName());
        assertEquals(COOKIE_VALUE, seleniumCookie.getValue());
        assertEquals(COOKIE_DOMAIN, seleniumCookie.getDomain());
        assertEquals(COOKIE_PATH, seleniumCookie.getPath());
        assertEquals(true, seleniumCookie.isSecure());
    }

    private Cookie buildDefaultMockCookie() {
        Cookie mockCookie = createMock(Cookie.class);
        expect(mockCookie.getName()).andReturn(COOKIE_NAME);
        expect(mockCookie.getValue()).andReturn(COOKIE_VALUE);
        expect(mockCookie.getDomain()).andReturn(COOKIE_DOMAIN);
        expect(mockCookie.getPath()).andReturn(COOKIE_PATH);
        expect(mockCookie.getExpiryDate()).andReturn(createMock(Date.class));
        expect(mockCookie.isSecure()).andReturn(true);
        replay(mockCookie);
        return mockCookie;
    }

    private CookieStore buildCookieStoreMockWithCookies(List<Cookie> cookies) {
        CookieStore cookieStoreMock = createMock(CookieStore.class);
        expect(cookieStoreMock.getCookies()).andReturn(cookies);
        replay(cookieStoreMock);
        return cookieStoreMock;
    }

}
