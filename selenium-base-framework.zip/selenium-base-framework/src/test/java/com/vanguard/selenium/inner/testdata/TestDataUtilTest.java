/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/testdata/TestDataUtilTest.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
 */
package com.vanguard.selenium.inner.testdata;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import org.junit.Test;

/**
 * @author utcl
 *
 */
public class TestDataUtilTest {

    /**
     * 
     */
    private static final String ANY_ATTRIBUTE = "anyAttribute";
    /**
     * 
     */
    private static final String ANY_UID = "uuuu";
    private static final String TEST_CASE_NAME = "testCaseName";

    @Test
    public void givenNullTestCaseWhenGettingDataThenReturnNull() throws Exception {
        TestData actualTestData = TestDataUtil.getTestData(null, "");
        assertEquals(null, actualTestData);
    }

    @Test
    public void givenTestCaseWithNoDataWhenGettingDataThenReturnNull() throws Exception {
        TestData actualTestData = TestDataUtil.getTestData(new TestCase(), "");
        assertEquals(null, actualTestData);
    }

    @Test
    public void givenTestDataThatDoesNotMatchTestNameWhenGettingDataThenDontReturnData() throws Exception {
        TestData mockData = buildMockDataWithName("won'tmatch");

        List<TestData> testDatas = new ArrayList<TestData>();
        testDatas.add(mockData);

        TestCase mockTestCase = buildMockTestCaseWithData(testDatas);

        TestData actualTestData = TestDataUtil.getTestData(mockTestCase, TEST_CASE_NAME);

        assertEquals(null, actualTestData);
    }

    @Test
    public void givenTestDataThatMatchesTestNameWhenGettingDataThenReturnData() throws Exception {
        TestData mockData = buildMockDataWithName(TEST_CASE_NAME);

        List<TestData> testDatas = new ArrayList<TestData>();
        testDatas.add(mockData);

        TestCase mockTestCase = buildMockTestCaseWithData(testDatas);

        TestData actualTestData = TestDataUtil.getTestData(mockTestCase, TEST_CASE_NAME);

        assertEquals(mockData, actualTestData);
    }

    @Test
    public void givenMultipleTestDataWithOneMatchingNameWhenGettingDataThenReturnMatchedData() throws Exception {
        TestData mockData = buildMockDataWithName("won'tmatch");
        TestData mockData2 = buildMockDataWithName(TEST_CASE_NAME);

        List<TestData> testDatas = new ArrayList<TestData>();
        testDatas.add(mockData);
        testDatas.add(mockData2);

        TestCase mockTestCase = buildMockTestCaseWithData(testDatas);

        TestData actualTestData = TestDataUtil.getTestData(mockTestCase, TEST_CASE_NAME);

        assertEquals(mockData2, actualTestData);
    }

    @Test
    public void givenNullTestDataAndEmptyAttributesOnTestCaseWhenGettingDataValueOtherThanUserIdThenReturnNull() throws Exception {
        TestCase mockTestCase = new TestCase();
        mockTestCase.setTestData(new ArrayList<TestData>());
        mockTestCase.setOtherAttributes(new HashMap<QName, String>());
        String actualValue = TestDataUtil.getTestDataValue(mockTestCase, TEST_CASE_NAME, "notUserId");

        assertEquals(null, actualValue);
    }

    @Test
    public void givenNullTestDataAndEmptyAttributesOnTestCaseWhenGettingUserIdThenReturnTestCaseUid() throws Exception {
        TestCase mockTestCase = new TestCase();
        mockTestCase.setTestData(new ArrayList<TestData>());
        mockTestCase.setUserID(ANY_UID);
        String actualValue = TestDataUtil.getTestDataValue(mockTestCase, TEST_CASE_NAME, TestDataUtil.USER_ID);

        assertEquals(ANY_UID, actualValue);
    }

    @Test
    public void givenAttributeMapWithoutMatchingNameWhenGettingValueThenReturnNull() throws Exception {
        QName qName = new QName("notMatchingAttribute");
        Map<QName, String> attributeMap = new HashMap<QName, String>();
        attributeMap.put(qName, "anyValue");

        String actualValue = TestDataUtil.getAttributeValue(attributeMap, ANY_ATTRIBUTE);

        assertEquals(null, actualValue);
    }

    @Test
    public void givenAttributeMapWithMatchingNameWhenGettingValueThenReturnValue() throws Exception {
        QName qName = new QName(ANY_ATTRIBUTE);
        Map<QName, String> attributeMap = new HashMap<QName, String>();
        String expectedValue = "expectedValue";
        attributeMap.put(qName, expectedValue);

        String actualValue = TestDataUtil.getAttributeValue(attributeMap, ANY_ATTRIBUTE);

        assertEquals(expectedValue, actualValue);
    }

    private TestCase buildMockTestCaseWithData(List<TestData> testDatas) {
        TestCase mockTestCase = new TestCase();
        mockTestCase.setTestData(testDatas);
        return mockTestCase;
    }

    private TestData buildMockDataWithName(String testCaseName) {
        TestData mockData = new TestData();
        mockData.setName(testCaseName);
        return mockData;
    }
}
