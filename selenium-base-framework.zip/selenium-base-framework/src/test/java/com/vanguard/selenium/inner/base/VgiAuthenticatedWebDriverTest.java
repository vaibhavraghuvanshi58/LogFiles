/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/VgiAuthenticatedWebDriverTest.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
*/
package com.vanguard.selenium.inner.base;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Timeouts;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.vanguard.selenium.inner.base.AuthenticationService.StatusMessageContainer;

/**
 * @author uc4b
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(AuthenticationService.class)
public class VgiAuthenticatedWebDriverTest {
    
    @Test
    public void testAuthenticationFailsMaximumNumberOfRetries() throws IOException {
        String username = "username";
        String password = "password";
        
        PowerMockito.mockStatic(AuthenticationService.class);
        AuthenticationService authenticationService = Mockito.mock(AuthenticationService.class);
        Mockito.when(AuthenticationService.getInstance()).thenReturn(authenticationService);
        
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,username,password)).thenThrow(new SocketTimeoutException());//.the
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.DEV,username,password)).thenThrow(new SocketTimeoutException());
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.INT,username,password)).thenThrow(new SocketTimeoutException());
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.CAT,username,password)).thenThrow(new SocketTimeoutException());
        VgiAuthenticatedWebDriver vgiAuthenticatedWebDriverSUT = new VgiAuthenticatedWebDriver();
        vgiAuthenticatedWebDriverSUT.setAuthenticationService(authenticationService);
        boolean exceptionThrown = false;
        try {
            //had to do this otherwise couldn't get to the verify which is important for this test
            vgiAuthenticatedWebDriverSUT.authenticate(username, password);
        }catch (SeleniumAuthenticationException e) {
            exceptionThrown = true;
        }
        
        Assert.assertTrue("Exception should have been thrown, but wasn't ",  exceptionThrown);
        
        Mockito.verify(authenticationService,Mockito.times(3)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT, username, password);
        Mockito.verify(authenticationService,Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.CAT, username, password);
        Mockito.verify(authenticationService,Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.INT, username, password);
        Mockito.verify(authenticationService,Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.DEV, username, password);
        PowerMockito.verifyStatic(Mockito.times(8));
        AuthenticationService.getInstance();
    }
    
    //
    @Test
    public void testAuthenticationDoesntThrowException() throws IOException {
        String username = "username";
        String password = "password";
        
        PowerMockito.mockStatic(AuthenticationService.class);
        AuthenticationService authenticationService = Mockito.mock(AuthenticationService.class);
        Mockito.when(AuthenticationService.getInstance()).thenReturn(authenticationService);
        
        JSONObject returnJsonObject = new JSONObject();
        StatusMessageContainer returnJsonResponse =  authenticationService.new StatusMessageContainer("message", AuthenticationService.SUCCESSFUL_STATUS);
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,username,password)).thenReturn(returnJsonObject);
        
        Mockito.when(authenticationService.getJSONResponseFromJSONOject(returnJsonObject)).thenReturn(returnJsonResponse);
        
        VgiAuthenticatedWebDriver vgiAuthenticatedWebDriverSUT = new VgiAuthenticatedWebDriver();
        vgiAuthenticatedWebDriverSUT.setAuthenticationService(authenticationService);
        
        //authentication through a void method... can only verify this.
        vgiAuthenticatedWebDriverSUT.authenticate( username, password);
        Mockito.verify(authenticationService,Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT, username, password);
        PowerMockito.verifyStatic(Mockito.times(8));
       
    }
    
    @Test 
    public void testProperlyAuthenticatesAndSetsCookiesOnWebdriver() throws IOException {
        String username = "username";
        String password = "password";
        WebDriver driver = Mockito.mock(WebDriver.class);
        
             
        PowerMockito.mockStatic(AuthenticationService.class);
        AuthenticationService authenticationService = Mockito.mock(AuthenticationService.class);
        Mockito.when(AuthenticationService.getInstance()).thenReturn(authenticationService);
        
        JSONObject returnJsonObject = new JSONObject();
        StatusMessageContainer returnJsonResponse =  authenticationService.new StatusMessageContainer("message", AuthenticationService.SUCCESSFUL_STATUS);
        
        Mockito.when(authenticationService.getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,username,password)).thenReturn(returnJsonObject);
        
        Mockito.when(authenticationService.getJSONResponseFromJSONOject(returnJsonObject)).thenReturn(returnJsonResponse);
        
        List<Cookie> returnCookies = new ArrayList<Cookie>();
        CookieService cookieService = Mockito.mock(CookieService.class);
        Mockito.when(cookieService.getCookies(returnJsonObject)).thenReturn(returnCookies);
        
        VgiAuthenticatedWebDriver vgiAuthenticatedWebDriver = new VgiAuthenticatedWebDriver();
        vgiAuthenticatedWebDriver.setAuthenticationService(authenticationService);
        vgiAuthenticatedWebDriver.setCookieService(cookieService);
        vgiAuthenticatedWebDriver.constuctAuthenticatedWebDriver(driver, username, password);
        
        Mockito.verify(authenticationService, Mockito.times(1)).getPOSTAuthenticationRequestResponse(AuthenticationUrl.SAT,username, password);
        Mockito.verify(authenticationService, Mockito.times(1)).verifyValidInputs(username, password);
        Mockito.verify(authenticationService, Mockito.times(1)).navigateToAVanguardDomainSite(driver);
        Mockito.verify(cookieService,Mockito.times(1)).addAllCookiesToDriver(driver, returnCookies);
    }
    
    @Test
    public void SMOKE_testFullAuthentication() {
        WebDriver driver = Mockito.mock(WebDriver.class);
        
        Options options = Mockito.mock(Options.class);
        Mockito.when(driver.manage()).thenReturn(options);
        
        Timeouts timeouts = Mockito.mock(Timeouts.class);
        Mockito.when(options.timeouts()).thenReturn(timeouts);
        
        Timeouts returnTimeouts = Mockito.mock(Timeouts.class);
        Mockito.when(timeouts.pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        Mockito.when(timeouts.pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS)).thenReturn(returnTimeouts);
        
        new VgiAuthenticatedWebDriver(driver, AuthenticationServiceTest.VALID_USERNAME , AuthenticationServiceTest.VALID_PASSWORD);
        
        Mockito.verify(driver,Mockito.times(3)).manage();
        Mockito.verify(driver,Mockito.times(1)).get(AuthenticationService.SAT_INTERNAL_VANGUARD_DOMAIN);
        Mockito.verify(options,Mockito.times(2)).timeouts();
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(timeouts,Mockito.times(1)).pageLoadTimeout(AuthenticationService.GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
        Mockito.verify(options,Mockito.times(1)).addCookie((Cookie)Mockito.any());;
    }
    
}
