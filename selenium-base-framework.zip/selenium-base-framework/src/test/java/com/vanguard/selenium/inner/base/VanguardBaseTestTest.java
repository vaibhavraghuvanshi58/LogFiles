package com.vanguard.selenium.inner.base;

import java.lang.reflect.Method;

import org.junit.After;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import com.vanguard.selenium.inner.core.utils.DriverUtils;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.environments.AndroidConfiguration;
import com.vanguard.selenium.inner.environments.BrowserType;
import com.vanguard.selenium.inner.environments.ChromeConfiguration;
import com.vanguard.selenium.inner.environments.EnvironmentConfiguration;
import com.vanguard.selenium.inner.environments.FirefoxConfiguration;
import com.vanguard.selenium.inner.environments.IPadConfiguration;
import com.vanguard.selenium.inner.environments.InternetExplorerConfiguration;
import com.vanguard.selenium.inner.environments.JenkinsBuildPropertiesService;
import com.vanguard.selenium.inner.environments.MobileConfiguration;
import com.vanguard.selenium.inner.environments.OperaConfiguration;
import com.vanguard.selenium.inner.environments.SafariConfiguration;


public class VanguardBaseTestTest {

    private VanguardBaseTest baseTest = new VanguardBaseTest();
    private PropertiesManager propertiesManager = new PropertiesManager();
    private static final String SAUCELABS_GRID_URL = "http://VanguardRoot:553e6d44-d40b-4f2e-bcb9-e9e15cd97ec5@dvlna088.vanguard.com:4444/wd/hub";
    
    private EnvironmentConfiguration defaultEnvironment = new FirefoxConfiguration();
    @Rule public TestName name = new TestName();
    
    @After
    public void teardown() {
        reInitializeProperties();
    }
    
    
    @Test
    public void testGetCorrectEnvironmentConfigWithNoPropertiesAndNoAnnotation() throws NoSuchMethodException, SecurityException {
        EnvironmentConfiguration expectedEnvironment = defaultEnvironment;
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testGetCorrectEnvironmentConfigWithSpecificPropertiesAndNoAnnotation() throws NoSuchMethodException, SecurityException {
        EnvironmentConfiguration expectedEnvironment = new InternetExplorerConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "InternetExplorer");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    @EnvironmentConfigAnnotation(browserType=BrowserType.SAFARI)
    public void testGetCorrectEnvironmentConfigWithSpecificPropertiesAndSpecificAnnotationUsesTheAnnotationValue() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new SafariConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "InternetExplorer");
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    public void testGetDefaultEnvironmentConfigMatchesANewFireFoxEnvironment() {
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        EnvironmentConfiguration expectedEnvironment = defaultEnvironment;
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    public void testOverrideEnvironmentFromPropertiesFile() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Chrome");
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testNoOverrideToEnvironmentIsMadeIfNoValuesSpecifiedFromPropertiesFile() throws NoSuchMethodException, SecurityException {
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    @EnvironmentConfigAnnotation(browserType=BrowserType.OPERA)
    public void testOverrideEnvironmentFromAnnotation() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration expectedEnvironment = new OperaConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testNoOverrideToEnvironmentIsMadeIfNoValueSpecifiedFromAnnotation() throws NoSuchMethodException, SecurityException {
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    
    @Test
    public void testOverrideAllIndividualBrowserCapabilitiesFromPropertiesFile() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        String expectedBrowserVersion = "46";
        String expectedOSType = "Mac";
        String expectedChromeDriverVersion = "2.02";
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        expectedEnvironment.addCapability(EnvironmentConfiguration.VERSION, expectedBrowserVersion);
        expectedEnvironment.addCapability(EnvironmentConfiguration.PLATFORM, expectedOSType);
        expectedEnvironment.addCapability(EnvironmentConfiguration.CHROME_DRIVER_VERSION, expectedChromeDriverVersion);
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);

        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Chrome");
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_VERSION, expectedBrowserVersion);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.OS_TYPE, expectedOSType);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.CHROME_DRIVER_VERSION, expectedChromeDriverVersion);
        
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testOverrideAllIndividualMobileCapabilitiesFromPropertiesFile() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        String expectedDeviceName = "iPad Simulator";
        String expectedDeviceOrientation = "landscape";
        String expectedPlatformVersion = "10.0";
        EnvironmentConfiguration expectedEnvironment = new IPadConfiguration();
        expectedEnvironment.addCapability(MobileConfiguration.DEVICE_NAME, expectedDeviceName);
        expectedEnvironment.addCapability(MobileConfiguration.DEVICE_ORIENTATION, expectedDeviceOrientation);
        expectedEnvironment.addCapability(MobileConfiguration.PLATFORM_VERSION, expectedPlatformVersion);
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);

        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "iPad");
        PropertiesManager.setPropertyInDefaults(MobileConfiguration.DEVICE_NAME, expectedDeviceName);
        PropertiesManager.setPropertyInDefaults(MobileConfiguration.DEVICE_ORIENTATION, expectedDeviceOrientation);
        PropertiesManager.setPropertyInDefaults(MobileConfiguration.PLATFORM_VERSION, expectedPlatformVersion);
        
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testNoOverrideToIndividualCapabilitiesWhenNoPropertiesValuesAreSpecifiedAndNoAnnotationsPresent() throws NoSuchMethodException, SecurityException {
        EnvironmentConfiguration expectedEnvironment = defaultEnvironment;
        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    
    @Test
    @EnvironmentConfigAnnotation(tags="tag1,tag2")
    public void testCanOverrideJustTagsAndNothingElse() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        String fullTagList = "tag1,tag2";
        if(!DriverUtils.isWindoze()) {
        	JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        	fullTagList += "," + expectedEnvironment.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
        }
        expectedEnvironment.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, fullTagList);
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());

        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    @EnvironmentConfigAnnotation(tags="tag1,tag2", browserType=BrowserType.CHROME, browserVersion="43", osType="Windows", osVersion="7", 
    	chromeDriverVersion="2.4.1", idleTimeout="90", screenResolution="1920x1080")
    public void testOverrideAllIndividualBrowserCapabilitiesFromAnnotationOnChrome() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        String fullTagList = "tag1,tag2";
        if(!DriverUtils.isWindoze()) {
        	JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        	fullTagList += "," + expectedEnvironment.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
        }
        expectedEnvironment.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, fullTagList);
        expectedEnvironment.addCapability(EnvironmentConfiguration.VERSION, "43");
        expectedEnvironment.addCapability(EnvironmentConfiguration.PLATFORM, "Windows" + " " + "7");
        expectedEnvironment.addCapability(EnvironmentConfiguration.CHROME_DRIVER_VERSION, "2.4.1");
        expectedEnvironment.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, "90");
        expectedEnvironment.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, "1920x1080");
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());

        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    @EnvironmentConfigAnnotation(tags="tag1", browserType=BrowserType.INTERNET_EXPLORER, browserVersion="11", osType="Windows", 
    osVersion="10", ieDriverVersion="1.40.0", idleTimeout="90", screenResolution="1920x1080")
    public void testOverrideAllIndividualBrowserCapabilitiesFromAnnotationOnIE() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new InternetExplorerConfiguration();
        String fullTagList = "tag1";
        if(!DriverUtils.isWindoze()) {
        	JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        	fullTagList += "," + expectedEnvironment.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
        }
        expectedEnvironment.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, fullTagList);
        expectedEnvironment.addCapability(EnvironmentConfiguration.VERSION, "11");
        expectedEnvironment.addCapability(EnvironmentConfiguration.PLATFORM, "Windows" + " " + "10");
        expectedEnvironment.addCapability(EnvironmentConfiguration.IE_DRIVER_VERSION, "1.40.0");
        expectedEnvironment.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, "90");
        expectedEnvironment.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, "1920x1080");        
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());

        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    @EnvironmentConfigAnnotation(tags="tag", browserType=BrowserType.FIREFOX, browserVersion="53", osType="Windows", osVersion="10", chromeDriverVersion="2.4.1", ieDriverVersion="1.40.0")
    public void testNeitherChromeDriverVersionNorIEDriverVersionGetSetWhenNotUsingTheirBrowsers() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        String fullTagList = "tag";
        if(!DriverUtils.isWindoze()) {
        	JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);
        	fullTagList += "," + expectedEnvironment.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
        }
        expectedEnvironment.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, fullTagList);
        expectedEnvironment.addCapability(EnvironmentConfiguration.VERSION, "53");
        expectedEnvironment.addCapability(EnvironmentConfiguration.PLATFORM, "Windows" + " " + "10");
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        //Specifically not setting ChromeDriverVersion or IEDriverVersion to expectedEnvironent, since we expect them NOT to be set.

        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    @EnvironmentConfigAnnotation(browserType=BrowserType.ANDROID, deviceName="Samsung Galaxy S7", deviceOrientation="landscape", platformVersion="5.3")
    public void testOverrideAllIndividualMobileCapabilitiesFromAnnotation() throws NoSuchMethodException, SecurityException {
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_GRID_URL);
        EnvironmentConfiguration expectedEnvironment = new AndroidConfiguration();
        expectedEnvironment.addCapability(MobileConfiguration.DEVICE_NAME, "Samsung Galaxy S7");
        expectedEnvironment.addCapability(MobileConfiguration.DEVICE_ORIENTATION, "landscape");
        expectedEnvironment.addCapability(MobileConfiguration.PLATFORM_VERSION, "5.3");
        expectedEnvironment.addCapability(EnvironmentConfiguration.NAME_OF_TEST, name.getMethodName());
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(expectedEnvironment);

        Method method = this.getClass().getMethod((name.getMethodName()));
        EnvironmentConfiguration actualEnvironment = baseTest.getEnvironmentConfig(method, name.getMethodName());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }

    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e){
            LoggingUtility.logError(e.getMessage());
        }
    }
}