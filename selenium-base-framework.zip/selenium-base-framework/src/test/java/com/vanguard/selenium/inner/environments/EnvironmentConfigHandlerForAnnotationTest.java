package com.vanguard.selenium.inner.environments;

import java.lang.reflect.Method;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import com.vanguard.selenium.inner.base.EnvironmentConfigAnnotation;


public class EnvironmentConfigHandlerForAnnotationTest {

    EnvironmentConfigHandlerForAnnotation environmentConfigHandlerForAnnotation;
    
    @Rule 
    public TestName name = new TestName();
    
    @Test
    @EnvironmentConfigAnnotation(browserType=BrowserType.CHROME, browserVersion="53", osType="Windows", osVersion="8.1")
    public void testGetEnvironmentConfigAnnotation() throws NoSuchMethodException, SecurityException {
        Method thisTestMethod = this.getClass().getMethod(name.getMethodName());
        environmentConfigHandlerForAnnotation = new EnvironmentConfigHandlerForAnnotation(EnvironmentConfigHandler.getEnvironmentConfigAnnotationFromMethod(thisTestMethod));
        EnvironmentConfigAnnotation expectedAnnotation = thisTestMethod.getAnnotation(EnvironmentConfigAnnotation.class);
        
        EnvironmentConfigAnnotation actualAnnotation = EnvironmentConfigHandler.getEnvironmentConfigAnnotationFromMethod(thisTestMethod);
        Assert.assertEquals(expectedAnnotation, actualAnnotation);
    }

    @Test
    public void testGetEnvironmentConfigAnnotationReturnsNullWhenNoAnnotationIsPresent() throws NoSuchMethodException, SecurityException {
        Method thisTestMethod = this.getClass().getMethod(name.getMethodName());
        environmentConfigHandlerForAnnotation = new EnvironmentConfigHandlerForAnnotation(EnvironmentConfigHandler.getEnvironmentConfigAnnotationFromMethod(thisTestMethod));
        EnvironmentConfigAnnotation expectedAnnotation = null;
        
        EnvironmentConfigAnnotation actualAnnotation = EnvironmentConfigHandler.getEnvironmentConfigAnnotationFromMethod(thisTestMethod);
        Assert.assertEquals(expectedAnnotation, actualAnnotation);
    }
    
}