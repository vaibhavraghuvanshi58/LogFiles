/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/CookieServiceTest.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

import static org.junit.Assert.assertTrue;

import java.util.Date;

import org.apache.http.auth.AuthenticationException;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Cookie;

/**
 * @author uc4b
 *
 */
public class CookieServiceTest {
    
    CookieService service;
    
    @Before
    public void setup() {
        service = new CookieService();
    }
    
    @Test
    public void getCookiesWithSuccessfulLoginTest() throws JSONException, AuthenticationException {
        String SUCCESS_STATUS = "0";
        String tokenName = "VGSESSION";
        String tokenValue = "nIS39PbpeCW2S8cjvOBg8BUtDwyAPyzj7SmW1im87RLhoA3TdNK1o+CTdvoiWVWJfiiMXSpymVSLK3LZNj2vEluZqQkRRq76N+DUMsqdp1MGUEU8K4dgn8JdG6i//2m3Xc9A8l8tupmnQ23xJS/EA/4xcZFFlF+OumIW63hFmxLcPqjbka2nVgP7HUAlesUW1m60NJpCZbkhJqkCluIXecolu1o556pdr+LNgPDSF40KZv3BeFXsRmo0/LctT/DrtmtbqTrzjIQRvujHor5waoPXyuAjPW6jHeJHXub2kXMo9+XBzwSbsfJ7U57JrcDBz+dUUgHXIMC0D2CuaKDzWJG3k5qmRXJqbBfaUdgwrLQMIFLiVVD+0gYPn076i1iJdq9/tUE0gYhvK8WHAOVwagNVLmPQXTLVrAMqx4EaUS2hVhURIpJIyFzI9aZl8KX+gAIGkCQiW6WnmDkamnkSfMuwCa/IOOqaoFqkJKhzBZH1qhd/xNrv1zBjVALZtncnkvDU997Q4k6XK6yt/wThXV5xXlnV1Ocn/3i22fmk9bfgjtetTHsNSG0mR4wq8ZJnFGw42cmY4n5a6Zyjqi+vdfa1YCevkdEceia99rXcfl4Opff5aL8hC5Ih6VSz0WJos0drP04M5P45IOch8Ndib1WXcmcxX2m3OY1SfWbXHXEE01P8ot+qyeJVVy9WaRIF9+hjAX/b/O/wDLRClvGLz12r/VUQBSkU3F9TrOGBmS4/3yBfDgzfq+kxyEA4R9WU9cuurkVpWpwcB08M7Ox/HMkQi1nNB615HF1NaA2NtsRBn+pWLt8gZfw7w0IHpgwxJBQ6wRbVPyAG6YVd6dOIWzgllyA4Px2N4i7UUt41KWq8JEUvzin1pYYdEUbbN/D4LvAHvsSCBm0Oao+QA3EOpitDHRifVa1Tm9uESip0CEWBFzztv+gNow==";
        JSONObject json = new JSONObject("{\"Status\":\"" + SUCCESS_STATUS + "\",\"Operation\":\"CreateActiveDirectoryToken\",\"Message\":\"Token successfully created\",\"TokenSet\":[{\"TokenName\":\"" + tokenName + "\",\"TokenValue\":\"" + tokenValue + "\"}]}");
        Date expire = service.getTomorrow();
        Cookie expectedCookie = new Cookie(tokenName, tokenValue, CookieService.COOKIE_DOMAIN, CookieService.COOKIE_PATH, expire);
        
        assertTrue("The cookie should now be in the driver", service.getCookies(json).contains(expectedCookie));
    }

    
    
}
