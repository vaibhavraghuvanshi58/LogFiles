/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/WebDriverMockBuilder.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;


import java.util.List;

import org.easymock.EasyMock;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.TargetLocator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * @author utcl
 *
 */
public class WebDriverMockBuilder<T extends RemoteWebDriver> extends VgiMockBuilder<T> {

    public WebDriverMockBuilder(Class<T> classToMock) {
        super(classToMock);
    }

    private static final String ANY_MESSAGE = "anyMessage";

    OptionsMockBuilder optionsMockBuilder;

    private WebElementMockBuilder webElementMockBuilder;

    private TargetLocatorMockBuilder targetLocatorMockBuilder;

    public NestedMockBuilderExpectationSetter<VgiMockBuilder<T>, WebElement, WebElementMockBuilder> findElement(By by) {
        instantiateWebElementMockBuilder();
        return chainNestedMock(EasyMock.expect(mock.findElement(by)), webElementMockBuilder);
    }

    public WebDriverMockBuilder<T> findElementThrowElementNotFound(By mockBy) {
        EasyMock.expect(mock.findElement(mockBy)).andThrow(new NoSuchElementException(ANY_MESSAGE));
        return this;
    }

    public OptionsMockBuilder manage() {
        if(optionsMockBuilder == null) {
            optionsMockBuilder = new OptionsMockBuilder(Options.class);
            addChildBuilder(optionsMockBuilder);
        }
        EasyMock.expect(mock.manage()).andReturn(optionsMockBuilder.getMock()).atLeastOnce();

        return optionsMockBuilder;
    }

    public WebElementMockBuilder findElementById(String elementId) {
        instantiateWebElementMockBuilder();
        EasyMock.expect(mock.findElementById(elementId)).andReturn(webElementMockBuilder.getMock());
        return webElementMockBuilder;
    }

    public WebElementMockBuilder findElementByIdWithError(String elementId) {
        EasyMock.expect(mock.findElementById(elementId)).andThrow(new IllegalArgumentException());
        return webElementMockBuilder;
    }

    /**
     * 
     */
    private void instantiateWebElementMockBuilder() {
        if(webElementMockBuilder == null) {
            webElementMockBuilder = new WebElementMockBuilder(WebElement.class);
            webElementMockBuilder.setParentBuilder(this);
            addChildBuilder(webElementMockBuilder);
        }
    }

    public MockBuilderExpectationSetter<WebDriverMockBuilder<T>, List<WebElement>> findElements(By by) {
        return chain(EasyMock.expect(mock.findElements(by)));
    }

    public MockBuilderExpectationSetter<WebDriverMockBuilder<T>, Object> executeScript(String inputValue, Object ... args) {
        return chain(EasyMock.expect(mock.executeScript(inputValue, args)));
    }

    /**
     * @return
     */
    public MockBuilderExpectationSetter<WebDriverMockBuilder<T>, String> getWindowHandle() {
        return chain(EasyMock.expect(mock.getWindowHandle()));
    }

    /**
     * @return 
     * 
     */
    public NestedMockBuilderExpectationSetter<WebDriverMockBuilder<T>, TargetLocator, TargetLocatorMockBuilder> switchTo() {
        if(targetLocatorMockBuilder == null) {
            targetLocatorMockBuilder = new TargetLocatorMockBuilder(TargetLocator.class);
            targetLocatorMockBuilder.setParentBuilder(this);
            addChildBuilder(targetLocatorMockBuilder);
        }
        return chainNestedMock(EasyMock.expect(mock.switchTo()), targetLocatorMockBuilder);
    }

}

