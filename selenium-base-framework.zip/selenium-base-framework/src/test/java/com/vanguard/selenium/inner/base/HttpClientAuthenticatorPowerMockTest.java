/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/HttpClientAuthenticatorPowerMockTest.java $
 $LastChangedRevision: 682 $
 $Author: uz0s $
 $LastChangedDate: 2014-09-04 12:24:48 -0400 (Thu, 04 Sep 2014) $
*/
package com.vanguard.selenium.inner.base;

import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;

import java.net.InetAddress;

import org.apache.http.auth.NTCredentials;
import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * @author utcl
 *
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({InetAddress.class, HttpClientAuthenticator.class})
public class HttpClientAuthenticatorPowerMockTest {
    
    private static final String ANY_PW = "password";
    private static final String ANY_USERNAME = "userName";
    
    @Test
    public void givenValidUserNameAndPwWhenSettingUpCredentialsAndAuthThenHttpClientNTCredentialsAreAppropriate() throws Exception {
        HttpClientBuilder myClientBuilder = HttpClientBuilder.create();
        HttpClientAuthenticator clientAuthenticator = new HttpClientAuthenticator();
        
        PowerMock.suppressConstructor(InetAddress.class);
        InetAddress inetAddressMock = createMock(InetAddress.class);
        String expectedWorkstation = "Any Host";
        expect(inetAddressMock.getHostName()).andReturn(expectedWorkstation);
        replay(inetAddressMock);
        
        PowerMock.mockStatic(InetAddress.class);
        expect(InetAddress.getLocalHost()).andReturn(inetAddressMock).atLeastOnce();
        PowerMock.replay(InetAddress.class);
        
        NTCredentials credentialsMock = PowerMock.createMock(NTCredentials.class);
        PowerMock.expectNew(NTCredentials.class, ANY_USERNAME, ANY_PW, expectedWorkstation, "vanguard").andReturn(credentialsMock);
        PowerMock.replay(credentialsMock, NTCredentials.class);
        
        clientAuthenticator.addNtCredentialsToClientBuilder(ANY_USERNAME, ANY_PW, myClientBuilder);
        
        PowerMock.verifyAll();
        //assertEquals(credentialsMock, myClientBuilder.getDefaultCredentialsProvider().getCredentials(AuthScope.ANY));
    }

}
