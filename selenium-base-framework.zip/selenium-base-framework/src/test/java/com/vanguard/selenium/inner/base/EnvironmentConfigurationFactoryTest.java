/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/base/EnvironmentConfigurationFactoryTest.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
 */
package com.vanguard.selenium.inner.base;


import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

import com.vanguard.selenium.inner.environments.AndroidConfiguration;
import com.vanguard.selenium.inner.environments.BrowserType;
import com.vanguard.selenium.inner.environments.ChromeConfiguration;
import com.vanguard.selenium.inner.environments.EdgeConfiguration;
import com.vanguard.selenium.inner.environments.EnvironmentConfiguration;
import com.vanguard.selenium.inner.environments.FirefoxConfiguration;
import com.vanguard.selenium.inner.environments.InternetExplorerConfiguration;
import com.vanguard.selenium.inner.environments.OperaConfiguration;
import com.vanguard.selenium.inner.environments.SafariConfiguration;
import com.vanguard.selenium.inner.environments.IPadConfiguration;
import com.vanguard.selenium.inner.environments.IPhoneConfiguration;

public class EnvironmentConfigurationFactoryTest {

    private PropertiesManager propertiesManager = new PropertiesManager();
    private static final String SAUCELABS_ROOT_GRID_URL = "http://sso-vanguard-cristan_denard_brown:0a2dc99e-ae1b-42cd-801c-9e6a8a4ee195@dvlna088.vanguard.com:4444/wd/hub";
    @After
    public void teardown() {
        reInitializeProperties();
    }
    
    @Test
    public void testReturnDefaultEnvironmentWhenNoBrowserTypeIsSpecified(){
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnDefaultEnvironmentWhenSomeUnknownBrowserTypeIsSpecified(){
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "SomeUnknownBrowser");
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnChromeEnvironmentWhenNotRunningOnSauceWhenChromeBrowserIsSpecified(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, DriverFactory.IN_HOUSE_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Chrome");
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnFirefoxEnvironmentWhenRunningOnSauceAndSpecifyingFireFox(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Firefox");
        EnvironmentConfiguration expectedEnvironment = new FirefoxConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnChromeEnvironmentWhenRunningOnSauceAndSpecifyingChrome(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Chrome");
        EnvironmentConfiguration expectedEnvironment = new ChromeConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnIEEnvironmentWhenRunningOnSauceAndSpecifyingInternetExplorer(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "InternetExplorer");
        EnvironmentConfiguration expectedEnvironment = new InternetExplorerConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnEdgeEnvironmentWhenRunningOnSauceAndSpecifyingEdge(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Edge");
        EnvironmentConfiguration expectedEnvironment = new EdgeConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnSafariEnvironmentWhenRunningOnSauceAndSpecifyingSafari(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Safari");
        EnvironmentConfiguration expectedEnvironment = new SafariConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnOperaEnvironmentWhenRunningOnSauceAndSpecifyingOpera(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "Opera");
        EnvironmentConfiguration expectedEnvironment = new OperaConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnIPhoneEnvironmentWhenRunningOnSauceAndSpecifyingIPhone(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "iPhone");
        EnvironmentConfiguration expectedEnvironment = new IPhoneConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnIPadEnvironmentWhenRunningOnSauceAndSpecifyingIPad(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "iPad");
        EnvironmentConfiguration expectedEnvironment = new IPadConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    @Test
    public void testReturnAndroidEnvironmentWhenRunningOnSauceAndSpecifyingAndroid(){
        PropertiesManager.setPropertyInDefaults(DriverFactory.SELENIUM_GRID_FLAG, "true");
        PropertiesManager.setPropertyInDefaults(DriverFactory.GRID_SERVER_ULR, SAUCELABS_ROOT_GRID_URL);
        PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.BROWSER_TYPE, "android");
        EnvironmentConfiguration expectedEnvironment = new AndroidConfiguration();
        EnvironmentConfiguration actualEnvironment = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
        Assert.assertEquals(expectedEnvironment.getDesiredCapabilities(), actualEnvironment.getDesiredCapabilities());
    }
    

    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
