/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/seleniummockbuilders/WebDriverWaitMockBuilder.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.seleniummockbuilders;

import org.easymock.EasyMock;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author utcl
 *
 */
public class WebDriverWaitMockBuilder extends VgiMockBuilder<WebDriverWait>{

    public WebDriverWaitMockBuilder(Class<WebDriverWait> classToMock) {
        super(classToMock);
    }

    public <T> MockBuilderExpectationSetter<VgiMockBuilder<WebDriverWait>, Object> until(ExpectedCondition<T> createMock) {
        mock.until(createMock);
        return chain(EasyMock.expectLastCall());
    }

}
