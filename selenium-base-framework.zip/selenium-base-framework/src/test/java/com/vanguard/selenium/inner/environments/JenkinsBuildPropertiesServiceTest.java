/*
 ****************************************************************************
 *
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/test/java/com/vanguard/selenium/inner/environments/JenkinsBuildPropertiesServiceTest.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.vanguard.selenium.inner.base.PropertiesManager;

@RunWith(PowerMockRunner.class)
@PrepareForTest(JenkinsBuildPropertiesService.class)
public class JenkinsBuildPropertiesServiceTest {

	private BuildProperties mockJenkinsProperties = new BuildProperties("projectName", "32", "40574", "jenkins-projectName-32");
	private PropertiesManager propertiesManager = new PropertiesManager();
	
    @Before
    public void teardown() {
        reInitializeProperties();
    }
	
	@Test
	public void getBuildPropertiesPopulatesTheBuildPropertiesObjectTest() {
		PowerMockito.mockStatic(System.class);
		Mockito.when(System.getenv("JOB_NAME")).thenReturn(mockJenkinsProperties.getProjectName());
		Mockito.when(System.getenv("BUILD_NUMBER")).thenReturn(mockJenkinsProperties.getBuildNumber());
		Mockito.when(System.getenv("SVN_REVISION")).thenReturn(mockJenkinsProperties.getSourceControlRevisionNum());
		Mockito.when(System.getenv("BUILD_TAG")).thenReturn(mockJenkinsProperties.getEntireBuildTag());
		
		BuildProperties actualBuildProperties = JenkinsBuildPropertiesService.getBuildProperties();
		Assert.assertEquals(mockJenkinsProperties, actualBuildProperties);
	}
	

	
	@Test
	public void setDefaultLabelIfNotAlreadySetAndNoLabelInPropertiesFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		Assert.assertEquals(mockJenkinsProperties.getProjectName(), environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL));
	}

	@Test
	public void verifyLabelDoesNotChangeIfAlreadySetFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		String expectedLabel = "LabelSetFromAnnotation";
		environmentConfig.getDesiredCapabilities().setCapability(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, expectedLabel);
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		Assert.assertNotEquals(mockJenkinsProperties.getProjectName(), environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL));
		Assert.assertEquals(expectedLabel, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL));
	}

	@Test
	public void setLabelFromPropertiesIfLabelAlreadySetInPropertiesFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		String expectedLabel = "labelDifferentFromProjectNameInMock";
		PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, expectedLabel);
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		Assert.assertNotEquals(mockJenkinsProperties.getProjectName(), environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL));
		Assert.assertEquals(expectedLabel, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL));
	}

	
	
	@Test
	public void setDefaultTagsIfNotAlreadySetAndNoTagsInPropertiesFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		String expectedTags = "jenkinsBuildNumber=" + mockJenkinsProperties.getBuildNumber() + ",svnRevision=" + mockJenkinsProperties.getSourceControlRevisionNum() + ",fullJenkinsID=" + mockJenkinsProperties.getEntireBuildTag();
		Assert.assertEquals(expectedTags, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS));
	}

	@Test
	public void verifyTagStaysAddedIfAlreadySetFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		String expectedTags = "TagSetFromAnnotation";
		environmentConfig.getDesiredCapabilities().setCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, expectedTags);
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		expectedTags += ",jenkinsBuildNumber=" + mockJenkinsProperties.getBuildNumber() + ",svnRevision=" + mockJenkinsProperties.getSourceControlRevisionNum() + ",fullJenkinsID=" + mockJenkinsProperties.getEntireBuildTag();
		Assert.assertEquals(expectedTags, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS));
	}
	
	@Test
	public void addTagFromPropertiesToDefaultTagsIfTagAlreadySetInPropertiesFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		String expectedTags = "TagFromProperties";
		PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, expectedTags);
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		expectedTags += ",jenkinsBuildNumber=" + mockJenkinsProperties.getBuildNumber() + ",svnRevision=" + mockJenkinsProperties.getSourceControlRevisionNum() + ",fullJenkinsID=" + mockJenkinsProperties.getEntireBuildTag();
		Assert.assertEquals(expectedTags, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS));
	}

	@Test
	public void addTagFromPropertiesAndAnnotationToDefaultTagsIfTagAlreadySetInBothPropertiesAndAnnotationFromCallingAddJenkinsInfoTest() throws Exception {
		EnvironmentConfiguration environmentConfig = new FirefoxConfiguration();
		String annoationTags = "TagFromAnnotation1,annotationTag2";
		environmentConfig.getDesiredCapabilities().setCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, annoationTags);
		String propertiesTags = "TagFromProps1,propsTag2,propsTag3";
		PropertiesManager.setPropertyInDefaults(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, propertiesTags);
		PowerMockito.stub(PowerMockito.method(JenkinsBuildPropertiesService.class, "getBuildProperties")).toReturn(mockJenkinsProperties);
		
		JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
		String expectedTags = annoationTags + "," + propertiesTags + ",jenkinsBuildNumber=" + mockJenkinsProperties.getBuildNumber() + ",svnRevision=" + mockJenkinsProperties.getSourceControlRevisionNum() + ",fullJenkinsID=" + mockJenkinsProperties.getEntireBuildTag();
		Assert.assertEquals(expectedTags, environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS));
	}

	
    private void reInitializeProperties() {
        try {
            propertiesManager.reInitializeProperties();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

}

