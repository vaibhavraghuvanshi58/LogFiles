/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/test/java/com/vanguard/selenium/inner/core/utils/FileBackupTest.java $
 $LastChangedRevision: 1130 $
 $Author: ubhj $
 $LastChangedDate: 2015-02-10 17:39:18 -0500 (Tue, 10 Feb 2015) $
 */
package com.vanguard.selenium.inner.core.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class FileBackupTest {

	FileBackup fileBackup = new FileBackup();
	File file = new File("fileBackupTestFile");

	@Before
	public void before() throws IOException {
		file.delete();
		file.createNewFile();
	}

	@After
	public void after() {
		file.delete();
	}

	@Test
	public void backupAndRestoreFile() throws IOException {
		PrintWriter writer = new PrintWriter(file);
		String fileContents = "\ttest\r\n testNewLine";
		writer.print(fileContents);
		writer.close();

		fileBackup.backup(file);

		file.delete();
		assertFalse(file.exists());

		fileBackup.restore();

		assertEquals(FileUtils.readFileToString(file), fileContents);
	}
}
