/*
 ****************************************************************************
 *
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/pages/ExamplePageObject.java $
 $LastChangedRevision: 4345 $
 $Author: uz0s $
 $LastChangedDate: 2016-08-19 17:11:48 -0400 (Fri, 19 Aug 2016) $
 */
package com.vanguard.selenium.inner.core.pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/** NOTE: This page is for Example purposes only.
 * Do NOT use this class in any tests or functionality.
 * It exists as a Learning tool only.
 * @author uz0s
 */
public class ExamplePageObject extends VanguardBasePageImpl {

	/*** The best thing to use is id, like this example ***/
	By retirementPlanParticipantsIcon = By.id("retirementIcon");
			
	/*** If id's are not present, you can use xpath where needed ***/
	By institutionalInvestorsLink = By.xpath("//span[contains(text(), 'Institutional investors')]");
	
	/*** You can also use CSS.  But be careful!  CSS and XPath can lead to bad matches easily.
	 * In this example below, this CSS actually matches to 4 different span elements.  By default,
	 * if you use these types of generic matches to find elements, Selenium will default to the
	 * first match it sees on the page and assign it to the WebElement object. 
	 ***/
	By personalInvestorLink = By.cssSelector("span.linkStyle");
	
	
	public ExamplePageObject(WebDriver driver) {
		super(driver);
	}

	/**This is needed because we're implementing VanguardBasePageInterface (since we're extending VanguardBasePageImple which implements it)*/
	public boolean isCurrentlyLoaded() {
		//General rule is to pick an element that seems like the most telling object for the page, or has the most unique ID.
		//And run isDisplayed off the VanguardBasePageImpl on that element with a reasonable amount of time to wait for that element to appear.
		return isDisplayed(institutionalInvestorsLink, 20);
	}
	
	
	/***  Now lets implement the methods specific to this page ***/
	
	public void navigateToPage(){
		visit("http://www.vanguard.com");
		Assert.assertTrue(isCurrentlyLoaded());
	}

	public PersonalInvestorPage clickPersonalInvestorLink(){
		click(personalInvestorLink);
		return new PersonalInvestorPage(driver);
	}
	
	public InstitutionalInvestorPage clickInstitutionalInvestorLink(){
		click(institutionalInvestorsLink);
		return new InstitutionalInvestorPage(driver);
	}
	
	public boolean isRetirementPlanParticipantsIconDisplayed(){
		return isDisplayed(retirementPlanParticipantsIcon);
	}

	
	
	
	/** This would be another Page Object class 
	 * We include it here just so that our Example page will compile.**/
	public class PersonalInvestorPage extends VanguardBasePageImpl{
		public PersonalInvestorPage(WebDriver driver) {
			super(driver);
		}
		public boolean isCurrentlyLoaded() {
			return true;
		}
	}
	
	/** This would be another Page Object class 
	 * We include it here just so that our Example page will compile.**/
	public class InstitutionalInvestorPage extends VanguardBasePageImpl{
		public InstitutionalInvestorPage(WebDriver driver) {
			super(driver);
		}
		public boolean isCurrentlyLoaded() {
			return true;
		}
	}
}



