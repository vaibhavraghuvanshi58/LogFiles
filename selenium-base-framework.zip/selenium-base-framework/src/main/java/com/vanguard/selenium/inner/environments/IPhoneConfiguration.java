/*
 ****************************************************************************
 * 
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/IPhoneConfiguration.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author uz0s
 *
 */
public class IPhoneConfiguration extends IOSConfiguration{
    
    public static final String DEVICE_NAME_IPHONE_DEFAULT_VALUE = "iPhone Simulator";
    
    public IPhoneConfiguration() {
        super(DesiredCapabilities.iphone());
        addCapability(MobileConfiguration.DEVICE_NAME, DEVICE_NAME_IPHONE_DEFAULT_VALUE);
    }

}
