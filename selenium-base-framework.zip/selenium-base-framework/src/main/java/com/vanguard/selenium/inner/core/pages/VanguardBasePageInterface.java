/*
 ****************************************************************************
 *
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/pages/VanguardBasePageInterface.java $
 $LastChangedRevision:7/03/2014
 $Author:utbx

   Interface describing functionality for one "view".
*/
package com.vanguard.selenium.inner.core.pages;


public interface VanguardBasePageInterface {

	boolean isCurrentlyLoaded();
}
