/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/logon/user/AccountType.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
*/
package com.vanguard.selenium.inner.logon.user;

import java.util.HashMap;
import java.util.Map;

public enum AccountType {

	//TODO Add all account types
	INDIVIDUAL("Individual"),
	JOINT("Joint"),
	UGMA_UTMA("UGMA/UTMA"),
	TRADITIONAL_IRA("Traditional IRA"),
	ROLLOVER_IRA("Rollover IRA");

	private String acctType;

	private AccountType(String acctType){
		this.acctType = acctType;
	}
	
	@Override
    public String toString() {
        return acctType;
    }
	
	private static final Map<String, AccountType> STRING_TO_ENUM = new HashMap<String, AccountType>();
	static{
		for(AccountType curEnum : values()){
			STRING_TO_ENUM.put(curEnum.toString(), curEnum);
		}
	}

	public static AccountType fromString(String acctType){
		return STRING_TO_ENUM.get(acctType);
	}
}
