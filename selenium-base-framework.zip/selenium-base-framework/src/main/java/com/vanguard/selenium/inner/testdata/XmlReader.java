/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/testdata/XmlReader.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
 */
package com.vanguard.selenium.inner.testdata;

import java.net.URL;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author ubmq
 * 
 */
public class XmlReader {

    private final static Schema mSchema = initializeSchema();

    static final JAXBContext context = initContext();

    private static Schema initializeSchema() {
        SchemaFactory sf = SchemaFactory.newInstance(javax.xml.XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = null;
        URL schemaDoc = XmlReader.class.getResource("/selenium-test-data.xsd");
        try {
            schema = sf.newSchema(schemaDoc);
        } catch (SAXException e) {
            LoggingUtility.logError("Error parsing Selenium Test Data schema.", e);
        }

        return schema;

    }

    /**
     * @return
     */
    private static JAXBContext initContext() {
        JAXBContext context = null;
        try {
            context = JAXBContext.newInstance(TestCases.class);
        } catch (JAXBException e) {
            LoggingUtility.logError("Error initializing JAXB Context for test data.", e);
        }
        return context;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vanguard.retail.printandmail.application.ApplicationPrintService#execute(com.vanguard.retail.printandmail.application.formdata.
     * ApplicationFormData)
     */
    public static TestCases getTestData(String xmlDataFileName) {
        LoggingUtility.logDebug("Begin test data retrieval");
        TestCases testCaseData = null;
        Unmarshaller unmarshaller;

        try {
            unmarshaller = context.createUnmarshaller();
            unmarshaller.setProperty("com.sun.xml.bind.ObjectFactory", new ObjectFactoryExt());
            unmarshaller.setSchema(mSchema);
            JAXBElement<TestCases> root = unmarshaller.unmarshal(new StreamSource(XmlReader.class.getResourceAsStream("/" + xmlDataFileName)),
                    TestCases.class);
            testCaseData = root.getValue();
        } catch (JAXBException e) {
            LoggingUtility.logWarning("Unable to getTestData!  Filepath:  /" + xmlDataFileName , e);
        }

        LoggingUtility.logDebug("End test data retrieval");
        List<TestCase> testCaseList = testCaseData.getTestCases();
        for (TestCase testCase : testCaseList) {
            if (testCase instanceof TestCaseExt) {
                ((TestCaseExt) testCase).setXmlFilePath(xmlDataFileName);
            }
        }
        return testCaseData;
    }

}
