/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/FileUtils.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Basic helper class for common IO use cases
 */
public class FileUtils {
	protected static Log log = LogFactory.getLog(FileUtils.class);
	
	/**
	 * Reads in a file and returns a list of strings for each row
	 */
	public static List<String> readFile(File file) {
		List<String> list = new ArrayList<String>();
		BufferedReader in = null;
		try {
			String string = null;
			in = new BufferedReader(new FileReader(file));
			while ((string = in.readLine()) != null) {
				list.add(string);
			}
		} catch (IOException e) {
			log.debug("Error reading file " + file.getName() + "......." + e);
			throw new RuntimeException(e);
		} finally {
			IOUtils.closeQuietly(in);
		}
		return list;
	}
	
	/**
	 * Parses a delimited separated string (uses commas by default).  If a value is enclosed in single quotes, the parser will ignore delimiters contained in the quotes and strips the quotes off of the value
	 * i.e.   a,b,"c,d" e  ==
	 * a
	 * b
	 * c,d
	 * e
	 */
	public static List<String> parseString(String string) {
		Pattern pattern = Pattern.compile("\\s*(\"[^\"]*\"|[^,]*)\\s*");
		return genericParser(string, pattern);
	}
	
	/**
	 * Parses a delimited separated string (uses commas by default).  If a value is enclosed in single quotes, the parser will ignore delimiters contained in the quotes and strips the quotes off of the value.
	 * i.e.   a,b,"c,d" e  ==
	 * a
	 * b
	 * c,d
	 * e
	 */
	public static List<String> parseString(String string, String delimiter) {
		Pattern pattern = Pattern.compile("\\s*(\"[^\"]*\"|[^" + delimiter +"]*)\\s*");
		return genericParser(string, pattern);
	}
	
	private static List<String> genericParser(String string, Pattern pattern){
		List<String> list = new ArrayList<String>();
		Matcher matcher = pattern.matcher(string);
		while (matcher.find()) {
			if(!matcher.group(1).equals("")){
				if (matcher.group(1).startsWith("\"") && matcher.group(1).endsWith("\"")){
					list.add(matcher.group(1).substring(1, matcher.group(1).length()-1));
				}
				else {
					list.add(matcher.group(1));
				}
				
			}
		}
		return list;
	}
	
	/**
	 * Writes a string to a file.  If the file exists, it appends the string to the file.
	 */
	public static void writeFile(File file, String string) {
		FileOutputStream stream = null;
		try {
			stream = new FileOutputStream(file, true); // append the file
			stream.write(string.getBytes());
			stream.flush();
		} catch (IOException e) {
			log.debug("Error writing " + file.getName() + " to disk...." + e);
			throw new RuntimeException(e);
		} finally {
			IOUtils.closeQuietly(stream);
		}
	}

}
