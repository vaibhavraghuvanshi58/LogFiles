package com.vanguard.selenium.inner.environments;


public class EnvironmentConfigOverrideValues {

	private String tags;
    private String browserVersion;
    private String osType;
    private String osVersion;
    private String chromeDriverVersion;
    private String ieDriverVersion;
    private String deviceName;
    private String deviceOrientation;
    private String devicePlatformVersion;
    private String idleTimeout;
    private String screenResolution;

    public EnvironmentConfigOverrideValues(String tags, String browserVersion, String osType, String osVersion, String chromeDriverVersion, 
    		String ieDriverVersion, String deviceName, String deviceOrientation, String devicePlatformVersion, String idleTimeout, 
    		String screenResolution) {
        super();
        this.tags = tags;
        this.browserVersion = browserVersion;
        this.osType = osType;
        this.osVersion = osVersion;
        this.chromeDriverVersion = chromeDriverVersion;
        this.ieDriverVersion = ieDriverVersion;
        this.deviceName = deviceName;
        this.deviceOrientation = deviceOrientation;
        this.devicePlatformVersion = devicePlatformVersion;
        this.idleTimeout = idleTimeout;
        this.screenResolution = screenResolution;
    }

    public String getTags() {
    	return tags;
    }
    
    public String getBrowserVersion() {
        return browserVersion;
    }

    public String getOsType() {
        return osType;
    }
    
    public String getOsVersion() {
        return osVersion;
    }

    public String getChromeDriverVersion() {
        return chromeDriverVersion;
    }

    public String getIEDriverVersion() {
        return ieDriverVersion;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public String getDeviceOrientation() {
        return deviceOrientation;
    }

    public String getDevicePlatformVersion() {
        return devicePlatformVersion;
    }

    public String getIdleTimout() {
    	return idleTimeout;
    }
    
    public String getScreenResolution() {
    	return screenResolution;
    }
}