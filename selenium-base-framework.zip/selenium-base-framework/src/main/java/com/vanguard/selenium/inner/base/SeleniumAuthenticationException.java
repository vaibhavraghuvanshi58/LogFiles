/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/SeleniumAuthenticationException.java $
 $LastChangedRevision: 5409 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-10 14:01:51 -0400 (Mon, 10 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

/**
 * @author uc4b
 *
 */
public class SeleniumAuthenticationException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -7938397276268149282L;

    /**
     * 
     */
    public SeleniumAuthenticationException(String message) {
        super(message);
    }
}
