/*
 ****************************************************************************
 * 
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/RetryRuleForGridFailure.java $
 $LastChangedRevision: 5583 $
 $Author: uz0s $
 $LastChangedDate: 2017-05-31 13:01:21 -0400 (Wed, 31 May 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.junit.internal.AssumptionViolatedException;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.vanguard.selenium.api.monitoring.GridInfoExtractor;
import com.vanguard.selenium.inner.core.rule.RetryRule;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.ScreenshotUtils;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;

/**
 * The RetryRule will attempt to rerun tests X number of times.  
 * Tests will be marked passed if they pass any time within the retry threshold.  
 */
public class RetryRuleForGridFailure extends RetryRule {

    private static String BROWSER_DIED_TEXT = "Error communicating with the remote browser. It may have died.";
    private static String WINDOW_CLOSED_TEXT = "Window not found. The browser window may have been closed.";

    public RetryRuleForGridFailure(Integer maxRetries, Boolean takeScreenshot) {
        super(maxRetries, takeScreenshot);
    }

    @Override
    public Statement apply(final Statement statement, final Description description) {
        return new Statement() {
    
    	    @Override
    	    public void evaluate() throws Throwable {
        		String formattedTestDescription = getFormattedTestDescription(description);
        		caughtThrowable = null;
        		for (int i = 0; i < maxRetries; i++) {
        		    try {
            			retryCount = retryCount + 1;
            			statement.evaluate();
            			return;
        		    } catch (WebDriverException e) {
        			if (e.getMessage().contains(BROWSER_DIED_TEXT) || e.getMessage().contains(WINDOW_CLOSED_TEXT)) {
        			    retryTheTest();
        			} else {
        			    reportErrorDoNOTRetry(e, formattedTestDescription);
        			    throw e;
        			}
        		    } catch (Throwable t) {
        			// skipped test
            			if (t instanceof AssumptionViolatedException) {
            			    return;
            			}
            			reportErrorDoNOTRetry(t, formattedTestDescription);
            			throw t;
        		    }
        		}
    	    }
    
    	    private void reportErrorDoNOTRetry(Throwable t, String formattedTestDescription) {
        		LoggingUtility.logError(formattedTestDescription + " Recieved error: " + t.getMessage());
        		if(!DriverFactory.isRunningOnSauceLabs() && driver.toString().toLowerCase().contains("remotewebdriver")){
        		    GridInfoExtractor.logGridInfo((RemoteWebDriver)driver, PropertiesManager.getProperty("gridServerUrl"));
        		}

        		if (takeScreenshot) {
        		    String directory = PropertiesManager.getProperty(PropertiesManager.SCREENSHOT_DIRECOTRY_KEY);
        		    if(StringUtils.isBlank(directory)){
        		        directory = "";
        		    }
        		    LoggingUtility.logInfo("Taking Screenshot [ " + formattedTestDescription + "] in directory " + directory);
        		    takeScreenShot(formattedTestDescription, driver, directory);
        		}
    	    }
    
    	    private void retryTheTest() {
        		LoggingUtility.logError("***************  WE FAILED DUE TO BROWSER DEATH *********************");
        
        		if (retryCount < maxRetries) {
        		    LoggingUtility.logInfo("Retrying test now.  Retry count is: " + retryCount + " of " + maxRetries);
        		}
        
        		SeleniumWaitHelper.pause(2); // Pause for 2 seconds for good measure before restarting the test.
    	    }
    
    	    protected String getFormattedTestDescription(final Description testDesc) {
        		String methodName = StringUtils.substringBefore(testDesc.getMethodName(), "[");
        		String testClass = testDesc.getTestClass().getSimpleName();
        		String ruleId = StringUtils.substringBetween(testDesc.getMethodName(), "rule=", " ");
        		String channel = StringUtils.substringBetween(testDesc.getMethodName(), "channel=", " ");
        		String user = StringUtils.substringBetween(testDesc.getMethodName(), "user=", " ");
        
        		StringBuilder stringBuilder = new StringBuilder(testClass).append('_').append(methodName).append('_');
        		if (StringUtils.isNotBlank(ruleId)) {
        		    stringBuilder.append(ruleId).append('_');
        		}
        		if (StringUtils.isNotBlank(channel)) {
        		    stringBuilder.append(channel).append('_');
        		}
        		if (StringUtils.isNotBlank(user)) {
        		    stringBuilder.append(user);
        		}
        
        		return stringBuilder.toString();
    	    }
    	};
    }

    private String getTimestamp() {
    	SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy HHmmss");
    	String string = formatter.format(new Date());
    	return string;
    }

    private void takeScreenShot(String className, WebDriver aDriver, String filePath) {
        ScreenshotUtils.takeScreenShot(filePath, filePath + className + "-" + getTimestamp() + ".png", aDriver);
    }

}