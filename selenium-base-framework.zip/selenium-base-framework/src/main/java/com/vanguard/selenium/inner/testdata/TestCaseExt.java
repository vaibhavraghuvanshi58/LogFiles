/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/testdata/TestCaseExt.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
 */
package com.vanguard.selenium.inner.testdata;

import org.apache.commons.lang3.StringUtils;

/**
 * @author ubmq
 * 
 */
public class TestCaseExt extends TestCase {

    private String xmlFilePath = "";

    /**
     * @return the xmlFilePath
     */
    public String getXmlFilePath() {
        return xmlFilePath;
    }

    /**
     * @param xmlFIlePath
     *            the xmlFilePath to set
     */
    public void setXmlFilePath(String xmlFilePath) {
        this.xmlFilePath = xmlFilePath;
    }

    /**
     * Returns TestCase description if available otherwise returns "{index}" which allows the NamedParamterized test runner to display the index of
     * the test. If the region is also present it will be appended to the description text (e.g. "Test 2: region=X")
     * 
     * If only the region is defined the method will return "{index}" + region name (e.g. "{index}: region=X")
     * 
     * JUnit runner will replace the "{index}" placeholder with an integer representing the current instance of the test case.
     * 
     */
    @Override
    public String toString() {
        String testCaseDescription = createDescription();
        return (StringUtils.isNotBlank(testCaseDescription) ? testCaseDescription : "{index}");
    }

    private String createDescription() {
        boolean isDescriptionPresent = StringUtils.isNotBlank(description);
        boolean isRegionPresent = StringUtils.isNotBlank(region);

        if (isDescriptionPresent && isRegionPresent) {
            return description + ": region=" + region.toUpperCase();
        } else if (isDescriptionPresent) {
            return description;
        } else if (isRegionPresent) {
            return "{index}: region=" + region.toUpperCase();
        } else {
            return null;
        }
    }
}
