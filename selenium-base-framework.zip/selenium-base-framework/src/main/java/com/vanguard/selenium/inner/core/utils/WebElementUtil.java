/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/WebElementUtil.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author ubmq
 * 
 */
public class WebElementUtil {

    static final String XPATH_SUFFIX = "')]";
    static final String XPATH_CONTAINS = "//*[contains(.,'";
    static final String INNER_HTML_JS = "return arguments[0].innerHTML";
    static final String GET_ELEMENT_BY_ID_TEXT = "return document.getElementById('";

    public static int defaultWaitInSeconds = 30;

    public static boolean isElementDisplayed(final String elementId, WebDriver driver, int maxWaitTime) {
    	driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        final WebDriverWait webDriverWait = new WebDriverWait(driver, maxWaitTime);
        ExpectedConditionBuilder conditionBuilder = new ExpectedConditionBuilder();
        final ExpectedCondition<Boolean> expectedCondition = conditionBuilder.buildIsDisplayedConditionById(driver, elementId);

        return isElementDisplayedWithWaitAndCondition(driver, webDriverWait, expectedCondition);
    }

    public static boolean isElementPresent(WebDriver driver, By by) {
        WebElement element = findElement(driver, by, 0);
        return (element!=null);
    }

    public static String getSourceForWebElement(WebElement element, WebDriver driver) {
        final Object obj = ((JavascriptExecutor) driver).executeScript(INNER_HTML_JS, element);

        if (obj != null && obj instanceof String) {
            return (String) obj;
        }
		LoggingUtility.logDebug("unable to look up element");
		return "";
    }

    @Deprecated
    //** Use isDisplayed off VanguardBasePageImpl.  Use a ByLocator that's a little more specific than the entire DOM **/
    public static boolean isTextPresent(WebDriver driver, String searchText) {
        try {
            driver.findElement(By.xpath(XPATH_CONTAINS + searchText + XPATH_SUFFIX));
            return true;
        } catch (final NoSuchElementException e) {
            LoggingUtility.logInfo(searchText + " was not found on the page!");
            return false;
        }
    }

    /**
     * NOTE: if the element is not displayed, this will take the Selenium Default time of 30 seconds to tell us that
     * 
     * @param element
     * @param driver
     * @param maxWaitTime - This param will not actually do anything.  Selenium will wait for up to 30 seconds to find the element if it is not displayed no matter what you put here.
     * @return
     * 
     * Better solution:
     * 		When declaring the WebElement at the top of the page, use a final String for the ID, then pass that ID into isElementDisplayed() instead of the webElement itself.
     * 		ie:
     * 		    final String logOffID = "_cbdGHLogOn";
     *			@FindBy(id = logOffID)
     *			private WebElement logOff;
     *			...
     *			boolean isDisplayed = WebElementUtil.isElementDisplayed(logOffID, driver, 0);
     */
    public static boolean isElementDisplayed(final WebElement element, WebDriver driver, int maxWaitTime) {
        final ExpectedConditionBuilder conditionBuilder = new ExpectedConditionBuilder();
        WebDriverWait webDriverWait = new WebDriverWait(driver, maxWaitTime);
        return isElementDisplayedWithWaitAndCondition(driver, webDriverWait, conditionBuilder.buildElementDisplayedCondition(element));
    }
    
    /**
     * NOTE: if the element is not displayed, this will take the Selenium Default time of 30 seconds to tell us that
     * @param element
     * @param driver
     * @return
     */
    public static boolean isElementDisplayed(final WebElement element, WebDriver driver) {
        final ExpectedConditionBuilder conditionBuilder = new ExpectedConditionBuilder();
        WebDriverWait webDriverWait = new WebDriverWait(driver, 0);
        return isElementDisplayedWithWaitAndCondition(driver, webDriverWait, conditionBuilder.buildElementDisplayedCondition(element));
    }

    static boolean isElementDisplayedWithWaitAndCondition(WebDriver driver, WebDriverWait webDriverWait,
            ExpectedCondition<Boolean> expectedCondition) {
        boolean isElementDisplayed = false;
        
        try {
            webDriverWait.until(expectedCondition);
            isElementDisplayed = true;
        } catch (final Exception e) {
            LoggingUtility.logDebug(e.getMessage());
        }

        return isElementDisplayed;
    }

    public static boolean doesIdExistOnPage(String id, WebDriver driver) {
        // Added the following conditional to ensure that no existing FireFox functionality is broken
        if (driver instanceof InternetExplorerDriver) {
            try {
                driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                final boolean isDisplayed = ((InternetExplorerDriver) driver).findElementById(id).isDisplayed();
                return isDisplayed;
            } catch (final Exception ex) {
                return false;
            } finally {
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            }
        } else {
            final Object obj = ((JavascriptExecutor) driver).executeScript(GET_ELEMENT_BY_ID_TEXT + id + "')");
            return obj != null;
        }
    }

    public static boolean isPopUpWindowDisplayed(WebDriver driver, String windowName) {
        return isPopUpWindowDisplayedWithText(driver, windowName, null);
    }

    public static boolean isPopUpWindowDisplayedWithText(WebDriver driver, String windowName, String text) {
        boolean isDisplayed = false;
        final String mainWindow = driver.getWindowHandle();
        try {
            driver.switchTo().window(windowName);
            if (!StringUtils.isNullOrEmpty(text)) {
                isDisplayed = isTextPresent(driver, text);
            } else {
                isDisplayed = true;
            }
            driver.switchTo().window(mainWindow);
        } catch (final NoSuchWindowException e) {
            isDisplayed = false;
        }
        return isDisplayed;
    }

    public static void clearAndType(WebElement field, String text, final WebDriver driver) {
        SeleniumWaitHelper waitHelper = new SeleniumWaitHelper(driver);
        waitHelper.waitForElementToBeEnabled(field.getAttribute("id"));
		field.sendKeys(Keys.HOME, Keys.SHIFT, Keys.END, Keys.BACK_SPACE);
		field.sendKeys(text, Keys.TAB);
        waitHelper.waitForAjax();
    }

    public static WebElement getLinkForText(WebDriver driver, String linkText, String ticker) {
        WebElement webElementLink = null;
        final List<WebElement> links = driver.findElements(By.linkText(linkText));
        for (final WebElement link : links) {
            if (link.getAttribute("href").contains(ticker)) {
                webElementLink = link;
                break;
            }
        }
        return webElementLink;
    }
    
    public static void tryToSendKeysForStubornWebElementUpToXTimes(WebDriver driver, String id, String sendKeys, int maxTimes){
		boolean success = false;
		int timesLeft = maxTimes;
		do{
			try{
				WebElement element = driver.findElement(By.id(id));
				element.sendKeys(sendKeys);
				success = true;
				LoggingUtility.logDebug("Success typing intput into element with ID: " + id);
			} catch (Exception e) {
				LoggingUtility.logInfo("Had trouble typing: " + sendKeys + ", into element with ID: " + id + ", trying up to [" + --timesLeft + "] more times.");
				SeleniumWaitHelper.pause(1);
			}
		} while(timesLeft > 0 && !success);
	}
	
	public static void tryToClickOnStubornWebElementUpToXTimes(WebDriver driver, String id, int maxTimes){
		boolean success = false;
		int timesLeft = maxTimes;
		do{
			try{
				WebElement element = driver.findElement(By.id(id));
				element.click();
				success = true;
				LoggingUtility.logDebug("Success clicking on element with ID:" + id);
			} catch (Exception e) {
				LoggingUtility.logInfo("Had trouble clicking on element with ID: " + id + ", trying up to [" + --timesLeft + "] more times.");
				SeleniumWaitHelper.pause(1);
			}
		} while(timesLeft > 0 && !success);
	}

	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(WebDriver driver, By by) {
		WebElement element;
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(by), 0);
			element = driver.findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}

	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(WebDriver driver, By by, int maxWaitTime) {
		WebElement element;
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(by), maxWaitTime);
			element = driver.findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}
	
	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(WebElement sourceElement, WebDriver driver, By by) {
		WebElement element;
		By sourceByLocator = getByLocatorOfElement(sourceElement);
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(sourceByLocator), 0);
			element = sourceElement.findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}
	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(By sourceElementByLocator, WebDriver driver, By by) {
		WebElement element;
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(sourceElementByLocator), 0);
			element = findElement(driver, sourceElementByLocator).findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}
	
	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(WebElement sourceElement, WebDriver driver, By by, int maxWaitTime) {
		WebElement element;
		By sourceByLocator = getByLocatorOfElement(sourceElement);
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(sourceByLocator), maxWaitTime);
			element = sourceElement.findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}
	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static WebElement findElement(By sourceElementByLocator, WebDriver driver, By by, int maxWaitTime) {
		WebElement element;
		try {
			waitFor(driver, ExpectedConditions.visibilityOfElementLocated(sourceElementByLocator), maxWaitTime);
			element = findElement(driver, sourceElementByLocator).findElement(by);
        } catch (final Exception e) {
        	element = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		
		return element;
	}

	@Deprecated
	/**Attempts to smartly get the best locator of an element that it can find **/
	/** Use the method off VanguardBasePageImpl **/
	public static By getByLocatorOfElement(WebElement sourceElement) {
		if(StringUtils.isNullOrEmpty(sourceElement.getAttribute("id"))){
			return By.id(sourceElement.getAttribute("id"));
		} else if(StringUtils.isNullOrEmpty(sourceElement.getAttribute("name"))) {
			return By.name(sourceElement.getAttribute("name"));
		} else if(StringUtils.isNullOrEmpty(sourceElement.getAttribute("class"))) {
			return By.className(sourceElement.getAttribute("class"));
		}
		return null;
	}
	
	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static List<WebElement> findElements(WebDriver driver, By by, int maxWaitTime) {
	    List<WebElement> result;
	    try{
	        findElement(driver, by, maxWaitTime); //Look for the default first one of the collection.
	        result = driver.findElements(by);
	    } catch (final Exception e) {
	        result = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		return result;
	}

	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	public static List<WebElement> findElements(WebElement sourceElement, WebDriver driver, By by, int maxWaitTime) {
        List<WebElement> result;
        try{
            findElement(sourceElement, driver, by, maxWaitTime); //Look for the default first one of the collection.
            result = sourceElement.findElements(by);
        } catch (final Exception e) {
            result = null;
            LoggingUtility.logDebug(e.getMessage());
        }
		return result;
	}

	@Deprecated
	/** Use the method off VanguardBasePageImpl **/
	private static void waitFor(WebDriver driver, ExpectedCondition<WebElement> condition, Integer maxWaitTime){
		maxWaitTime = maxWaitTime != null ? maxWaitTime : 5;
		WebDriverWait wait = new WebDriverWait(driver, maxWaitTime);
		wait.until(condition);
	}
	
	@Deprecated
	/** Use findElement method instead **/
	public static WebElement getElementOrNullIfDoesNotExist(WebDriver driver, int maxLookTimeInSeconds, By byLocator){
		return findElement(driver, byLocator, maxLookTimeInSeconds);
	}
	
	@Deprecated
	/** Use findElement method instead **/
	public static WebElement getElementOrNullIfDoesNotExist(WebDriver driver, WebElement baseElement, int maxLookTimeInSeconds, By byLocator){
		return findElement(baseElement, driver, byLocator, maxLookTimeInSeconds);
	}
	
	public static WebElement getElementFromListByFULLText(List<WebElement> elemList, String correctText) {
		for (WebElement webElement : elemList) {
			String elementText = "";
			String elementName = "";
			try {
				elementText = webElement.getText();
				elementName = webElement.getAttribute("name");
			} catch (Exception e) {
				//Do nothing.  For some reason some getText() calls are not returning Strings even thought that's the method return type!?!
			}
			if(correctText.equals(elementText) || correctText.equals(elementName)) {
				return webElement;
			}
		}
		return null;
	}

	public static WebElement getElementFromListByPARTIALText(List<WebElement> elemList, String partialMatch) {
		for (WebElement webElement : elemList) {
			if(webElement.getText().contains(partialMatch) || (webElement.getAttribute("name") != null && webElement.getAttribute("name").contains(partialMatch))) {
				return webElement;
			}
		}
		return null;
	}

	public static WebElement getElementFromListByREGULAR_EXPRESSION(List<WebElement> elemList, String regEx) {
		for (WebElement webElement : elemList) {
			if(webElement.getText().matches(regEx) || (webElement.getAttribute("name") != null && webElement.getAttribute("name").matches(regEx))) {
				return webElement;
			}
		}
		return null;
	}
	
	public static void printElementInfoToConsole(WebElement element) {
		if(element != null){
			String message = "";
			//Try to get each of every attributes we can think of, if any don't work for any reason, just don't include them in the output.
			try{
				String id = element.getAttribute("id");
				message+="ID: [" + id + "], ";
			} catch(Exception e){ }
			try{
				String name = element.getAttribute("name");
				message+="Name: [" + name + "], ";
			} catch (Exception e) { }
			try{
				String elemText = element.getText();
				message+="Text: [" + elemText + "], ";
			} catch (Exception e) {	}
			try{
				boolean isDisplayed = element.isDisplayed();
				message+="isDisplayed: [" + isDisplayed + "], ";
			} catch (Exception e) {	}
			try{
				boolean isEnabled = element.isEnabled();
				message+="isEnabled: [" + isEnabled + "], ";
			} catch (Exception e) {	}
			try{
				boolean isSelected = element.isSelected();
				message+="isSelected: [" + isSelected + "], ";
			} catch (Exception e) {	}
			try{
				String elemSize = element.getSize().toString();
				message+="Size:" + elemSize + ", ";
			} catch (Exception e) {	}
			try{
				String elemLoc = element.getLocation().toString();
				message+="Location: " + elemLoc + ", ";
			} catch (Exception e) {	}
			try{
				String elemTagName = element.getTagName().toString();
				message+="Tag Name: [" + elemTagName + "]";
			} catch (Exception e) {	}
			System.out.println(message);
		} else {
			System.out.println("Element passed in is null!  There's no Info to print to the console.");
		}
	}
	
	/**This method will scroll the page either up or down until the element you specify is within view.
	 * If the element is already in view, no scrolling will occur.
	 * If the element is not already in view it will scroll until the element is at the top of the viewable screen.**/
	public static void scrollToElement(WebDriver driver, WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}

	/**NOTE: For exact scrolling use method: scrollToElement().
	 * This method scrolls down 80% of the window screen.  
	 * The top browser controls and banner are included in this height value which is why we only scroll 80%.**/
	public static void scrollDownOnePage(WebDriver driver) {
		int browserHeight = driver.manage().window().getSize().getHeight();
		int percentage = (int) (browserHeight * 0.80);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0," + percentage + ")");
	}

	/**NOTE: For exact scrolling use method: scrollToElement().
	 * This method scrolls up 80% of the window screen.  
	 * The top browser controls and banner are included in this height value which is why we only scroll 80%.**/
	public static void scrollUpOnePage(WebDriver driver) {
		int browserHeight = driver.manage().window().getSize().getHeight();
		int percentage = (int) (browserHeight * 0.80);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0, " + percentage * -1 + ")");
	}
}
