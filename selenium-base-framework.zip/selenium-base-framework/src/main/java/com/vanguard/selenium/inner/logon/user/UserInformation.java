/*
 ****************************************************************************
 * 
 * Copyright (c)2011 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/logon/user/UserInformation.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
*/
package com.vanguard.selenium.inner.logon.user;

import java.util.ArrayList;
import java.util.List;

import com.vanguard.selenium.inner.base.Region;

/**
 * @author urkh
 *
 */
public class UserInformation {

    private String name;
    private String poid;
    private String tin;
    private String userId;
    private List<Account> accounts = new ArrayList<Account>();
    private Region region;
    private SegmentType segment;

    public String getName() {
        return name;
    }

    public void setName(String name) {
    	this.name = name;
    }

    public String getPoid() {
        return poid;
    }

    public void setPoid(String poid) {
        this.poid = poid;
    }

    public String getTin() {
    	return tin;
    }
    
    public void setTin(String tin) {
    	this.tin = tin;
    }
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

	public List<Account> getAccounts() {
		return accounts;
	}
	
	public Account getDefaultAccount(){
		//TODO First account listed for client in CSV file is the "default"
		return accounts.get(0);
	}
	
	public void addAccount(Account account) {
		this.accounts.add(account);
	}
    
	public Region getRegion() {
        return region;
    }
    
    public void setRegion(Region region) {
        this.region = region;
    }

	public SegmentType getSegment() {
		return segment;
	}

	public void setSegment(SegmentType segement) {
		this.segment = segement;
	}
}
