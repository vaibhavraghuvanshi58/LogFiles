package com.vanguard.selenium.inner.environments;

import com.vanguard.selenium.inner.base.EnvironmentConfigAnnotation;
import com.vanguard.selenium.inner.base.EnvironmentConfigurationFactory;

public class EnvironmentConfigHandlerForAnnotation extends EnvironmentConfigHandler
{
	protected EnvironmentConfigAnnotation environmentConfigAnnotation;
	
    public EnvironmentConfigHandlerForAnnotation(EnvironmentConfigAnnotation environmentConfigAnnotation) {
        super();
        this.environmentConfigAnnotation = environmentConfigAnnotation;
    }

    public EnvironmentConfiguration handleRequest(EnvironmentConfiguration environmentConfig)
	{
        if(environmentConfigAnnotation != null) {
            BrowserType annotationBrowserType = environmentConfigAnnotation.browserType();
            String tags = environmentConfigAnnotation.tags();
    		if (annotationBrowserType!=null || tags!=null)
    		{           
    		    environmentConfig = EnvironmentConfigurationFactory.getEnvironment(annotationBrowserType);
                EnvironmentConfigOverrideValues overrideValues = new EnvironmentConfigOverrideValues(
                		environmentConfigAnnotation.tags(),
                        environmentConfigAnnotation.browserVersion(), 
                        environmentConfigAnnotation.osType(), 
                        environmentConfigAnnotation.osVersion(),
                        environmentConfigAnnotation.chromeDriverVersion(),
                        environmentConfigAnnotation.ieDriverVersion(),
                        environmentConfigAnnotation.deviceName(), 
                        environmentConfigAnnotation.deviceOrientation(), 
                        environmentConfigAnnotation.platformVersion(),
                        environmentConfigAnnotation.idleTimeout(),
                        environmentConfigAnnotation.screenResolution());
                
                overrideAnyCapabilityValuesPresent(environmentConfig, overrideValues);
    		}
        }
		return successorHanddler.handleRequest(environmentConfig);
	}
	
}