/*
 ****************************************************************************
 * 
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/IOSConfiguration.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author uz0s
 *
 */
public abstract class IOSConfiguration extends MobileConfiguration{
    
    public static final String PLATFORM_VERSION_DEFAULT_VALUE = "9.3";
    public static final String PLATFORM_NAME_DEFAULT_VALUE = "iOS";
    public static final String MOBILE_BROWSER_DEFAULT_VALUE = "Safari";
    
    public IOSConfiguration(DesiredCapabilities environmentCapabilities) {
        super(environmentCapabilities);
        addCapability(MobileConfiguration.PLATFORM_VERSION, PLATFORM_VERSION_DEFAULT_VALUE);
        addCapability(MobileConfiguration.PLATFORM_NAME, PLATFORM_NAME_DEFAULT_VALUE);
        addCapability(MobileConfiguration.MOBILE_BROWSER_NAME, MOBILE_BROWSER_DEFAULT_VALUE);
    }
}
