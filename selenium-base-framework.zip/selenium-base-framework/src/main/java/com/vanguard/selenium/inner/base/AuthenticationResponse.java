/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/AuthenticationResponse.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

import org.json.JSONObject;

import com.vanguard.selenium.inner.base.AuthenticationService.StatusMessageContainer;

/**
 * @author uc4b
 *
 */
public class AuthenticationResponse {
    
    private AuthenticationStatus authenticationStatus = AuthenticationStatus.FAILURE;
    
    private JSONObject jsonObject;


    public AuthenticationStatus getStatus() {
        return authenticationStatus;
    }


    public void setAuthenticationStatus(AuthenticationStatus status) {
        this.authenticationStatus = status;
        
    }

    /**
     * @param jsonObjectResponse
     */
    public void setJsonObject(JSONObject jsonObjectResponse) {
        this.jsonObject = jsonObjectResponse;
        
    }
    
    public JSONObject getJsonObject() {
        return jsonObject;
    }
}
