/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/PropertiesManager.java $
 $LastChangedRevision: 5583 $
 $Author: uz0s $
 $LastChangedDate: 2017-05-31 13:01:21 -0400 (Wed, 31 May 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.logon.user.ChannelType;

public class PropertiesManager {

    public static final String BASE_WINDOWS_URL = "baseWindowsUrl";

    public static final String RUN_TESTS_IN_UNIX = "runTestsInUnix";

    public static final String BASE_UNIX_RETAIL_EXTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_RETAIL_EXTERNAL_URL;

    public static final String BASE_UNIX_RETAIL_INTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_RETAIL_INTERNAL_URL;

    public static final String BASE_UNIX_SBS_EXTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_SBS_EXTERNAL_URL;

    public static final String BASE_UNIX_SBS_INTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_SBS_INTERNAL_URL;

    public static final String BASE_UNIX_INST_EXTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_INST_EXTERNAL_URL;

    public static final String BASE_UNIX_INST_INTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_INST_INTERNAL_URL;
    
    public static final String BASE_UNIX_PE_INTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_PE_INTERNAL_URL;

    public static final String BASE_UNIX_FAS_INTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_FAS_INTERNAL_URL;
    
    public static final String BASE_UNIX_MOBI_EXTERNAL_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_MOBILE_EXTERNAL_URL;

    public static final String BASE_UNIX_IOA_URL = PropertiesFileRegionToUrlMapper.BASE_UNIX_IOA_URL;
    
    public static final String REGION = "region";

    public static final String FIREBUG = "firebug";

    public static final String DEFAULT_USER = "defaultUser";

    public static final String BANK_USER = "bankUser";

    public static final String MARGIN_USER = "marginUser";

    public static final String BASE_WINDOWS_FILE_PATH = "baseWindowsFilePath";

    public static final String BASE_DIRECTORY = "src/test/resources/";

    public static final String PERF = "perf";    
    
    public static final String SCREENSHOT_DIRECOTRY_KEY = "screenShotDirectory";

    public static final String JENKINS_STRING_PARAM_TEST_PROPERTIES_KEY = "testProperties";
    
    private static Map<RegionProperties, Properties> properties;
    
    private static final String SELENIUM_SSI_FILE = "SELENIUM_SSI_FILE";

    public static String getProperty(String property, RegionProperties region, String baseDirectory) {
        if (properties == null) {
            try {
                properties = initializeRunProperties(baseDirectory);
            } catch (Exception e) {
                throw new RuntimeException("Error loading properties.", e);
            }
        }
        
        if(properties.get(region) != null) {
            return properties.get(region).getProperty(property);
        }
        
        LoggingUtility.logInfo("Using [defaults.properties] file to get property: " + property);
        return properties.get(RegionProperties.DEFAULT).getProperty(property);
    }
    
    /**WARNING: Be really sure you want to use this method before calling it.
     * This method will overwrite what you have in your settings file for the remainder of the JUnit run.
     * @param propertyNameToUpdate
     * @param newValue - The new value we will use to overwrite whatever it was
     * @param region - Specifying the property file to use (passing null will use defaults.properties)
     * @param baseDirectory - This should probably be PropertiesManager.BASE_DIRECTORY
     */
    public static void setProperty(String propertyNameToUpdate, String newValue, RegionProperties region, String baseDirectory){
        if (properties == null) {
            try {
                properties = initializeRunProperties(baseDirectory);
            } catch (Exception e) {
                throw new RuntimeException("Error trying to set a property.", e);
            }
        }
        if(properties.get(region) != null) {
            properties.get(region).setProperty(propertyNameToUpdate, newValue);
            return;
        }

        LoggingUtility.logDebug("Using Default.properties file to set property: " + propertyNameToUpdate);
        properties.get(RegionProperties.DEFAULT).setProperty(propertyNameToUpdate, newValue);
    }
    public static void setPropertyInDefaults(String name, String value){
        PropertiesManager.setProperty(name, value, RegionProperties.DEFAULT, PropertiesManager.BASE_DIRECTORY);
    }

    public static String getProperty(String property, RegionProperties region) {
        return getProperty(property, region, BASE_DIRECTORY);
    }

    public static String getProperty(String property) {
        if(getRegion() == null){
            LoggingUtility.logWarning("No region was loaded within the properties we've obtained yet.  We will get the property from defaults.properties file.");
            return getProperty(property, RegionProperties.DEFAULT);
        }
        String returnValue = getProperty(property, RegionProperties.fromRegionString(getRegion()));
        if(returnValue != null){
            return returnValue;
        }
        return getProperty(property, RegionProperties.DEFAULT);
    }

    public static String getRegion(RegionProperties region) {
        return getProperty(REGION, region);
    }
    public static String getRegion() {
        return getProperty(REGION, RegionProperties.DEFAULT);
    }

    public static boolean isDefaultSetToRunInRegion() {
        String runTestsInUnix = getProperty(RUN_TESTS_IN_UNIX);
        if (Boolean.TRUE.toString().equalsIgnoreCase(runTestsInUnix)) {
            return true;
        }
		return false;
    }
    
    @Deprecated
    /**We no longer need the input, should call the method without the input now**/
    public static boolean isDefaultSetToRunInRegion(RegionProperties region) {
        return isDefaultSetToRunInRegion();
    }

    public static Region getDefaultRegion() {
        return Region.fromString(getRegion(RegionProperties.DEFAULT));
    }

    public static String getDefaultBaseUrl(ChannelType channel) {
        return getRegionBaseUrl(channel, RegionProperties.DEFAULT);
    }

    @Deprecated
    /**We no longer need the input, should call the method without the input now**/
    public static String getRegionBaseUrl(ChannelType channel, RegionProperties region) {
        String baseUrl = StringUtils.EMPTY;
        boolean isSetToRunInTestRegion = isDefaultSetToRunInRegion(region);
        PropertiesFileRegionToUrlMapper urlMapper = new PropertiesFileRegionToUrlMapper();
        String propertyUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        baseUrl = PropertiesManager.getProperty(propertyUrl);

        LoggingUtility.logDebug("Base URL is " + baseUrl);
        return baseUrl;
    }
    
    public static String getRegionBaseUrl(ChannelType channel) {
        String baseUrl = StringUtils.EMPTY;
        boolean isSetToRunInTestRegion = isDefaultSetToRunInRegion();
        PropertiesFileRegionToUrlMapper urlMapper = new PropertiesFileRegionToUrlMapper();
        String propertyUrl = urlMapper.getPropertyUrlForChannelBasedOnLocalOrTestRegion(channel, isSetToRunInTestRegion);

        baseUrl = PropertiesManager.getProperty(propertyUrl);

        LoggingUtility.logDebug("Base URL is " + baseUrl);
        return baseUrl;
    }
    
    public static Map<RegionProperties, Properties> initializeRunProperties(String baseDirectory) throws Exception {
        final File ssiFile = createSSIFile();
        
        Map<RegionProperties, Properties> runProperties = new HashMap<RegionProperties, Properties>();
        if (ssiFile != null && ssiFile.exists()) {
            runProperties = initializeOverrideRunProperties(ssiFile);
        } else {
            runProperties = initializeDefaultRunProperties(baseDirectory);
        }
        
        return runProperties;
    }

    private static boolean shouldOverrideWithRegressionProperties(Map<RegionProperties, Properties> runProperties) {
        boolean returnVal = false;
        if(runProperties!=null){
            returnVal = (runProperties.get(RegionProperties.REGRESSION_MULTIMODULE_DEFAULT) != null) && 
                    (runProperties.get(RegionProperties.DEFAULT).getProperty("regressionRun") == null || runProperties.get(RegionProperties.DEFAULT).getProperty("regressionRun").equals("true") );
        }
        return returnVal;
    }

    private static File createSSIFile() {
        String ssiFileStr = System.getProperty(SELENIUM_SSI_FILE);
        File ssiFile = null;
        if (ssiFileStr != null) {
            ssiFileStr = StringUtils.remove(ssiFileStr, "file:");
            ssiFile = new File(ssiFileStr);
        }
        
        return ssiFile;
    }
    
    private static Map<RegionProperties, Properties> initializeOverrideRunProperties(File overrideFile) throws Exception {
        Map<RegionProperties, Properties> props = new HashMap<RegionProperties, Properties>();
        for (RegionProperties propertiesFile : RegionProperties.values()) {
            try {
                loadProperties(props, propertiesFile, overrideFile);
            } catch (FileNotFoundException fnfe) {
                LoggingUtility.logDebug("INFO: Properties file " + overrideFile.getPath() + " not found");
            }
        }
        if (props.isEmpty()) {
            LoggingUtility.logError("ERROR: No properties file found.");
            LoggingUtility.logError("ERROR: Please put a 'defaults.properties' file in src/test/resources");
        }
        return props;
    }
    
    private static Map<RegionProperties, Properties> initializeDefaultRunProperties(String baseDirectory) throws Exception {
        Map<RegionProperties, Properties> props = loadDefaultsPropertiesAndOverrideIfNeeded(baseDirectory);
        loadRegionPropertiesAndOverrideIfNeeded(baseDirectory, props);
        
        if (props.isEmpty()) {
            LoggingUtility.logError("ERROR: No properties file found.");
            LoggingUtility.logError("ERROR: Please put a 'defaults.properties' file in src/test/resources");
        }
        return props;
    }

    private static Map<RegionProperties, Properties> loadDefaultsPropertiesAndOverrideIfNeeded(String baseDirectory) throws FileNotFoundException, IOException {
        Map<RegionProperties, Properties> props = new HashMap<RegionProperties, Properties>();
        RegionProperties propsFileToLoad = RegionProperties.DEFAULT;
        loadPropertiesFromRegionPropertiesFile(baseDirectory, props, propsFileToLoad);
        loadAndPerformOverridePropertiesFileIfNeeded(props, propsFileToLoad);
        
        //Set properties to our props so far in case we need to look something up, like "region".
        properties = props;
        return props;
    }
    
    private static void loadRegionPropertiesAndOverrideIfNeeded(String baseDirectory, Map<RegionProperties, Properties> props) throws FileNotFoundException, IOException {
        if(getRegion() == null){
            LoggingUtility.logWarning("No region was retrieved within the properties we've obtained yet.  We will not load any *_region.properties files.");
            return;
        }
        RegionProperties propsFileToLoad = RegionProperties.fromRegionString(getRegion());
        loadPropertiesFromRegionPropertiesFile(baseDirectory, props, propsFileToLoad);
        loadAndPerformOverridePropertiesFileIfNeeded(props, propsFileToLoad);
    }

    private static void loadPropertiesFromRegionPropertiesFile(String baseDirectory, Map<RegionProperties, Properties> props, RegionProperties propsFileToLoad) throws FileNotFoundException, IOException {
        File propertiesFile = new File(baseDirectory + propsFileToLoad.getRegionFileName());
        loadProperties(props, propsFileToLoad, propertiesFile);
    }
    
    

    private static void loadAndPerformOverridePropertiesFileIfNeeded(Map<RegionProperties, Properties> props, RegionProperties propsFileToLoad) throws IOException {
        RegionProperties overrideFile = propsFileToLoad.determinOverrideFileBasedOnRegionFile();
        loadPropertiesFromClasspath(props, overrideFile);
        String type = "DEFAULT";
        if(propsFileToLoad.getRegionFileName().contains("_region.properties")){
            type = "REGION";
        }
        if(shouldOverrideWithRegressionProperties(props)){
            overrideProperties(props, type, propsFileToLoad);
        }
    }
    private static void overrideProperties(Map<RegionProperties, Properties> props, String type, RegionProperties fileWeAreOverriding) {
            LoggingUtility.logInfo("OVERRIDING " + type + " PROPERTY VALUES ** BEGIN ** - This project is being run as part of a Regression multi-module and may have some properties overridden.");
            Properties overrideProperties = props.get(fileWeAreOverriding.determinOverrideFileBasedOnRegionFile());
            //It's possible for a multi-module to set up overrides when a project has not specified a region or defaults file for their project
            //In that case, just add the file to the props mapping with no values and we'll add the override values in this method
            if(props.get(fileWeAreOverriding) == null){
                props.put(fileWeAreOverriding, new Properties());
            }
            
            //NGSA has set up a "testProperties" String Parameter for us to use in Jenkins Builds.
            //We can pass in key/values into this string and parse them here into System Properties.
            parseJenkinsTestPropertiesIntoSystemPropertyValues();
            
            for (Entry<Object, Object> regressionProperty : overrideProperties.entrySet()) {   
                  String key = (String) regressionProperty.getKey();   
                  String value = "";
                  
                  String systemProperty = System.getProperty(key);
                  if (StringUtils.isNotBlank(systemProperty)) {
                      LoggingUtility.logInfo("Property [" + key + "] is set via System Properties (possibly via a Jenkins parameter).  We're keeping the system value of [" + systemProperty + "]");
                      value = systemProperty;
                  } else {
                      value = (String) regressionProperty.getValue();
                  }
                  props.get(fileWeAreOverriding).setProperty(key, value);
                  LoggingUtility.logInfo("Overriding " + type + " property: properties file [" + fileWeAreOverriding.getRegionFileName() + "] prop name [" + key + "] setting new value [" + value + "]");
            }
            LoggingUtility.logInfo("OVERRIDING " + type + " PROPERTY VALUES ** END **");
    }

    protected static void parseJenkinsTestPropertiesIntoSystemPropertyValues() {
        String testProperties = System.getProperty(JENKINS_STRING_PARAM_TEST_PROPERTIES_KEY);
        if (StringUtils.isNotBlank(testProperties)) {
            String[] keyValuePairs = testProperties.split(";");
            for (String pair : keyValuePairs) {
                if(!pair.contains("=")){
                    LoggingUtility.logError("ERROR: Could not parse Jenkins String Parameter for key=value pair of: " + pair);
                } else {
                    String key = pair.substring(0, pair.indexOf("="));
                    String value = pair.substring(pair.indexOf("=") + 1, pair.length());
                    LoggingUtility.logInfo("*** Adding a key=value pair from Jenkins " + JENKINS_STRING_PARAM_TEST_PROPERTIES_KEY + " String Parameter: " + key + "=" + value);
                    System.setProperty(key, value);
                }
            }
        }
    }

    private static void loadProperties(Map<RegionProperties, Properties> props, RegionProperties propertiesFile, File file) throws FileNotFoundException, IOException {
        if(propertiesFile.isClassPathFile()){
            loadPropertiesFromClasspath(props, propertiesFile);
        } else {
            loadPropertiesFromFile(props, propertiesFile, file);
        }
    }

    private static void loadPropertiesFromClasspath(Map<RegionProperties, Properties> props, RegionProperties propertiesFile) throws IOException {
        Properties prop = new Properties();
        InputStream inputStream = PropertiesManager.class.getClassLoader().getResourceAsStream(propertiesFile.getRegionFileName());
        if(inputStream == null){
            //We don't have this file in the classpath, don't try to load anything from it
            return;
        }
        
        prop.load(inputStream);

        // If any System properties were defined, override the defaults
        Enumeration<Object> items = prop.keys();
        while (items.hasMoreElements()) {
            String key = (String) items.nextElement();
            String systemProperty = System.getProperty(key);
            if (StringUtils.isNotBlank(systemProperty)) {
                prop.setProperty(key, systemProperty);
            }
        }
        props.put(propertiesFile, prop);
    }

    private static void loadPropertiesFromFile(Map<RegionProperties, Properties> props, RegionProperties propertiesFile, File file) throws FileNotFoundException, IOException {
        InputStream in = null;
        try{
            in = new FileInputStream(file);
        }
        catch (Exception e) {
            LoggingUtility.logInfo("We attempted to load region the properties file for: " + file.getName() + ", but none exists for this project.");
            return;
        }
        Properties prop = new Properties();
        String propertyFileContents = convertStreamToString(in);
        prop.load(new ByteArrayInputStream(propertyFileContents.replace("\\", "\\\\").getBytes()));

        // If any System properties were defined, override the defaults
        Enumeration<Object> items = prop.keys();
        while (items.hasMoreElements()) {
            String key = (String) items.nextElement();
            String systemProperty = System.getProperty(key);
            if (StringUtils.isNotBlank(systemProperty)) {
                prop.setProperty(key, systemProperty);
            }
        }
        props.put(propertiesFile, prop);
    }

    private static String convertStreamToString(java.io.InputStream is) {
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }

    public static boolean isRunningOnWindows() {
        return System.getProperty("os.name").contains("Windows");
    }

    public static boolean isRunningOnWindowsXP() {
        final String osName = System.getProperty("os.name");
        return osName.contains("Windows") && osName.contains("XP");
    }
    
    public static boolean isPerf(RegionProperties regionProperties) {
        final String value = PropertiesManager.getProperty(PERF,regionProperties);
        return BooleanUtils.toBoolean(value);
    }    

    //Needed for Test class to fully test this class
    public void reInitializeProperties() throws Exception{
        if(properties != null){
            Properties regionPropsToClear = properties.get(RegionProperties.DEFAULT);
            if(regionPropsToClear != null){
                regionPropsToClear.clear();
            }
        }
        properties = initializeRunProperties(BASE_DIRECTORY);
    }
    protected void reInitializePropertiesAfterRegionChange() throws FileNotFoundException, IOException {
        Properties regionPropsToClear = properties.get(RegionProperties.E);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        regionPropsToClear = properties.get(RegionProperties.F);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        regionPropsToClear = properties.get(RegionProperties.X);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        regionPropsToClear = properties.get(RegionProperties.M);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        regionPropsToClear = properties.get(RegionProperties.P);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        regionPropsToClear = properties.get(RegionProperties.S);
        if(regionPropsToClear != null){
            regionPropsToClear.clear();
        }
        //Now that all the old region files that might have been loaded have been cleared
        //We need to load the proper region files (and possibly override) based on the new region
        loadRegionPropertiesAndOverrideIfNeeded(PropertiesManager.BASE_DIRECTORY, properties);
    }
}
