/*
 ****************************************************************************
 *
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/CouldNotFindCorrectPageException.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
*/
package com.vanguard.selenium.inner.core.utils;

import org.openqa.selenium.WebDriver;

/**
 * @author uz0s
 *
 */
@Deprecated /** Please use com.vanguard.selenium.inner.base.PageNavigationException in test-data-framework project instead of this deprecated class. **/
public class CouldNotFindCorrectPageException extends Exception {
	
	private static final long serialVersionUID = 1L;

	//Parameterless Constructor
    public CouldNotFindCorrectPageException() {}

    //Constructor that accepts a message
    public CouldNotFindCorrectPageException(String message)
    {
       super(message);
    }

    /**Constructor that takes a screenshot of the current WebDriver. 
     * The screenshot will take the name specified and put in the path specified.
     * */
    public CouldNotFindCorrectPageException(String message, WebDriver driver, String screenShotFilePath, String screenShotFileName)
    {
    	super(message);
   		ScreenshotUtils.takeScreenShot(screenShotFileName, driver, screenShotFilePath);
    }
}
