/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/VgiAuthenticatedWebDriver.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.util.List;
import java.util.Set;

import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

/**
 * @author ubmq
 * 
 */
public class VgiAuthenticatedWebDriver implements AuthenticatedWebDriver, TakesScreenshot, JavascriptExecutor, HasInputDevices {
    
    
    
    static final int MAX_RETRIES = 5;

    static final String DRIVER_NULL_EXCEPTION = "Driver cannot be null";

    private WebDriver driver;

    private String userName;
    
    private AuthenticationService authenticationService = AuthenticationService.getInstance();
    private CookieService cookieService = new CookieService();

    VgiAuthenticatedWebDriver() {
    }

    public VgiAuthenticatedWebDriver(WebDriver driver, String userName, String password) {
        constuctAuthenticatedWebDriver(driver, userName, password);
    }

    void constuctAuthenticatedWebDriver(WebDriver driver, String userName, String password) {
        if(driver == null){
            throw new IllegalArgumentException(DRIVER_NULL_EXCEPTION);
        }
        
        this.setDriver(driver);
        this.userName = userName;
        
        authenticationService.verifyValidInputs(userName, password);
        // Go to Vanguard home page - covers scenarios where home page is not in Vanguard domain
        authenticationService.navigateToAVanguardDomainSite(driver);
        
        AuthenticationResponse authenticationResponse = authenticate(userName, password);
        JSONObject responseJSonObject = authenticationResponse.getJsonObject();
        List<Cookie> cookies = cookieService.getCookies(responseJSonObject);
        cookieService.addAllCookiesToDriver(driver, cookies);
    }

    
    
    @Deprecated
    /** No longer using internalServerUri or protectedResourceUri **/
    public VgiAuthenticatedWebDriver(WebDriver driver, String userName, String password, String internalServerUri) {
        this(driver, userName, password);
    }

    @Deprecated
    /** No longer using internalServerUri or protectedResourceUri **/
    public VgiAuthenticatedWebDriver(WebDriver driver, String userName, String password, String internalServerUri, String protectedResourceUri) {
        this(driver, userName, password);
    }

    protected AuthenticationResponse authenticate(String userID, String password) {
        AuthenticationChainOfResponsibilityLink authenticationChainLink = createAuthenticationChainLink(); 
        AuthenticationResponse response = authenticationChainLink.authenticateChainLink(userID, password);
        return response;
        
    }

    SSGAuthenticationChainLink createAuthenticationChainLink() {
        return new SSGAuthenticationChainLink (
                new SSGAuthenticationChainLink(
                 new SSGAuthenticationChainLink(
                  new SSGAuthenticationChainLink(
                   new SSGAuthenticationChainLink(
                    new SSGAuthenticationChainLink(
                     new FailureAuthenticationChainLink()
                     ,AuthenticationUrl.SAT)
                    ,AuthenticationUrl.CAT)
                   ,AuthenticationUrl.SAT)
                  ,AuthenticationUrl.INT)
                 ,AuthenticationUrl.DEV)
                ,AuthenticationUrl.SAT);
    }    

    void setAuthenticationService(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }
    
    void setCookieService(CookieService cookieService) {
        this.cookieService = cookieService;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.vanguard.util.AuthenticatedWebDriver#getAuthenticatedUserId()
     */
    @Deprecated/**This method is no longer supported.  There is no reason you should need to get the userName off the authenticatedDriver object**/
    public String getAuthenticatedUserId() {
        return userName;
    }


    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#close()
     */
    @Deprecated/**This method should never be called.  The Inner Source framework will close the driver at the end of each test automatically**/
    public void close() {
        getDriver().close();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#findElement(org.openqa.selenium.By)
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public WebElement findElement(By arg0) {
        return getDriver().findElement(arg0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#findElements(org.openqa.selenium.By)
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public List<WebElement> findElements(By arg0) {

        return getDriver().findElements(arg0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#get(java.lang.String)
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public void get(String arg0) {
        getDriver().get(arg0);

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#getCurrentUrl()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public String getCurrentUrl() {

        return getDriver().getCurrentUrl();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#getPageSource()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public String getPageSource() {

        return getDriver().getPageSource();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#getTitle()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public String getTitle() {

        return getDriver().getTitle();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#getWindowHandle()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public String getWindowHandle() {

        return getDriver().getWindowHandle();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#getWindowHandles()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public Set<String> getWindowHandles() {

        return getDriver().getWindowHandles();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#manage()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public Options manage() {

        return getDriver().manage();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#navigate()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public Navigation navigate() {

        return getDriver().navigate();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#quit()
     */
    @Deprecated/**This method should never be called.  The Inner Source framework will close the driver at the end of each test automatically**/
    public void quit() {
        getDriver().quit();

    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.WebDriver#switchTo()
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public TargetLocator switchTo() {

        return getDriver().switchTo();
    }
    
    /**
     * Used for retrieving the session Id if a remote driver is used.
     * 
     * @return SessionId object
     */
    @Deprecated/**Use the methods off the VanguardBasePageImpl instead**/
    public SessionId getSessionId() {
        WebDriver aDriver = getDriver();
        SessionId sessionId = null;
        
        if( aDriver instanceof RemoteWebDriver ) {
            sessionId = ((RemoteWebDriver) aDriver).getSessionId();
        }
        
        return sessionId;
    }


    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.TakesScreenshot#getScreenshotAs(org.openqa.selenium.OutputType)
     */
    @Deprecated/**Use the methods within ScreenshotUtility instead**/
    public <X> X getScreenshotAs(OutputType<X> arg0) throws WebDriverException {
        return ((TakesScreenshot) getDriver()).getScreenshotAs(arg0);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.JavascriptExecutor#executeAsyncScript(java.lang.String, java.lang.Object[])
     */
    @Deprecated/**There should be no need to use JavascriptExecutor's at Vanguard.  An Inner Source method should be created for any true need that arises for this.**/
    public Object executeAsyncScript(String arg0, Object... arg1) {
        return ((JavascriptExecutor) getDriver()).executeAsyncScript(arg0, arg1);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.openqa.selenium.JavascriptExecutor#executeScript(java.lang.String, java.lang.Object[])
     */
    @Deprecated/**There should be no need to use JavascriptExecutor's at Vanguard.  An Inner Source method should be created for any true need that arises for this.**/
    public Object executeScript(String arg0, Object... arg1) {
        return ((JavascriptExecutor) getDriver()).executeScript(arg0, arg1);
    }

    /**
     * @return the driver
     */
    private WebDriver getDriver() {
        return driver;
    }

    /**
     * @param driver the driver to set
     */
    void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    public Keyboard getKeyboard() {
        return ((HasInputDevices) getDriver()).getKeyboard();
    }

    public Mouse getMouse() {
        return ((HasInputDevices) getDriver()).getMouse();
    }

    @Override
    public List<String> getAuthenticatedUserSbfs() {
        return null;
    }

}
