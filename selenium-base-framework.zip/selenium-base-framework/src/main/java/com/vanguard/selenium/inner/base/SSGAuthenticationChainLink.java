/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/SSGAuthenticationChainLink.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

import org.json.JSONObject;

import com.vanguard.selenium.inner.base.AuthenticationService.StatusMessageContainer;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author uc4b
 *
 */
public class SSGAuthenticationChainLink extends AuthenticationChainOfResponsibilityLink {

    private final AuthenticationUrl authenicationUrl; 
    
    public SSGAuthenticationChainLink(AuthenticationChainOfResponsibilityLink nextLinkChainLink, AuthenticationUrl authenticationUrl) {
        super(nextLinkChainLink);
        this.authenicationUrl  = authenticationUrl;
    }

    @Override
    AuthenticationResponse authenticate(String username, String password) {
        AuthenticationResponse authenticationResponse = new AuthenticationResponse();
        try {
            JSONObject jsonObjectResponse = authenticationService.getPOSTAuthenticationRequestResponse(authenicationUrl, username, password);
            StatusMessageContainer statusMessageContainer = authenticationService.getJSONResponseFromJSONOject(jsonObjectResponse);
            authenticationResponse.setJsonObject(jsonObjectResponse);
            authenticationResponse.setAuthenticationStatus(statusMessageContainer.getAuthenticationStatus());
            
        } catch (Exception e) {
            LoggingUtility.logError("Failure Authenticating will attempt another channel.  Failure message: " + e.getMessage());
        }
        return authenticationResponse;
    }

}
