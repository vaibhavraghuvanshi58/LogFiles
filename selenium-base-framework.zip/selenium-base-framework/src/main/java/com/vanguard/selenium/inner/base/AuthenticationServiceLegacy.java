/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/AuthenticationServiceLegacy.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
 */
package com.vanguard.selenium.inner.base;

import static com.vanguard.selenium.inner.base.PropertiesManager.BASE_UNIX_RETAIL_INTERNAL_URL;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.auth.AuthenticationException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.BasicHttpContext;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author uz0s
 * 
 */
public class AuthenticationServiceLegacy {

    static final String DRIVER_NULL_EXCEPTION = "Driver cannot be null";

    static final String IO_EXCEPTION_MESSAGE = " - IO Exception.";
    static final String GENERAL_EXCEPTION_MESSAGE = " - General Exception.";
    static final String ACCESS_DENIED_MESSAGE = ". Access denied.";
    static final String AUTH_FAIL_EXCEPTION_PREFIX = "Authentication failed accessing ";
    static final String PROTECTED_URI_BLANK_EXCEPTION = "Protected resource URI cannot be blank";
    static final String SERVER_URI_BLANK_EXCEPTION = "Internal server URI cannot be blank";
    static final String PASSWORD_BLANK_EXCEPTION = "Password cannot be blank";
    static final String USER_NAME_BLANK_EXCEPTION = "User Name cannot be blank";
    static final String INCORRECT_HOST_URI_SYNTAX_EXCEPTION = " - Incorrect Host URI syntax.";
    static final String HTTP_PROTOCOL_EXCEPTION_MESSAGE = ". Problem with HTTP Protocol.";
    
    private AuthenticationService authenticationService = AuthenticationService.getInstance();
    private CookieService cookieService = new CookieService();

    /**Authenticate for RETAIL via Legacy Method **/
    public void authenticateLegacyMethod(WebDriver driver, String userName, String password) {
    	authenticateLegacyMethod(driver, userName, password, PropertiesManager.getProperty(BASE_UNIX_RETAIL_INTERNAL_URL), "us/ServiceUtilityServlet");
    }
    
    /**Authenticate for ANY SYSTEM by specifying the InternalServerUri and ProtectedResourceUri via Legacy Method **/
    public void authenticateLegacyMethod(WebDriver driver, String localUserName, String localPassword, String localInternalServerUri, String localProtectedResourceUri) {
        if(driver == null){
            throw new IllegalArgumentException(DRIVER_NULL_EXCEPTION);
        }
        
        // Go to Vanguard home page - covers scenarios where home page is not in Vanguard domain
        authenticationService.navigateToAVanguardDomainSite(driver);
        
        if(StringUtils.startsWith(localProtectedResourceUri, "/") || StringUtils.startsWith(localProtectedResourceUri, "http")) {
            //Leave as is
        } else {
        	localProtectedResourceUri = "/" + localProtectedResourceUri;
        }
        
    	try {
        	List<Cookie> cookies = getCookiesViaAuthenticateLegacyMethod(localUserName, localPassword, localProtectedResourceUri, localInternalServerUri);
        	driver.get(localInternalServerUri); //To set to the correct domain so we can add cookies
        	cookieService.addAllCookiesToDriver(driver, cookies);
            LoggingUtility.logInfo("SUCCESSFUL AUTHENTICATION: Completed authenticating against: " + localInternalServerUri + localProtectedResourceUri);
        } catch (AuthenticationException e) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + ACCESS_DENIED_MESSAGE, e);
        } catch (ClientProtocolException e) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + HTTP_PROTOCOL_EXCEPTION_MESSAGE, e);
        } catch (IOException e) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + IO_EXCEPTION_MESSAGE, e);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + INCORRECT_HOST_URI_SYNTAX_EXCEPTION, e);
        } 
        
        //If there was a problem, but none of the above, then do a catch-all here with a more general error message
        catch (Exception e) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + GENERAL_EXCEPTION_MESSAGE, e);
        } catch (Throwable t) {
            throw new IllegalArgumentException(AUTH_FAIL_EXCEPTION_PREFIX + localInternalServerUri + localProtectedResourceUri
                    + GENERAL_EXCEPTION_MESSAGE, t);
        }
    }
	
	
    
    private List<Cookie> getCookiesViaAuthenticateLegacyMethod(String localUserName, String localPassword, String localProtectedResourceUri, String localInternalServerUri) throws IOException, ClientProtocolException, AuthenticationException, URISyntaxException, Exception {
            HttpClientAuthenticator clientAuthenticator = new HttpClientAuthenticator();
            HttpClientBuilder myClientBuilder = HttpClientBuilder.create();
            CookieStore cookieStore = new BasicCookieStore();
            myClientBuilder.setDefaultCookieStore(cookieStore);
            clientAuthenticator.addNtCredentialsToClientBuilder(localUserName, localPassword, myClientBuilder);
            clientAuthenticator.setupClientBuilderWithAuthSchemes(myClientBuilder);
            //Starting in 2015.0900 there is a circular redirect with the authentication and this bypasses the circular redirect exception  
            RequestConfig.Builder requestBuilder = RequestConfig.custom().setCircularRedirectsAllowed(true);
            myClientBuilder.setDefaultRequestConfig(requestBuilder.build());
            CloseableHttpClient myClient = myClientBuilder.build();

            retrieveHttpResponseFromProtectedUriLegacyMethod(myClient, localUserName, localProtectedResourceUri, localInternalServerUri);

            List<Cookie> seleniumCookies = clientAuthenticator.translateClientCookiesIntoSeleniumCookies(cookieStore);
            return seleniumCookies;
    }

    private HttpResponse retrieveHttpResponseFromProtectedUriLegacyMethod(CloseableHttpClient myClient, String localUserName, String localProtectedResourceUri, String localInternalServerUri)
            throws IOException, ClientProtocolException, AuthenticationException, URISyntaxException {
        
        URI hostUri = new URI(localInternalServerUri);
        
        HttpHost target = new HttpHost(hostUri.getHost(), hostUri.getPort(), hostUri.getScheme());
        
        HttpGet httpGet = new HttpGet(localProtectedResourceUri);
        
        BasicHttpContext authContext = new BasicHttpContext();
        HttpResponse response = myClient.execute(target, httpGet, authContext);
        
        StatusLine statusLine = response.getStatusLine();
        
        determineAuthenticationSuccessLegacyMethod(localUserName, localProtectedResourceUri, localInternalServerUri, statusLine);
        return response;
    }

    private void determineAuthenticationSuccessLegacyMethod(String localUserName, String localProtectedResourceUri, String localInternalServerUri, StatusLine statusLine)
            throws AuthenticationException {
        if (statusLine.getStatusCode() != 200) {
            throw new AuthenticationException("Failed to authenticate user ID: " + localUserName + ".  Attempted to authenticate access to: "
                    + localInternalServerUri + '/' + localProtectedResourceUri);
        }
    }

}
