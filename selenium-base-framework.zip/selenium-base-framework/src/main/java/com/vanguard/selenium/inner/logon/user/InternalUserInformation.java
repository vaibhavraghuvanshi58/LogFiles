/*
 ****************************************************************************
 * 
 * Copyright (c)2011 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/logon/user/InternalUserInformation.java $
 $LastChangedRevision: 3342 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 17:17:12 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.logon.user;

import com.vanguard.selenium.inner.base.Region;

/**
 * @author urkh
 * 
 */
@Deprecated
/** Use TestCrewMemberInformation instead **/
public class InternalUserInformation {

    private TestCrewMemberInformation crewInfo;
    
    public InternalUserInformation(String poid, String userId) {
        this.crewInfo = new TestCrewMemberInformation();
        this.crewInfo.setPoid(poid);
        this.crewInfo.setUserId(userId);
    }

    public InternalUserInformation(String poid, String userId, String password) {
        this.crewInfo = new TestCrewMemberInformation();
        this.crewInfo.setPoid(poid);
        this.crewInfo.setUserId(userId);
        this.crewInfo.setPassword(password);
    }

    /**
     * 
     */
    public InternalUserInformation() {
        this.crewInfo = new TestCrewMemberInformation();
    }

    public String getPoid() {
        return this.crewInfo.getPoid();
    }

    public void setPoid(String poid) {
        this.crewInfo.setPoid(poid);
    }

    public String getUserId() {
        return this.crewInfo.getUserId();
    }

    public void setUserId(String userId) {
        this.crewInfo.setUserId(userId);
    }

    /**
     * @return
     */
    public String getPassword() {
        return this.crewInfo.getPassword();
    }

    /**
     * @param region
     */
    public void setRegion(Region region) {
        this.crewInfo.setRegion(region);
    }

    /**
     * @return the crewType
     */
    public String getCrewType() {
        return this.crewInfo.getCrewType();
    }

    /**
     * @param crewType
     *            the crewType to set
     */
    public void setCrewType(String crewType) {
        this.crewInfo.setCrewType(crewType);
    }

    /**
     * @return the region
     */
    public Region getRegion() {
        return this.crewInfo.getRegion();
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
        this.crewInfo.setPassword(password);
    }

    /**
     * @return the crewInfo
     */
    public TestCrewMemberInformation getCrewInfo() {
        return crewInfo;
    }

    /**
     * @param crewInfo the crewInfo to set
     */
    public void setCrewInfo(TestCrewMemberInformation crewInfo) {
        this.crewInfo = crewInfo;
    }
    
    
}
