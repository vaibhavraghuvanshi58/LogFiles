/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/ScreenshotUtils.java $
 $LastChangedRevision: 2028 $
 $Author: uz0s $
 $LastChangedDate: 2015-11-03 15:06:47 -0500 (Tue, 03 Nov 2015) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;

public class ScreenshotUtils {

    /**
     * Takes a screenshot and saves it in the default file path. For a Jenkins job, check your workspace folder.
     */
    public static void takeScreenShot(String className, WebDriver driver) {
        String filePath = "";
        takeScreenShot(className, driver, filePath);
    }

    /**
     * Takes a screen shot and saves the file in the filePath specified adding a timestamp to the className
     */
    public static void takeScreenShot(String className, WebDriver driver, String filePath) {
    	takeScreenShot(filePath, filePath + className + "()-" + getTimestamp() + ".png", driver);
    }
    
    /**
     * Takes a screen shot and saves the file in the filePath specified
     */
    public static void takeScreenShot(String filePath, String fullFilePathAndName, WebDriver driver) {
    	WebDriver driverToUse = driver;
    	//TODO: Find out how to add in a correct check to do the augment for real RemoteWebDrivers.
    	//The below check is returning true for a regular ChromeDriver instance (that's not remote).
    	if ((driver instanceof RemoteWebDriver) && !(driver instanceof ChromeDriver)){
    		try{
    			driverToUse = new Augmenter().augment(driver);
    		} catch (Exception e) {
    			driverToUse = driver;
			}
    	}
        try {
            new File(filePath).mkdirs();
            File screenShot = ((TakesScreenshot) driverToUse).getScreenshotAs(OutputType.FILE); // take the screen shot
            if(DriverUtils.isWindoze()){
                if(fullFilePathAndName.length() > 255) {
                	//File names shouldn't be that long.  Windows only even allows 255, lets limit to 250 just to be safe.
                	fullFilePathAndName = fullFilePathAndName.substring(0, 250) + ".png";
                }
            }
            FileUtils.copyFile(screenShot, new File(fullFilePathAndName)); // move the file
        } catch (Exception e) {
            /*
             * We are not going to handle the screen shot failing Common causes are the browser already being closed or an issue writing \ copying the
             * file
             */
        	LoggingUtility.logError("Could not capture screenshot.  Here's a stacktrace of the error:\nMessage: " + e.getMessage() + "\n");
        	e.printStackTrace();
        }
    }


    /**
     * Takes a screen shot that ensures the entire WebElement specified is captured and saves the file in the filePath specified.
     * This can be used to capture "scrolling pages" by specifying the outer table, or an element encompassing more than just the currently visible area.
     */
    public static void takeScreenshotElement(WebElement element, WebDriver driver, String filePath, String fileName) {
    	int elemWidth = element.getSize().width;
    	int elemHeight = element.getSize().height;
    	String fullFilePathAndName = filePath + fileName + "()-" + getTimestamp() + ".png";
    	takeScreenShot(filePath, fullFilePathAndName, driver);
    	SeleniumWaitHelper.pause(1);
    	File screeshotFile = new File(fullFilePathAndName);
    	BufferedImage bimg = null;
		try {
			bimg = ImageIO.read(screeshotFile);
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
    	int imgWidth = bimg.getWidth();
    	int imgHeight = bimg.getHeight();
    	
    	if((imgWidth >= elemWidth) && (imgHeight >= elemHeight)){
    		//we included all of the element in the screenshot, we're done
    		return;
    	}
    	
    	//Take off 30 px for the scroll bars
    	imgWidth = imgWidth - 30;
    	imgHeight = imgHeight - 30;
    	
    	//We need to scroll either right, down, or both to capture the whole element
    	int count = 1;
    	screeshotFile.renameTo(new File(fullFilePathAndName.replace("()", "()_" + count)));
    	
    	if((imgWidth + 30) >= elemWidth){
    		count = takePicsUntilAllHeightIsCovered(driver, fileName, filePath, elemHeight, imgHeight, count, count);
    	} else if((imgHeight + 30) >= elemHeight){
    		//Only need to worry about width
    		do{
	    		JavascriptExecutor jsx = (JavascriptExecutor)driver;
	    		jsx.executeScript("window.scrollBy(" + imgWidth + ",0)", "");
	    		SeleniumWaitHelper.pause(2);
	    		count ++;
	    		fullFilePathAndName = filePath + fileName + "()_" + count + "-" + getTimestamp() + ".png";
	    		takeScreenShot(fileName, fullFilePathAndName, driver);
    		}while((imgWidth * (count)) < elemWidth);
    	} else {
    		//Need to worry about both width and height.
    		count = takePicsUntilAllHeightIsCovered(driver, fileName, filePath, elemHeight, imgHeight, count, count);
    		do{
	    		JavascriptExecutor jsx = (JavascriptExecutor)driver;
	    		jsx.executeScript("window.scrollBy(" + imgWidth + "," + -imgHeight*count + ")", "");
	    		SeleniumWaitHelper.pause(2);
	    		count ++;
	    		fullFilePathAndName = filePath + fileName + "()_" + count + "-" + getTimestamp() + ".png";
	    		takeScreenShot(fileName, fullFilePathAndName, driver);
	    		count = takePicsUntilAllHeightIsCovered(driver, fileName, filePath, elemHeight, imgHeight, 1, count);
    		}while((imgWidth * (count)) < elemWidth);
    	}
    }

	private static int takePicsUntilAllHeightIsCovered(WebDriver driver, String fileName, String filePath, int elemHeight, int imgHeight, int heightCount, int picCount) {
		int count = picCount;
		int curHeightCount = heightCount;
		do{
			JavascriptExecutor jsx = (JavascriptExecutor)driver;
			jsx.executeScript("window.scrollBy(0," + imgHeight + ")", "");
			SeleniumWaitHelper.pause(2);
			count ++;
			curHeightCount++;
			takeScreenShot(filePath, filePath + fileName + "()_" + count + "-" + getTimestamp() + ".png", driver);
		}while((imgHeight * (curHeightCount)) < elemHeight);
		return count;
	}
	
    
    /**
     * Takes a screen shot and return the byte[] oject back so you can embed it in cucumber scenario results
     */
	public static byte[] getScreenshotBytes(WebDriver driver) {
    	WebDriver driverToUse = driver;
    	//TODO: Find out how to add in a correct check to do the augment for real RemoteWebDrivers.
    	//The below check is returning true for a regular ChromeDriver instance (that's not remote).
    	if ((driver instanceof RemoteWebDriver) && !(driver instanceof ChromeDriver)){
    		try{
    			driverToUse = new Augmenter().augment(driver);
    		} catch (Exception e) {
    			driverToUse = driver;
			}
    	}
        try {
            return ((TakesScreenshot) driverToUse).getScreenshotAs(OutputType.BYTES); // take the screen shot
        } catch (Exception e) {
            /*
             * We are not going to handle the screen shot failing Common causes are the browser already being closed or an issue writing \ copying the
             * file
             */
        	LoggingUtility.logError("Could not capture screenshot.  Here's a stacktrace of the error:\nMessage: " + e.getMessage() + "\n");
        	e.printStackTrace();
        }
        return null;
	}
    
    
    public static String getTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy-HH-mm-ss");
        String string = formatter.format(new Date());
        return string;
    }

}