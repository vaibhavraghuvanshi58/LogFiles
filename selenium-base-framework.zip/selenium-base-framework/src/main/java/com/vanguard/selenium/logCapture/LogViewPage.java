package com.vanguard.selenium.logCapture;
/*
 ****************************************************************************
 * 
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/logCapture/LogViewPage.java $
 $LastChangedRevision: 3357 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-15 11:38:37 -0400 (Wed, 15 Jun 2016) $
*/


import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;
import org.openqa.selenium.support.ui.SystemClock;

import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.pages.VanguardBasePageImpl;

public class LogViewPage extends VanguardBasePageImpl{
	
    private static final String UNIX_INTERNAL_DIAGNOSTIC_LOG = "unixInternalDiagnosticLog";
	private static final String UNIX_EXTERNAL_DIAGNOSTIC_LOG = "unixExternalDiagnosticLog";

	@FindBy(xpath = "//td[@colspan = '6']/b")
    private List<WebElement> logMessageWebElements;
	
	private WebDriver driver;
	private String sessionId; 
	private boolean isExternalTest;
	protected ElementLocatorFactory elementFactory;

	public LogViewPage(WebDriver driver, String sessionId, boolean isExternalTest) {
		super(driver);
		this.driver = driver;
		this.sessionId = sessionId;
		this.isExternalTest = isExternalTest;
		elementFactory = new AjaxElementLocatorFactory(driver, 5);
		PageFactory.initElements(elementFactory, this);
	}
	
	public String getPageUrl() {
		return String.format("http://devlogview.vanguard.com:1080/cgi-bin/logview?file=%s&time=&host=&app=&pid=&mod=&sid=%s&type=error&code=&time=&host=&app=&pid=&mod=&sid=&type=&code=&time=&host=&app=&pid=&mod=&sid=&type=&code=&time=&host=&app=&pid=&mod=&sid=&type=&code=&time=&host=&app=&pid=&mod=&sid=&type=&code=&Filter=View+Filtered+Entries",
				getLogFile(), sessionId);
	}
	
	private String getLogFile() {
		String returnValue = "";
		if( isExternalTest ) {
			returnValue = PropertiesManager.getProperty(UNIX_EXTERNAL_DIAGNOSTIC_LOG);
		} else {
			returnValue = PropertiesManager.getProperty(UNIX_INTERNAL_DIAGNOSTIC_LOG);
		}
		return returnValue;
	}

	public void navigateTo() {
	    load();
    }

	@Deprecated
	protected void isLoaded() throws Error {
	    Assert.assertTrue(isCurrentlyLoaded());
	}
    public boolean isCurrentlyLoaded() {
        final String expectedUrl = getPageUrl().toLowerCase();
        final String currentUrl = driver.getCurrentUrl().toLowerCase();
        return currentUrl.contains(expectedUrl);
    }
	
	protected void load() {
		driver.get(getPageUrl());
	}

	public List<WebElement> getLogMessageWebElements() {
		return logMessageWebElements;
	}


	
}
