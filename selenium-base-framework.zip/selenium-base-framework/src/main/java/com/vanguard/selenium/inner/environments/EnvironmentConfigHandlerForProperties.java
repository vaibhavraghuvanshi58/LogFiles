package com.vanguard.selenium.inner.environments;

import com.vanguard.selenium.inner.base.EnvironmentConfigurationFactory;
import com.vanguard.selenium.inner.base.PropertiesManager;

public class EnvironmentConfigHandlerForProperties extends EnvironmentConfigHandler
{
    public EnvironmentConfigHandlerForProperties() {
        super();
    }

    public EnvironmentConfiguration handleRequest(EnvironmentConfiguration environmentConfig)
	{
		if (PropertiesManager.getProperty(EnvironmentConfiguration.BROWSER_TYPE) != null)
		{           
		    environmentConfig = EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile());
		    EnvironmentConfigOverrideValues overrideValues = new EnvironmentConfigOverrideValues(
		    		PropertiesManager.getProperty(EnvironmentConfiguration.SAUCELABS_TAG_LABELS),
		            PropertiesManager.getProperty(EnvironmentConfiguration.BROWSER_VERSION), 
		            PropertiesManager.getProperty(EnvironmentConfiguration.OS_TYPE), 
		            PropertiesManager.getProperty(EnvironmentConfiguration.OS_VERSION),
		            PropertiesManager.getProperty(EnvironmentConfiguration.CHROME_DRIVER_VERSION),
		            PropertiesManager.getProperty(EnvironmentConfiguration.IE_DRIVER_VERSION),
		            PropertiesManager.getProperty(MobileConfiguration.DEVICE_NAME), 
		            PropertiesManager.getProperty(MobileConfiguration.DEVICE_ORIENTATION), 
		            PropertiesManager.getProperty(MobileConfiguration.PLATFORM_VERSION),
		            PropertiesManager.getProperty(MobileConfiguration.IDLE_TIMEOUT),
		            PropertiesManager.getProperty(MobileConfiguration.SCREEN_RESOLUTION));
		    
	        overrideAnyCapabilityValuesPresent(environmentConfig, overrideValues);
		}
		return successorHanddler.handleRequest(environmentConfig);
	}

 }