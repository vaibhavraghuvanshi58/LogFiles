/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/ParameterizedBaseTest.java $
 $LastChangedRevision: 3342 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 17:17:12 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.base;

import static com.vanguard.selenium.inner.base.PropertiesManager.REGION;
import static org.junit.Assume.assumeTrue;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.utils.CommonUtility;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.ScreenshotUtils;
import com.vanguard.selenium.inner.testdata.TestCase;
import com.vanguard.selenium.inner.testdata.TestCaseExt;
import com.vanguard.selenium.inner.testdata.TestCases;
import com.vanguard.selenium.inner.testdata.TestData;
import com.vanguard.selenium.inner.testdata.TestDataRequest;
import com.vanguard.selenium.inner.testdata.TestDataUtil;
import com.vanguard.selenium.inner.testdata.XmlReader;

@Ignore
@RunWith(NamedParameterized.class)
public abstract class ParameterizedBaseTest extends VanguardBaseTest{
    private static final String GENERIC_ERROR_LOG = "Error populating test data field(s)";

    protected TestCase testCase;

    private String allTestValuesAsString = StringUtils.EMPTY;

    protected final Map<String, String> testValues = new HashMap<String, String>();

    private final String className = getClass().getSimpleName();

    private boolean isdataLoaded = false;

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.FIELD)
    public @interface TestDataAttribute {

        String name() default StringUtils.EMPTY;

        String defaultValue() default StringUtils.EMPTY;
    }

    @Rule
    public TestWatcher parameterizedMethodRule = new TestWatcher() {
        @Override
        public void failed(Throwable e, Description method) {
            printHeader();
            
            if(!isdataLoaded) {
                printIgnoreInfo(method);
            } 
            else {
                printFailureInfo(method);
            }
            
            printHeader();
        }

        private void printFailureInfo(Description method) {
        	final String methodName = StringUtils.substringBefore(method.getMethodName(), "[");
            System.out.println("Failure for: " + className + "." + methodName + "    Time:  " + getTimestamp());
            printTestCaseInfo();
            System.out.println("Test Data Values: " + getAllTestValuesAsString());
            
            try {
                System.out.println("Current URL: " + driver.getCurrentUrl());
                System.out.println("Cookie info: " + CommonUtility.getSessionInfoFromCookie(driver));
                ScreenshotUtils.takeScreenShot("FAILURE-" + className + "-" + methodName, driver);
            } 
            catch (Exception e2) {
                System.out.println("Browser closed - cannot get URL, session data or screenshot.");
            }
        }

        private void printIgnoreInfo(Description method) {
            System.out.println("SKIPPING TEST!!! - No data found in Test Case XML for: " 
            		+ className + "." + method.getMethodName() 
            		+ "    Time:  " + getTimestamp());
            printTestCaseInfo();
        }

        private void printTestCaseInfo() {
            System.out.println("XML File Path: " + getXMLFilePath());
            System.out.println("TestCase Description Attribute: " + getTestCaseDescription());
            System.out.println("Region Attribute: " + getTestCaseRegion());
        }

        private String getTestCaseDescription() {
            String testCaseDescription = "None";
            
            if(testCase != null) {
                testCaseDescription = StringUtils.isNotEmpty(testCase.getDescription()) ? " [" + testCase.getDescription() + "] " : "None";
            }
            
            return testCaseDescription;
        }

        private String getXMLFilePath() {
            String xmlDataFilePath = "None";
            
            if(testCase != null && testCase instanceof TestCaseExt) {
                xmlDataFilePath = ((TestCaseExt) testCase).getXmlFilePath();
            }
            
            return xmlDataFilePath;
        }

        private String getTestCaseRegion() {
            String testCaseRegion = "None";
            
            if(testCase != null) {
                testCaseRegion = StringUtils.isNotEmpty(testCase.getRegion()) ? " [" + testCase.getRegion().toUpperCase() + "] " : "None";
            }
            
            return testCaseRegion;
        }

        private void printHeader() {
            System.out.println("**********************************************************************************************************");
        }
    };

    /**
     * The object containing the data used by the test cases.
     * @param testCase
     */
    public ParameterizedBaseTest(TestCase testCase) {
        if(testCase != null) {
            this.testCase = testCase;
        }
    }

    private static List<TestCase[]> getTestData(TestDataRequest testDataRequest) throws Exception {

        String xmlFilePath = testDataRequest.getXmlDataFilepath();
        TestCases testCases = XmlReader.getTestData(xmlFilePath);
        Collection<TestCase> testCaseList = testCases.getTestCases();
        List<TestCase[]> returnList = new ArrayList<TestCase[]>();
        String region = PropertiesManager.getProperty(REGION);

        for(TestCase testCase : testCaseList) {
            if(testCase.getRegion().equals(region)
                    && ((testCase.getName() == null) || (testDataRequest.getTestCaseName() == null) || testCase.getName().equals(
                            testDataRequest.getTestCaseName()))) {
                returnList.add(new TestCase[] { testCase });
            }
        }

        return returnList;
    }

    /**
     * @return the testCase
     */
    protected TestCase getTestCase() {
        return testCase;
    }

    protected static Collection<TestCase[]> getTestDataCollection(TestDataRequest testDataRequest) {
        Collection<TestCase[]> testCaseData = new ArrayList<TestCase[]>();

        try {
            testCaseData = getTestData(testDataRequest);
        } 
        catch (Exception e) {
            LoggingUtility.logError("Error generating test case data", e);
        }

        return testCaseData;
    }

    @Before
    public void loadTestData() {
        // System.out.print("Loading test data for the following method:  " + name.getMethodName());

        StringBuffer allTestDataValues = new StringBuffer();
        TestData testData = getTestData(getMethodName());

        // Ignore test if no data
        assumeTrue(testData != null || testCase.getTestData().isEmpty());
        isdataLoaded = true;

        List<Field> fields = getAllDeclaredFields(new ArrayList<Field>(), getClass());
        parseTestDataValuesFromFields(fields, allTestDataValues);
    }

    /**
     * @param fields
     * @param allTestDataValues
     */
    void parseTestDataValuesFromFields(List<Field> fields, StringBuffer allTestDataValues) {
        for(Field field : fields) {
            String fieldName = field.getName();
            String testDataValue = null;
            TestDataAttribute annotation = field.getAnnotation(TestDataAttribute.class);
            
            if(annotation != null) {
                String testDataValueName = StringUtils.isNotEmpty(annotation.name()) ? annotation.name() : fieldName;
                testDataValue = TestDataUtil.getTestDataValue(testCase, getMethodName(), testDataValueName);

                try {
                    field.setAccessible(true);
                    field.set(this, testDataValue == null ? annotation.defaultValue() : testDataValue);
                    String defaultValueAsString = StringUtils.isNotEmpty(annotation.defaultValue()) ? annotation.defaultValue() + " (default value)" : "null";
                    allTestDataValues.append(testDataValueName + '=' + (testDataValue == null ? defaultValueAsString : testDataValue) + '|');
                    testValues.put(testDataValueName, testDataValue == null ? defaultValueAsString : testDataValue);
                } 
                catch(IllegalArgumentException e) {
                    LoggingUtility.logError(GENERIC_ERROR_LOG, e);
                } 
                catch(IllegalAccessException e) {
                    LoggingUtility.logError(GENERIC_ERROR_LOG, e);
                }

                allTestValuesAsString = allTestDataValues.toString();
            }
        }
    }

    private List<Field> getAllDeclaredFields(List<Field> fields, Class<?> clazz) {
        for(Field field : clazz.getDeclaredFields()) {
            fields.add(field);
        }

        if(clazz.getSuperclass() != null) {
            fields = getAllDeclaredFields(fields, clazz.getSuperclass());
        }
        
        return fields;
    }

    private Field getDeclaredField(String fieldName, Class<?> clazz) throws SecurityException, NoSuchFieldException {
        try {
            return clazz.getDeclaredField(fieldName);
        } 
        catch(NoSuchFieldException e) {
            Class<?> superclazz = clazz.getSuperclass();
            
            if(superclazz != null) {
                return getDeclaredField(fieldName, superclazz);
            } 
            else {
                throw e;
            }
        }
    }

    /**
     * @return the allTestValuesAsString
     */
    protected String getAllTestValuesAsString() {
        return allTestValuesAsString;
    }

    protected String getTestValue(String testDataName) {
        return testValues.get(testDataName);
    }

    protected void setTestValue(String testDataName, String value) {
        String errorPopulating = "Error populating test data field";
        
        try {
            Field field = getDeclaredField(testDataName, getClass());
            field.setAccessible(true);
            field.set(this, value);
            testValues.put(testDataName, value);
        } 
        catch(IllegalArgumentException e) {
            LoggingUtility.logError(errorPopulating + testDataName, e);
        } 
        catch(IllegalAccessException e) {
            LoggingUtility.logError(errorPopulating + testDataName, e);
        } 
        catch(SecurityException e) {
            LoggingUtility.logError(errorPopulating + testDataName, e);
        } 
        catch(NoSuchFieldException e) {
            LoggingUtility.logError(errorPopulating + testDataName, e);
        }

        updateTestValuesAsString();
    }

    private void updateTestValuesAsString() {
        StringBuffer allTestDataValues = new StringBuffer();
        List<Field> fields = getAllDeclaredFields(new ArrayList<Field>(), getClass());

        for(Field field : fields) {
            String fieldName = field.getName();
            String testDataValue = null;
            TestDataAttribute annotation = field.getAnnotation(TestDataAttribute.class);
            
            if(annotation != null) {
                String testDataValueName = StringUtils.isNotEmpty(annotation.name()) ? annotation.name() : fieldName;
                testDataValue = testValues.get(testDataValueName);

                String defaultValueAsString = StringUtils.isNotEmpty(annotation.defaultValue()) ? annotation.defaultValue() + " (default value)" : "null";
                allTestDataValues.append(testDataValueName + '=' + (testDataValue == null ? defaultValueAsString : testDataValue) + '|');

                allTestValuesAsString = allTestDataValues.toString();
            }
        }
    }

    private TestData getTestData(String testName) {
        return TestDataUtil.getTestData(testCase, testName);
    }

    private String getTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy HH:mm:ss");
        String string = formatter.format(new Date());
        return string;
    }

    public String getMethodName() {
        return StringUtils.substringBefore(this.name.getMethodName(), "[");
    }

    void setDriver(WebDriver driver) {
        this.driver = driver;
    }
}