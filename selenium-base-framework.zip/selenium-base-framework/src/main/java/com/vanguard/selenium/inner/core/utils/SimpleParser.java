/* ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/SimpleParser.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Simple string parser that will parse on a given delimiter or the default one - ","
 * Allows for the delimiter to be enclosed in quotes and not parsed.
 */
public class SimpleParser {
	
   
    
    private static final String PATTERN_REGEX_BEGINNING = "\\s*(\"[^\"]*\"|[^";
    private static final String PATTERN_REGEX_ENDING = "]*)\\s*";
    private static final String PATTERN_DEFAULT_DELIMITER = ",";
    private static final int MATCHER_GROUP_ONE = 1; 
    private static final String DOUBLE_QUOTES = "\"";
    

    /**
	 * Parses a delimited separated string (uses commas by default).  
     * If a value is enclosed in quotes, the parser will ignore delimiters contained 
     * in the quotes and strips the quotes off of the value
     * i.e.   a,b,"c,d" e  ==
     * a
     * b
     * c,d
     * e
	 * @param string
	 * @return
	 */
	public static List<String> parseString(String string) {
		Pattern pattern = Pattern.compile(PATTERN_REGEX_BEGINNING + PATTERN_DEFAULT_DELIMITER + PATTERN_REGEX_ENDING);
		return genericParser(string, pattern);
	}

	protected static List<String> parseString(String string, String delimiter) {
		Pattern pattern = Pattern.compile(PATTERN_REGEX_BEGINNING + delimiter + PATTERN_REGEX_ENDING);
		return genericParser(string, pattern);
	}
	
	protected static List<String> genericParser(String string, Pattern pattern){
		List<String> list = new ArrayList<String>();
		Matcher matcher = pattern.matcher(string);
		while (matcher.find()) {
			if(!matcher.group(MATCHER_GROUP_ONE).equals("")){
				if (matcher.group(MATCHER_GROUP_ONE).startsWith(DOUBLE_QUOTES) && matcher.group(MATCHER_GROUP_ONE).endsWith(DOUBLE_QUOTES)){
					list.add(matcher.group(MATCHER_GROUP_ONE).substring(1, matcher.group(MATCHER_GROUP_ONE).length()-1));
				}
				else {
					list.add(matcher.group(1));
				}
				
			}
		}
		return list;
	}
	
}