package com.vanguard.selenium.inner.environments;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import com.vanguard.selenium.inner.base.DriverFactory;
import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.StringUtils;

public class EnvironmentConfigHandlerForSauceLabsCapabilities extends EnvironmentConfigHandler
{
	private static final String JENKINS_PROPERTIES_FILE_NAME = "project.properties";
	public static final String LATEST_ANDROID_APPIUM_VERSION = "1.5.3";
	public static final String LATEST_IOS_APPIUM_VERSION = "1.6.3";
	public static final String APPIUM_VERSION = "appiumVersion";
	protected String testName;
	
	
    public EnvironmentConfigHandlerForSauceLabsCapabilities(String testName) {
        super();
        this.testName = testName;
    }

    public EnvironmentConfiguration handleRequest(EnvironmentConfiguration environmentConfig)
	{
        if(DriverFactory.isRunningOnSauceLabs()){
            setParentTunnelIfNeeded(environmentConfig);
            setSeleniumVersionIfNeeded(environmentConfig);
            setSauceLabsSpecicDesiredCapabilities(environmentConfig);
            environmentConfig.addCapability(EnvironmentConfiguration.NAME_OF_TEST, testName);
        }
		return environmentConfig;
	}


    protected static void setSeleniumVersionIfNeeded(EnvironmentConfiguration environmentConfig) {
        //TODO: Find a better way of determining when we want to set the selenium-java version.  
        //TODO: For now whenever we're using a Windows environment, otherwise use whatever default SauceLabs decides.
    	//NOTE: The below code was a good idea to make sure we only run on the version of selenium we compile against,
    	//however, in reality, since we could be running on much later browser versions, letting SauceLabs decide which version of selenium-java to use
    	//is almost certainly the better practical thing to do.
//        if(environmentConfig.getDesiredCapabilities().getPlatform() == null || environmentConfig.getDesiredCapabilities().getPlatform().toString().toUpperCase().contains("WIN")){
//            environmentConfig.addCapability(EnvironmentConfiguration.SELENIUM_VERSION, EnvironmentConfiguration.SELENIUM_VERSION_VALUE);
//        } 
    }
    protected static void setParentTunnelIfNeeded(EnvironmentConfiguration environmentConfig) {
        if(!DriverFactory.getGridServerUrl().contains(EnvironmentConfiguration.SAUCE_ROOT_ACCT_NAME)){
            //When running as a sub-user under VanguardRoot, we need to specify a parent-tunnel.
            //NOTE: Do not include parent tunnel if running as the Root User
            environmentConfig.addCapability(EnvironmentConfiguration.PARENT_TUNNEL, EnvironmentConfiguration.SAUCE_ROOT_ACCT_NAME);
        }
    }
    protected static void setSauceLabsSpecicDesiredCapabilities(EnvironmentConfiguration environmentConfig) {
    	String idleTimeout = PropertiesManager.getProperty(EnvironmentConfiguration.IDLE_TIMEOUT);
        addIdleTimeoutIfValid(environmentConfig, idleTimeout);
    	String screenResolution = PropertiesManager.getProperty(EnvironmentConfiguration.SCREEN_RESOLUTION);
        addScreenResolutionIfValid(environmentConfig, screenResolution);
        addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.SHOULD_RECORD_VIDEO);
        addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.SHOULD_RECORD_SNAPSHOTS);
        addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.SELENIUM_VERSION);
        addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.TIME_ZONE);
        if(environmentConfig instanceof ChromeConfiguration){
        	addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.CHROME_DRIVER_VERSION);
        }
        if(environmentConfig instanceof InternetExplorerConfiguration){
        	addCapabilityToEnvironmentConfigIfPropertyIsSet(environmentConfig, EnvironmentConfiguration.IE_DRIVER_VERSION);
        }
        
        JenkinsBuildPropertiesService.addJenkinsInfoToEnvironmentConfig(environmentConfig);
    }
    
	/**
     * Note: For anyone using this method, the name of the property in the defaults(or other).properties file must be
     * an exact match to the name of the property SauceLabs wants you to specify in the desiredCapabilities
     * @param environmentConfig
     * @param propertyName
     */
	private static void addCapabilityToEnvironmentConfigIfPropertyIsSet(EnvironmentConfiguration environmentConfig, String propertyName) {
		String propertyValue = PropertiesManager.getProperty(propertyName);
        if(propertyValue != null) {
        	environmentConfig.addCapability(propertyName, propertyValue);
        }
	}
	
    protected static void addScreenResolutionIfValid(EnvironmentConfiguration environmentConfig, String screenResolution) {
		if(!StringUtils.isNullOrEmpty(screenResolution)) {
        	if (isValidScreenResolution(screenResolution)) {
        		environmentConfig.addCapability(EnvironmentConfiguration.SCREEN_RESOLUTION, screenResolution);
        	} else {
        		throw new RuntimeException("Invalid screenResolution value of: " + screenResolution + ".  Value must be of the form: 1920x1080");
        	}
        }
	}

	protected static void addIdleTimeoutIfValid(EnvironmentConfiguration environmentConfig, String idleTimeout) {
		if(!StringUtils.isNullOrEmpty(idleTimeout)) {
        	if (isValidIdleTimeoutValue(idleTimeout)) {
        		environmentConfig.addCapability(EnvironmentConfiguration.IDLE_TIMEOUT, idleTimeout);
        	} else {
        		throw new RuntimeException("Invalid idleTimeout value of: " + idleTimeout + ".  Value must be numeric between 0-1000");
        	}
        }
	}

	static boolean isValidIdleTimeoutValue(String idleTimeout) {
		try{
			Integer.valueOf(idleTimeout);
		} catch(NumberFormatException e) {
			return false;
		}
		if((Integer.valueOf(idleTimeout) >= 0) && (Integer.valueOf(idleTimeout) <= 1000)) {
			return true;
		}
		return false;
	}
	
	static boolean isValidScreenResolution(String screenResolution) {
		List<String> resolutions = Arrays.asList(screenResolution.split("x"));
		if(resolutions.size() != 2) {
			return false;
		}
		try{
			Integer.valueOf(resolutions.get(0));
		} catch(NumberFormatException e) {
			return false;
		}
		try{
			Integer.valueOf(resolutions.get(1));
		} catch(NumberFormatException e) {
			return false;
		}
		return true;
	}
	
 }