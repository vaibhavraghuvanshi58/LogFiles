package com.vanguard.selenium.inner.base;

import static com.vanguard.selenium.inner.base.PropertiesManager.BASE_UNIX_RETAIL_INTERNAL_URL;

import java.io.File;
import java.lang.reflect.Method;

import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ExternalResource;
import org.junit.rules.TestName;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.coverity.testadvisor.client.selenium.SeleniumRecorderClient;
import com.vanguard.selenium.inner.core.pages.VanguardBasePageImpl;
import com.vanguard.selenium.inner.core.rule.SeleniumDebugLogRule;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;
import com.vanguard.selenium.inner.environments.BrowserType;
import com.vanguard.selenium.inner.environments.EnvironmentConfigHandler;
import com.vanguard.selenium.inner.environments.EnvironmentConfigHandlerForAnnotation;
import com.vanguard.selenium.inner.environments.EnvironmentConfigHandlerForProperties;
import com.vanguard.selenium.inner.environments.EnvironmentConfigHandlerForSauceLabsCapabilities;
import com.vanguard.selenium.inner.environments.EnvironmentConfiguration;
import com.vanguard.selenium.inner.environments.FirefoxConfiguration;
import com.vanguard.selenium.inner.logon.user.TestCrewMemberInformation;


public class VanguardBaseTest {
	
	public static final String STATUS_SUCCESS = "Success";
	public static final String STATUS_FAILED = "Failed";

	private String status = "IN_PROGRESS";
	
	protected WebDriver driver;
	protected EnvironmentConfiguration environmentConfig;
	
	@Rule 
	public TestName name = new TestName();

    @Rule
    public SeleniumDebugLogRule seleniumDebugRule = new SeleniumDebugLogRule();

    protected SeleniumRecorderClient testadvisorClient = null;
    
    @Rule
    public TestWatcher watchman = new TestWatcher() {
        @Override
        protected void failed(Throwable e, Description description) {
        	status = STATUS_FAILED;
        }
        @Override
        protected void succeeded(Description description) {
        	status = STATUS_SUCCESS;
       }
    };
    
    @Rule
    public ExternalResource resource = new ExternalResource() {
        @Override
        protected void after() {
            quitDriver();
        }
    };
    
    @Before
    public void before(){
        Method method = null;
        try {
            method = this.getClass().getMethod(removeParameterizedValuesFromMethodName(name.getMethodName()));
        } catch (NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        }
        environmentConfig = getEnvironmentConfig(method, name.getMethodName());
        launchTheBrowser();
    }



    protected EnvironmentConfiguration getEnvironmentConfig(Method method, String testName) {
        EnvironmentConfiguration environmentConfig = null;
        // Setup Chain of Responsibility
        EnvironmentConfigHandler propertiesHandler = new EnvironmentConfigHandlerForProperties();
        EnvironmentConfigHandler annotationHandler = new EnvironmentConfigHandlerForAnnotation(EnvironmentConfigHandler.getEnvironmentConfigAnnotationFromMethod(method));
        EnvironmentConfigHandler sauceLabsCapabilitiesHandler = new EnvironmentConfigHandlerForSauceLabsCapabilities(testName);
        propertiesHandler.setSuccessor(annotationHandler);
        annotationHandler.setSuccessor(sauceLabsCapabilitiesHandler);
        // Send request to the chain
        environmentConfig = propertiesHandler.handleRequest(EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile()));
        return environmentConfig;
    }
    
    

    private String removeParameterizedValuesFromMethodName(String methodName) {
        int endIndex = methodName.indexOf("[");
        if(endIndex == -1){
            endIndex = methodName.indexOf("{");
        }
        if(endIndex == -1){
            endIndex = methodName.indexOf("(");
        }
        if(endIndex == -1){
            endIndex = methodName.length();
        }
        String nameWithoutValues = methodName.substring(0, endIndex);
        return nameWithoutValues;
    }

    public void launchTheBrowser() {
        driver = DriverFactory.getDriver(environmentConfig);
    }

    protected void quitDriver(){
        clearAnySauceLabsPropertiesThatWereAddedForTheTest();
        boolean successfulStatus = status.equals(STATUS_SUCCESS);
        if(testadvisorClient != null){
        	LoggingUtility.logInfo("******** STOPPING Coverity Recorder ***********");
            testadvisorClient.stopTest(successfulStatus);
        }
        if(driver != null){
        	if(DriverFactory.isRunningOnSauceLabs()) {
        		((JavascriptExecutor)driver).executeScript("sauce:job-result=" + successfulStatus);
        	}        
            driver.quit();
            if(!DriverFactory.isRunningOnAGrid() && (environmentConfig instanceof FirefoxConfiguration)) {
            	//TODO: FF52 with GeckoDriver currently doesn't work 100%.  We currently get a "Firefox has stopped working"
            	//popup that needs to be closed.  Hopefully with later versions of FF and GeckoDriver, this method
            	//won't be needed in the future anymore.
            	killPopupForLocalFireFox52StoppedWorkingIssue();
            }
        }
    }

	private void killPopupForLocalFireFox52StoppedWorkingIssue() {
		SeleniumWaitHelper.pause(1);
		String killPopupBatPath = DriverFactory.GECKO_DRIVER_FOLDER_PATH + "Kill-FirefoxPopups.bat";
		try {
		    File killPopupFile = (new File(killPopupBatPath));
		    if(killPopupFile.exists()){
		    	Runtime.getRuntime().exec("cmd /c \"" + killPopupFile.getAbsolutePath() + "\"");
		    }
		} catch (Exception e) {
			LoggingUtility.logError("In trying to kill the potential Firefox Popup via .bat script:\n" + e.getMessage());
		}
	}
	
    private void clearAnySauceLabsPropertiesThatWereAddedForTheTest() {
        PropertiesManager propManager = new PropertiesManager();
        try {
            propManager.reInitializeProperties();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /** This method will authenticate against some RETAIL specific URLs **/
    public void authenticateForInternal(TestCrewMemberInformation testCrewMemberInfo){
        driver = new VgiAuthenticatedWebDriver(driver, testCrewMemberInfo.getUserId(), testCrewMemberInfo.getPassword(), PropertiesManager.getProperty(BASE_UNIX_RETAIL_INTERNAL_URL));
    }
    
    public void authenticateForInternal(TestCrewMemberInformation testCrewMemberInfo, String internalServerUri, String protectedResourceUri){
        driver = new VgiAuthenticatedWebDriver(driver, testCrewMemberInfo.getUserId(), testCrewMemberInfo.getPassword(), internalServerUri, protectedResourceUri);
    }
    
    /** This method will authenticate against some RETAIL specific URLs using the Legacy method.  NOTE: THIS IS KNOWN *NOT* TO WORK FOR CONTRACTORS!**/
    public void authenticateForInternalLegacy(TestCrewMemberInformation testCrewMemberInfo){
    	AuthenticationServiceLegacy legacyAuthService = new AuthenticationServiceLegacy();
    	legacyAuthService.authenticateLegacyMethod(driver, testCrewMemberInfo.getUserId(), testCrewMemberInfo.getPassword());
    }
    /** NOTE: THIS IS KNOWN *NOT* TO WORK FOR CONTRACTORS!**/
    public void authenticateForInternalLegacy(TestCrewMemberInformation testCrewMemberInfo, String internalServerUri, String protectedResourceUri){
    	AuthenticationServiceLegacy legacyAuthService = new AuthenticationServiceLegacy();
    	legacyAuthService.authenticateLegacyMethod(driver, testCrewMemberInfo.getUserId(), testCrewMemberInfo.getPassword(), internalServerUri, protectedResourceUri);
    }
    
    /** Switches focus to the THE other window.  THIS METHOD REQUIRES 
     * EXACTLY 2 WINDOWS TO BE OPEN!
     * 
     * Note: If only 1 window is open, you will be switched to it.  If more 
     * than 2 windows are open, it will remain focus on the original window. 
     * Also Note: This method only works on new windows, NOT tabs.
     */
    public void switchFocusToTheOtherWindow() {
        VanguardBasePageImpl page = new VanguardBasePageImpl(driver) {
            @Override
            public boolean isCurrentlyLoaded() {
                return false;
            }
        };
        page.switchFocusToTheOtherWindow();
    }
	/**
	 * Resizes the Browser to the width and height specified.
	 */
    public void resizeBrowser(int width, int height){
		if(driver==null){
			throw new NullPointerException("The Driver object you are using is null.  Please make sure you are passing the correct driver instance into the PageObject.");
		}    	
		Dimension dim = new Dimension(width, height);
		driver.manage().window().setSize(dim);
    }
    
    //COVERITY REPORTING SPECIFIC METHODS:
    public void startCoverityOED(){
        driver.get(PropertiesManager.getProperty("baseUnixInternalUrl"));
        startCoverity(PropertiesManager.getProperty("CoverityOED"));
    }

    public void startCoverityHNW(){
        driver.get(PropertiesManager.getProperty("baseUnixExternalUrl"));
        startCoverity(PropertiesManager.getProperty("CoverityHNW"));
    }
    
    public void startCoverityPEExternal(){
        driver.get(PropertiesManager.getProperty("baseUnixPEExternal"));
        startCoverity(PropertiesManager.getProperty("CoverityPEExternal"));
    }

    public void startCoverityPEInternal(){
        driver.get(PropertiesManager.getProperty("baseUnixPEInternalUrl"));
        startCoverity(PropertiesManager.getProperty("CoverityPEInternal"));
    }

    public void startCoverityMPM(){
        driver.get(PropertiesManager.getProperty("baseUnixMPMInternalUrl"));
        startCoverity(PropertiesManager.getProperty("CoverityMPM"));
    }
    
    private void startCoverity(String url) {
        if("false".equalsIgnoreCase(PropertiesManager.getProperty("regressionRun"))){
            //Don't start coverity for debug mode
        } else {
            LoggingUtility.logInfo("******** STARTING Coverity Recorder on url: " + driver.getCurrentUrl());
            testadvisorClient = new SeleniumRecorderClient(driver, url);
            testadvisorClient.startTest(getTestName(name.getMethodName()), "Automated Selenium Test");
        }
    }
    
    protected String getTestName(String fullName){
        String returnVal = fullName;
        if(fullName.contains("[")){
            returnVal = fullName.substring(0, fullName.indexOf("["));
            String id = getTestIDIfExists(fullName);
            if(!"".equals(id)){
                returnVal += "_" + id;
            }
        }
        return returnVal;
    }
    
    protected String getTestIDIfExists(String fullName){
        String lookfor = "|testid=";
        String id = "";
        id = getTestParamValue(fullName, lookfor);
        if(!"".equals(id)){
            return id;
        }
        lookfor = "| testid=";
        return getTestParamValue(fullName, lookfor);
    }

    protected String getTestParamValue(String fullName, String lookfor) {
        String value = "";
        if(fullName.toLowerCase().contains(lookfor)){
            int startPos = fullName.toLowerCase().indexOf(lookfor) + lookfor.length();
            int endPos = fullName.indexOf("|", startPos + 1);
            value = fullName.substring(startPos, endPos); 
        }
        return value;
    }

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public EnvironmentConfiguration getEnvironmentConfig() {
		return environmentConfig;
	}
	public void setEnvironmentConfig(EnvironmentConfiguration environmentConfig) {
		this.environmentConfig = environmentConfig;
	}
    
    
}