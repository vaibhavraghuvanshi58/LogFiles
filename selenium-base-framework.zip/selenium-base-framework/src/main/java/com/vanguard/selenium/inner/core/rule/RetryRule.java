/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/rule/RetryRule.java $
 $LastChangedRevision: 325 $
 $Author: unyt $
 $LastChangedDate: 2013-12-02 14:51:09 -0500 (Mon, 02 Dec 2013) $
 */
package com.vanguard.selenium.inner.core.rule;

import org.junit.rules.TestRule;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.utils.ScreenshotUtils;

/**
 * The RetryRule will attempt to rerun tests X number of times.  Tests will pass if within the retry threshhold.  The RetryRule can be configured to optionally take a screen shot for each failure.  The RetryRule will handle the closing of the browser by calling driver.quit().  These references should be removed from your tests.  The RetryRule should not be used with tests that extend BaseTest.
 */
public class RetryRule implements TestRule {
    protected Integer retryCount = 1;
    protected Integer maxRetries;
    protected Throwable caughtThrowable = null;
    protected WebDriver driver;
    protected Boolean takeScreenshot = false;

    public RetryRule(Integer maxRetries) {
        this.maxRetries = maxRetries;
    }

    public RetryRule(Integer maxRetries, Boolean takeScreenshot) {
        this.maxRetries = maxRetries;
        this.takeScreenshot = takeScreenshot;
    }

    public Statement apply(final Statement statement, final Description description) {
        return new Statement(){
            @Override
            public void evaluate() throws Throwable {
                for (int i = 0; i < maxRetries; i++) {
                    try {
                        retryCount = retryCount + 1;
                        statement.evaluate();
                        driver.quit();
                        return;
                    } catch (Throwable t) {
                        if (takeScreenshot){
                            ScreenshotUtils.takeScreenShot(description.getMethodName(), driver);
                        }
                        driver.quit();
                        caughtThrowable = t;
                    }
                }
                // giving up
                if (caughtThrowable != null){
                    driver.quit();
                    throw caughtThrowable;
                }
            }
        };
    }

    public Integer getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }

    public Integer getMaxRetries() {
        return maxRetries;
    }

    public void setMaxRetries(Integer maxRetries) {
        this.maxRetries = maxRetries;
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void setDriver(WebDriver driver) {
        this.driver = driver;
    }

    public Boolean getTakeScreenshot() {
        return takeScreenshot;
    }

    public void setTakeScreenshot(Boolean takeScreenshot) {
        this.takeScreenshot = takeScreenshot;
    }


}