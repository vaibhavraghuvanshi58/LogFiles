/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/AuthenticationUrl.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

/**
 * @author uc4b
 *
 */
public enum AuthenticationUrl {
    INT("https://intspx.vanguard.com:1443/ssgtokenprovider/CreateToken")
    ,SAT("https://satspx.vanguard.com:1443/ssgtokenprovider/CreateToken")
    ,DEV("https://devspx.vanguard.com:1443/ssgtokenprovider/CreateToken")
    ,CAT("https://catspx.vanguard.com:1443/ssgtokenprovider/CreateToken")
    ;

    private final String url;
    private AuthenticationUrl(String url) {
        this.url = url;
    }
    
    public String getUrl() {
        return url;
    }
}
