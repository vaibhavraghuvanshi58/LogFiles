/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/BrowserType.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.StringUtils;


public enum BrowserType {

	FIREFOX,
	CHROME,
	INTERNET_EXPLORER,
	EDGE,
	SAFARI,
	OPERA,
	IPHONE,
	IPAD,
	ANDROID;
	
	public static final BrowserType DEFAULT_VALUE = FIREFOX;
	
	public static BrowserType getBrowserTypeFromPropertiesFile() {
	    String browserName = PropertiesManager.getProperty(EnvironmentConfiguration.BROWSER_TYPE);
	    return getBrowserTypeFromString(browserName);
	}

	public static BrowserType getBrowserTypeFromString(String browserName) {
		BrowserType browserType = null;
	    if(!StringUtils.isNullOrEmpty(browserName)){
    	    switch (browserName.toUpperCase()) {
            case "FIREFOX":
                browserType = BrowserType.FIREFOX;
                break;
            case "CHROME":
            case "GOOGLECHROME":
            case "GOOGLE_CHROME":
                browserType = BrowserType.CHROME;
                break;
            case "IE":
            case "INTERNET_EXPLORER":
            case "INTERNETEXPLORER":
                browserType = BrowserType.INTERNET_EXPLORER;
                break;
            case "EDGE":
            case "MS_EDGE":
            case "MICROSOFT_EDGE":
            case "MICROSOFTEDGE":
                browserType = BrowserType.EDGE;
                break;
            case "SAFARI":
            case "APPLESAFARI":
            case "APPLE_SAFARI":
                browserType = BrowserType.SAFARI;
                break;
            case "OPERA":
                browserType = BrowserType.OPERA;
                break;
            case "IPHONE":
                browserType = BrowserType.IPHONE;
                break;
            case "IPAD":
                browserType = BrowserType.IPAD;
                break;
            case "ANDROID":
                browserType = BrowserType.ANDROID;
                break;
            default:
                LoggingUtility.logError("Invalid value for 'BrowserName'.  Value [" + browserName + "] is not currently supported.  We're going to run the test with " + DEFAULT_VALUE + ".");
                browserType = BrowserType.DEFAULT_VALUE;
            }
	    } else {
	        browserType = DEFAULT_VALUE;
	    }
	    return browserType;
	}

}
