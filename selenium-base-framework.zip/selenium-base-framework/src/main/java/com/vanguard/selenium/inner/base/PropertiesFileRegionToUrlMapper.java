/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/PropertiesFileRegionToUrlMapper.java $
 $LastChangedRevision: 2001 $
 $Author: uoc0 $
 $LastChangedDate: 2015-10-27 15:38:29 -0400 (Tue, 27 Oct 2015) $
 */
package com.vanguard.selenium.inner.base;

import static com.vanguard.selenium.inner.base.PropertiesManager.BASE_WINDOWS_URL;

import org.apache.commons.lang3.StringUtils;

import com.vanguard.selenium.inner.logon.user.ChannelType;

/**
 * @author utcl
 * 
 */
public class PropertiesFileRegionToUrlMapper {

    static final String BASE_UNIX_RETAIL_EXTERNAL_URL = "baseUnixExternalUrl";

    static final String BASE_UNIX_RETAIL_INTERNAL_URL = "baseUnixInternalUrl";

    static final String BASE_UNIX_SBS_EXTERNAL_URL = "baseUnixSbsExternalUrl";

    static final String BASE_UNIX_SBS_INTERNAL_URL = "baseUnixSbsInternalUrl";

    static final String BASE_UNIX_INST_EXTERNAL_URL = "baseUnixInstExternalUrl";

    static final String BASE_UNIX_INST_INTERNAL_URL = "baseUnixInstInternalUrl";
    
    static final String BASE_UNIX_PE_INTERNAL_URL = "baseUnixPEInternalUrl";

    static final String BASE_UNIX_FAS_INTERNAL_URL = "baseUnixFasInternalUrl";
    
    static final String BASE_UNIX_MOBILE_EXTERNAL_URL = "baseUnixMobileExternalUrl";
        
    static final String BASE_UNIX_MPM_INTERNAL_URL = "baseUnixMPMInternalUrl";
    
    static final String BASE_UNIX_IOA_URL = "baseUnixIoaUrl";



    public String getPropertyUrlForChannelBasedOnLocalOrTestRegion(ChannelType channel, boolean isSetToRunInTestRegion) {
        String propertyUrl = StringUtils.EMPTY;
        if (isSetToRunInTestRegion) {
            switch (channel) {
            case RETAIL_WEB:
                propertyUrl = BASE_UNIX_RETAIL_EXTERNAL_URL;
                break;
            case RETAIL_PHONE:
                propertyUrl = BASE_UNIX_RETAIL_INTERNAL_URL;
                break;
            case SBS_INTERNAL:
                propertyUrl = BASE_UNIX_SBS_INTERNAL_URL;
                break;
            case SBS_EXTERNAL:
                propertyUrl = BASE_UNIX_SBS_EXTERNAL_URL;
                break;
            case INST_EXTERNAL:
                propertyUrl = BASE_UNIX_INST_EXTERNAL_URL;
                break;
            case FAS_INTERNAL:
                propertyUrl = BASE_UNIX_FAS_INTERNAL_URL;
                break;
            case DOT_MOBI:
                propertyUrl = BASE_UNIX_MOBILE_EXTERNAL_URL;
                break;
            case IOA:
                propertyUrl = BASE_UNIX_IOA_URL;
                break;
            case PE_INTERNAL:
                propertyUrl = BASE_UNIX_PE_INTERNAL_URL;
                break;
            case MPM_INTERNAL:
                propertyUrl = BASE_UNIX_MPM_INTERNAL_URL;
                break;
            }
        } else {
            propertyUrl = BASE_WINDOWS_URL;
        }
        return propertyUrl;
    }

}
