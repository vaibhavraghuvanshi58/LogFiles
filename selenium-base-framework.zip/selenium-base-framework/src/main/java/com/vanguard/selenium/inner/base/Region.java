/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/Region.java $
 $LastChangedRevision: 1758 $
 $Author: uz0s $
 $LastChangedDate: 2015-09-02 16:30:15 -0400 (Wed, 02 Sep 2015) $
 */
package com.vanguard.selenium.inner.base;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public enum Region {

    E("E", RegionProperties.E), F("F", RegionProperties.F), X("X", RegionProperties.X), M("M", RegionProperties.M), P("P", RegionProperties.P), S("S", RegionProperties.S);

    private String region;

    private RegionProperties propertiesFile;

    private Region(String region, RegionProperties propertiesFile) {
        this.region = region;
        this.propertiesFile = propertiesFile;
    }

    @Override
    public String toString() {
        return region;
    }

    public RegionProperties getRegionProperties() {
        return propertiesFile;
    }

    public String getRegionFileName() {
        return propertiesFile.getRegionFileName();
    }

    private static final Map<String, Region> STRING_TO_ENUM = new HashMap<String, Region>();
    static {
        for (Region curEnum : values()) {
            STRING_TO_ENUM.put(curEnum.toString(), curEnum);
        }
    }

    public static Region fromString(String region) {
        return STRING_TO_ENUM.get(region);
    }

    private static final Map<RegionProperties, Region> PROPERTIES_TO_ENUM = new HashMap<RegionProperties, Region>();
    static {
        for (Region curEnum : values()) {
            PROPERTIES_TO_ENUM.put(curEnum.getRegionProperties(), curEnum);
        }
        final File defaultFile = new File(PropertiesManager.BASE_DIRECTORY + RegionProperties.REGRESSION_MULTIMODULE_DEFAULT);
        if(defaultFile.exists()) {
            PROPERTIES_TO_ENUM.put(RegionProperties.REGRESSION_MULTIMODULE_DEFAULT, PropertiesManager.getDefaultRegion());
        } else {
            PROPERTIES_TO_ENUM.put(RegionProperties.DEFAULT, PropertiesManager.getDefaultRegion());
        }
    }

    public static Region fromRegionProperties(RegionProperties region) {
        return PROPERTIES_TO_ENUM.get(region);
    }

}