/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/EmailUtils.java $
 $LastChangedRevision: 1325 $
 $Author: ubhj $
 $LastChangedDate: 2015-04-01 16:46:28 -0400 (Wed, 01 Apr 2015) $
 */
package com.vanguard.selenium.inner.core.utils;


@Deprecated
public class EmailUtils {

	/**
	 * @deprecated use com.vanguard.utils.email.EmailUtils.sendEmail directly instead
	 */
	@Deprecated
	public static boolean sendEmail(String toEmail, String subject, String body){
		return com.vanguard.utils.email.EmailUtils.sendEmail(toEmail, subject, body);
	}


}
