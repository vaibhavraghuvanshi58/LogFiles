package com.vanguard.selenium.inner.core.utils;


public class StringUtils{
	
	public static boolean isNullOrEmpty(String string){
		return (string == null) || string.equals("");
	}
		
	public static String putSlashesBeforeAnyRegExChars(String regExString){
		String removedRegEx = regExString.replace("\\", "\\\\");//make sure you replace \'s first
		removedRegEx = removedRegEx.replace("*", "\\*");
		removedRegEx = removedRegEx.replace(".", "\\.");
		removedRegEx = removedRegEx.replace("-", "\\-");
		removedRegEx = removedRegEx.replace("(", "\\(");
		removedRegEx = removedRegEx.replace(")", "\\)");
		removedRegEx = removedRegEx.replace("[", "\\[");
		removedRegEx = removedRegEx.replace("]", "\\]");
		removedRegEx = removedRegEx.replace("+", "\\+");
		removedRegEx = removedRegEx.replace("?", "\\?");
		removedRegEx = removedRegEx.replace("|", "\\|");
		removedRegEx = removedRegEx.replace(":", "\\:");
		removedRegEx = removedRegEx.replace("<", "\\<");
		removedRegEx = removedRegEx.replace(">", "\\>");
		removedRegEx = removedRegEx.replace("=", "\\=");
		removedRegEx = removedRegEx.replace("$", "\\$");
		removedRegEx = removedRegEx.replace("^", "\\^");
		removedRegEx = removedRegEx.replace("&", "\\&");
		return removedRegEx;
	}
}