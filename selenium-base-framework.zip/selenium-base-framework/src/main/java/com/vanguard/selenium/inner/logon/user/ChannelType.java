/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/logon/user/ChannelType.java $
 $LastChangedRevision: 2001 $
 $Author: uoc0 $
 $LastChangedDate: 2015-10-27 15:38:29 -0400 (Tue, 27 Oct 2015) $
 */
package com.vanguard.selenium.inner.logon.user;

import java.util.HashMap;
import java.util.Map;

public enum ChannelType {
    RETAIL_WEB("WEB"), RETAIL_PHONE("PHONE"), RETAIL_MAIL("MAIL"), SBS_INTERNAL("SBS_INTERNAL"), SBS_EXTERNAL("SBS EXTERNAL"), INST_EXTERNAL(
            "INST_EXTERNAL"), INST_INTERNAL("INST_INTERNAL"), FAS_INTERNAL("FAS_INTERNAL"), DOT_MOBI("MOBILE"), IOA("IOA"), PE_INTERNAL("PE_INTERNAL"),
            MPM_INTERNAL("MPM_INTERNAL");

    private String channel;

    private ChannelType(String channel) {
        this.channel = channel;
    }

    @Override
    public String toString() {
        return channel;
    }

    private static final Map<String, ChannelType> STRING_TO_ENUM = new HashMap<String, ChannelType>();
    static {
        for (ChannelType curEnum : values()) {
            STRING_TO_ENUM.put(curEnum.toString(), curEnum);
        }
    }

    public static ChannelType fromString(String channel) {
        return STRING_TO_ENUM.get(channel); 
    }

    /**
     * @return
     */
    public boolean isExternalUser() {
        return RETAIL_WEB.equals(this);
    }


}
