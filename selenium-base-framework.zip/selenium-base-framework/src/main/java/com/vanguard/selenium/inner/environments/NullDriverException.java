/*
 ****************************************************************************
 *
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/NullDriverException.java $
 $LastChangedRevision: 5640 $
 $Author: uz0s $
 $LastChangedDate: 2017-06-20 11:49:08 -0400 (Tue, 20 Jun 2017) $
*/
package com.vanguard.selenium.inner.environments;

/**
 * @author uz0s
 *
 */
public class NullDriverException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;


    public NullDriverException(String message)
    {
       super(message);
    }

}
