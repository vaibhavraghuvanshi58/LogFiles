/*
 ****************************************************************************
 *
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/pages/SeleniumFindElementWrapperMethods.java $
 $LastChangedRevision: 5354 $
 $Author: uz0s $
 $LastChangedDate: 2017-03-22 14:53:18 -0400 (Wed, 22 Mar 2017) $
*/
package com.vanguard.selenium.inner.core.pages;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.StringUtils;

public class SeleniumFindElementWrapperMethods {

	protected WebDriver driver;
	
	/**
	 * Returns an element found via the byLocator.  The element must already be present and 
	 * enabled on the page before this method is called.  If you'd like to keep looking for the element 
	 * for a length of time call findElement(byLocator, maxWaitTime); If no element is found, null will 
	 * be returned.
	 * @param byLocator
	 * @return - The WebElement object if found, or null if not found
	 */
	public WebElement findElement(By byLocator) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		WebElement element;
		if(!isElementEnabledWithinWait(byLocator, 0)){
		    return null;
		}
		element = driver.findElement(byLocator);	
		return element;
	}
	
	/**
	 * Looks for an element via the byLocator for up to maxWaitTime.  As soon as an element is present and
	 * enabled matching the byLocator it is returned.  If no match is found within the maxWaitTime, null is returned.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public WebElement findElement(By byLocator, int maxWaitTime) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		WebElement element;
		if(!isElementEnabledWithinWait(byLocator, maxWaitTime)){
		    return null;
		}
		element = driver.findElement(byLocator);
		return element;
	}
	
	private boolean isElementEnabledWithinWait(By byLocator, int maxWaitTime) {
		if(isWaitForSuccessful(ExpectedConditions.elementToBeClickable(byLocator), maxWaitTime)){
			return true;
		}
		return false;
	}
	
	
	/**
	 * Looks for an element via the byLocator for up to maxWaitTime.  As soon as an element is visible 
	 * matching the byLocator it is returned.  If no match is found within the maxWaitTime, null is returned.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public WebElement findElementThatIsVisible(By byLocator, int maxWaitTime) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		WebElement element;
		if(!isElementVisibleWithinWait(byLocator, maxWaitTime)){
		    return null;
		}
		element = driver.findElement(byLocator);
		return element;
	}

	/**
	 * Looks for an element via the byLocator for up to maxWaitTime.  As soon as an element is present within the DOM
	 * matching the byLocator it is returned.  NOTE: The element does NOT have to be visible for this method.  
	 * If no match is found within the maxWaitTime, null is returned.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 * 
	 * Technical Note: This method re-implements the ExpectedConditions.presenceOfElementLocated.
	 * 		Since at present Selenium uses driver.findElement() within that ExpectedCondition, which can potentially
	 * 		freeze the browser if looking for an element that is not present.  We re-implement it here using driver.findElemnts();
	 */
	public WebElement findElementThatIsPresent(final By byLocator, int maxWaitTime) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
	    FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	            .withTimeout(maxWaitTime, TimeUnit.SECONDS)
	            .pollingEvery(200, TimeUnit.MILLISECONDS);

	    try{
	    	return wait.until(new Function<WebDriver, WebElement>() {
	    		public WebElement apply(WebDriver webDriver) {
	    			List<WebElement> elems = driver.findElements(byLocator);
	    			if(elems.size() > 0){
	    				return elems.get(0);
	    			} else {
	    				return null;
	    			}
	    		}
	    	});
	    } catch(Exception e) {
	    	return null;
	    }
	}
	
	/**
	 * Waits for "up to" maxTime for the WebElement to get the neededValue.  
	 * As soon as the WebElement has that text value, we will return true and continue the test
	 * If we wait the entire maxTime and the WebElement still does not have the neededValue at that time
	 * we will return false and continue the test. 
	 */
	public boolean doesElementGetTextValueWithinSpecifiedTime(final By byLocator, int maxTime, final String neededValue){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
	    FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	            .withTimeout(maxTime, TimeUnit.SECONDS)
	            .pollingEvery(200, TimeUnit.MILLISECONDS);

	    try{
	    	return wait.until(new Function<WebDriver, Boolean>() {
	    		public Boolean apply(WebDriver webDriver) {
	    			WebElement element = findElement(byLocator);
	    			if(element == null){
	    				return false;
	    			} else {
	    				return element.getText().equalsIgnoreCase(neededValue);
	    			}
	    		}
	    	});
	    } catch(Exception e) {
	    	return false;
	    }		
	}
	
	/**
	 * Element found via byLocator can be seen on the page.
	 */
	private boolean isElementVisibleWithinWait(By byLocator, int maxWaitTime) {
		if(isWaitForSuccessful(ExpectedConditions.visibilityOfElementLocated(byLocator), maxWaitTime)){
			return true;
		}
		return false;
	}

	/**
	 * byLocator can be found within the DOM.  The element does NOT necessarily need to be visible
	 * 
	 * Deprecated - use findElementThatIsPresent().  There is a bug in Selenium core ExpectedConditions.
	 * 		Selenium's ExpectedConditions use driver.findElement() under the covers which according to Selenium's own documentation:
	 * 		https://seleniumhq.github.io/selenium/docs/api/java/org/openqa/selenium/WebElement.html
	 * 		Should not be used to find non-present elements.
	 * 
	 * 		This method would be much simpler than re-implementing the Expected condition again like
	 * 		findElementThatIsPresent() does.  We can revert back to using this if/when Selenium corrects their ExpectedCondition.
	 */
	@Deprecated
	private boolean isElementPresentWithinWait(By byLocator, int maxWaitTime) {
		if(isWaitForSuccessful(ExpectedConditions.presenceOfElementLocated(byLocator), maxWaitTime)){
			return true;
		}
		return false;
	}
	
	/**
	 * Checks to see that we can find the sub-Element AND that it passes our "is-ready-to-be-used" check
	 */
	private boolean isSubElementEnabledWithinWaitTime(WebElement sourceElement, By subByLocator, int maxWaitTime){
		Date start = new Date();
		if(sourceElement == null){
			return false;
		}
		if(!subElementCanBeFoundBySelenium(sourceElement, subByLocator, maxWaitTime)){
			return false;
		}
		Date middle = new Date();
		int secondsAlreadyWaited = (int) (middle.getTime() - start.getTime()) / 1000;
		int secondsWeCanStillWaitFor = maxWaitTime - secondsAlreadyWaited;
		if(secondsWeCanStillWaitFor < 0) {
			secondsWeCanStillWaitFor = 0;
		}
		if(isWaitForSuccessful(ExpectedConditions.elementToBeClickable(sourceElement.findElement(subByLocator)), secondsWeCanStillWaitFor)){
			return true;
		}
		return false;
	}
	
	/**
	 * Simply checks to see if Selenium can find the sub-Element.  Does NOT check if it passes our "ready-to-be-used" check.
	 */
	private boolean subElementCanBeFoundBySelenium(WebElement sourceElement, By subByLocator, int maxWaitTime) {
		if(isWaitForSuccessful(ExpectedConditions.presenceOfNestedElementLocatedBy(sourceElement, subByLocator), maxWaitTime)){
			return true;
		}
		return false;
	}

	/**
	 * Make sure if trying to grab the subLocation of a parent element by Xpath, 
	 * that the xpath specifies ".//" for a relative path search and not start with 
	 * "//" for global search.
	 * @param subLocation
	 * @return
	 */
	private By updateXPathIfNeededForSubElements(By subLocation) {
		if(subLocation instanceof ByXPath){
			String byXpath = "By.xpath: ";
			String xpathExpr = subLocation.toString().substring(byXpath.length());
			if(xpathExpr.startsWith("//")){
				subLocation = By.xpath("." + xpathExpr);
			}
		}
		return subLocation;
	}

	
	/**
	 * Looks for a subElement within a parent source element. If the parent can not be found, an error is logged and the test continues, 
	 * and null will be returned.  If the parent is present and the subElement can not be found, null will be returned. 
	 * If both the parent and child can be found immediately the subElement of the parent is returned.
	 * @param sourceElementByLocator
	 * @param byLocator
	 * @return
	 */
	public WebElement findElement(By sourceElementByLocator, By byLocator) {
		WebElement parent = findElement(sourceElementByLocator);
		if(parent == null){
			logErrorForNotFindingElement();
			return null;
		}
		byLocator = updateXPathIfNeededForSubElements(byLocator);
		WebElement element;
        if(!isSubElementEnabledWithinWaitTime(parent, byLocator, 0)){
            return null;
        }
		element = parent.findElement(byLocator);
		return element;
	}
	
	/**
	 * Looks for a subElement within a parent source element. If the parent can not be found within the maxWaitTime, 
	 * an error is logged and the test continues, and null will be returned.  If the parent can be found but the 
	 * subElement can not be found within the maxWaitTime, null will be returned. If both the parent and child can be found 
	 * within the maxWaitTime the subElement is returned and the test continues as soon as it's found.
	 * @param sourceElementByLocator
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public WebElement findElement(By sourceElementByLocator, By byLocator, int maxWaitTime) {
		Date start = new Date();
		WebElement parent = findElement(sourceElementByLocator, maxWaitTime);
		if(parent == null){
			logErrorForNotFindingElement();
			return null;
		}
		byLocator = updateXPathIfNeededForSubElements(byLocator);
		Date middle = new Date();
		int secondsAlreadyWaited = (int) (middle.getTime() - start.getTime()) / 1000;
		int secondsWeCanStillWaitFor = maxWaitTime - secondsAlreadyWaited;
		if(secondsWeCanStillWaitFor < 0) {
			secondsWeCanStillWaitFor = 0;
		}
		if(!isSubElementEnabledWithinWaitTime(parent, byLocator, secondsWeCanStillWaitFor)){
		    return null;
		}
		//Find the parent again.  No telling what may have happened in all that wait time we used to get the subElement.
		WebElement element = findElement(sourceElementByLocator).findElement(byLocator);
		return element;
	}
	/**
	 * Looks for a subElement within a parent source element. If the parent is null, 
	 * an error is logged and the test continues, and null will be returned.  If the parent is there but the 
	 * subElement can not be found within the maxWaitTime, null will be returned. If both the parent and child can be found 
	 * within the maxWaitTime the subElement is returned and the test continues as soon as it's found.
	 * @param sourceElement
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public WebElement findElement(WebElement sourceElement, By byLocator, int maxWaitTime) {
		if(sourceElement == null){
			logErrorForNotFindingElement();
			return null;
		}
		byLocator = updateXPathIfNeededForSubElements(byLocator);
		if(!isSubElementEnabledWithinWaitTime(sourceElement, byLocator, maxWaitTime)){
		    return null;
		}
		WebElement element = sourceElement.findElement(byLocator);
		return element;
    }

	/**Attempts to smartly get the best locator of an element that it can find 
	 * We look to find an id, name, or class attribute.  
	 * If none can be found, we return null.
	 * **/
	public By getByLocatorOfElement(WebElement sourceElement) {
        if(sourceElement == null){
            logErrorForNotFindingElement();
            return null;
        }
		if(!StringUtils.isNullOrEmpty(sourceElement.getAttribute("id"))){
			return By.id(sourceElement.getAttribute("id"));
		} else if(!StringUtils.isNullOrEmpty(sourceElement.getAttribute("name"))) {
			return By.name(sourceElement.getAttribute("name"));
		} else if(!StringUtils.isNullOrEmpty(sourceElement.getAttribute("class"))) {
			return By.className(sourceElement.getAttribute("class"));
		}
		LoggingUtility.logError("Could not find a locator of sourceElement [" + sourceElement + "] by id, name, or class.  Returning null.");
		return null;
	}

	/**
	 * Looks for all elements that match the byLocator for up to maxWaitTime.  As soon as the first
	 * element is found, we return the list of all elements that match the byLocator that are present at that time.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public List<WebElement> findElements(By byLocator, int maxWaitTime) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
	    List<WebElement> result;
        findElement(byLocator, maxWaitTime); //Look for the default first one of the collection.
        result = driver.findElements(byLocator);
		return result;
	}

	/**
	 * Looks for all subElements within a parent source element that match the byLocator. If the parent is null, 
	 * an error is logged and the test continues, and an empty list will be returned.  If the parent is there but no 
	 * subElements can not be found within the maxWaitTime, an empty list will be returned. If both the parent and at least one 
	 * child can be found within the maxWaitTime a list of all subElements is returned and the test continues as soon as the first subElement is found.
	 * @param sourceElementByLocator
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public List<WebElement> findElements(By sourceElementByLocator, By byLocator, int maxWaitTime) {
		Date start = new Date();
		WebElement parent = findElement(sourceElementByLocator, maxWaitTime);
		if(parent == null){
			logErrorForNotFindingElement();
			return new ArrayList<WebElement>();
		}
		byLocator = updateXPathIfNeededForSubElements(byLocator);
		Date middle = new Date();
		int secondsAlreadyWaited = (int) (middle.getTime() - start.getTime()) / 1000;
		int secondsWeCanStillWaitFor = maxWaitTime - secondsAlreadyWaited;
		if(secondsWeCanStillWaitFor < 0) {
			secondsWeCanStillWaitFor = 0;
		}
        findElement(sourceElementByLocator, byLocator, secondsWeCanStillWaitFor); //Look for the default first one of the collection.
        List<WebElement> result = findElement(sourceElementByLocator).findElements(byLocator);
		return result;
	}
	/**
	 * Looks for all subElements within a parent source element that match the byLocator. If the parent is null, 
	 * an error is logged and the test continues, and an empty list will be returned.  If the parent is there but no 
	 * subElements can not be found within the maxWaitTime, an empty list will be returned. If both the parent and at least one 
	 * child can be found within the maxWaitTime a list of all subElements is returned and the test continues as soon as the first subElement is found.
	 * @param sourceElement
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
    public List<WebElement> findElements(WebElement sourceElement, By byLocator, int maxWaitTime) {
        if(sourceElement == null){
            LoggingUtility.logWarning("When trying to get list of subElements with locator: " + byLocator + ", the parent element is null.  Returning an empty list.");
            return new ArrayList<WebElement>();
        }
        byLocator = updateXPathIfNeededForSubElements(byLocator);
        findElement(sourceElement, byLocator, maxWaitTime); //Look for the default first one of the collection.
        List<WebElement> result = sourceElement.findElements(byLocator);
        return result;
    }

	private boolean isWaitForSuccessful(ExpectedCondition<WebElement> condition, Integer maxWaitTime){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		if(maxWaitTime==null){
			maxWaitTime = 3;
		}
		WebDriverWait wait = new WebDriverWait(driver, maxWaitTime);
		try{
		    wait.until(condition);
		    return true;
		} catch(TimeoutException e){
		    return false;
		}
	}
	
	
    protected void logErrorForNotFindingElement(By byLocator) {
        LoggingUtility.logError("Could not find element based on locator: " + byLocator.toString());
    }
    protected void logErrorForNotFindingElement() {
        LoggingUtility.logError("Element is null and can not be acted upon");
    }
    protected void throwNullPointerExeptionForNullDriver(){
    	throw new NullPointerException("The Driver object you are using is null.  Please make sure you are passing the correct driver instance into the PageObject.");
    }
}
