package com.vanguard.selenium.inner.environments;

import java.lang.reflect.Method;

import com.vanguard.selenium.inner.base.EnvironmentConfigAnnotation;
import com.vanguard.selenium.inner.core.utils.StringUtils;

public abstract class EnvironmentConfigHandler
{
	protected EnvironmentConfigHandler successorHanddler;
	
	public EnvironmentConfigHandler() {
	}
	
	public void setSuccessor(EnvironmentConfigHandler successorHanddler)
	{
	    this.successorHanddler = successorHanddler;
	}

	public abstract EnvironmentConfiguration handleRequest(EnvironmentConfiguration environmentConfig);
	
    protected static void overrideCapabilityIfValueIsPresent(EnvironmentConfiguration environmentConfig, String capability, String value) {
        if(!StringUtils.isNullOrEmpty(value)){
            environmentConfig.addCapability(capability, value);
        }
    }
    
    protected static void overrideAnyCapabilityValuesPresent(EnvironmentConfiguration environmentConfig, EnvironmentConfigOverrideValues overrideValues) {
    	overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.SAUCELABS_TAG_LABELS, overrideValues.getTags());
    	EnvironmentConfigHandlerForSauceLabsCapabilities.addIdleTimeoutIfValid(environmentConfig, overrideValues.getIdleTimout());
    	EnvironmentConfigHandlerForSauceLabsCapabilities.addScreenResolutionIfValid(environmentConfig, overrideValues.getScreenResolution());
    	if(environmentConfig instanceof BrowserConfiguration){
            overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.VERSION, overrideValues.getBrowserVersion());
            if(!StringUtils.isNullOrEmpty(overrideValues.getOsType()) && !StringUtils.isNullOrEmpty(overrideValues.getOsVersion())){
                overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.PLATFORM, overrideValues.getOsType() + " " + overrideValues.getOsVersion());
            } else if(!StringUtils.isNullOrEmpty(overrideValues.getOsType())) {
                overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.PLATFORM, overrideValues.getOsType());
            }
            if(environmentConfig instanceof ChromeConfiguration){
            	overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.CHROME_DRIVER_VERSION, overrideValues.getChromeDriverVersion());
            }
            if(environmentConfig instanceof InternetExplorerConfiguration){
            	overrideCapabilityIfValueIsPresent(environmentConfig, EnvironmentConfiguration.IE_DRIVER_VERSION, overrideValues.getIEDriverVersion());
            }
        } else if(environmentConfig instanceof MobileConfiguration){
            overrideCapabilityIfValueIsPresent(environmentConfig, MobileConfiguration.DEVICE_NAME, overrideValues.getDeviceName());
            overrideCapabilityIfValueIsPresent(environmentConfig, MobileConfiguration.DEVICE_ORIENTATION, overrideValues.getDeviceOrientation());
            overrideCapabilityIfValueIsPresent(environmentConfig, MobileConfiguration.PLATFORM_VERSION, overrideValues.getDevicePlatformVersion());
        }
    }
    
    public static EnvironmentConfigAnnotation getEnvironmentConfigAnnotationFromMethod(Method method) {
        EnvironmentConfigAnnotation environmentConfigAnnotation = null;
        if (method !=null && method.isAnnotationPresent(EnvironmentConfigAnnotation.class)) {
            environmentConfigAnnotation = method.getAnnotation(EnvironmentConfigAnnotation.class);
        }
        return environmentConfigAnnotation;
    }
}