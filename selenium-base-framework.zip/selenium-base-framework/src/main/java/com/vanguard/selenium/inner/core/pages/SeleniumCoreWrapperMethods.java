/*
 ****************************************************************************
 *
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/pages/SeleniumCoreWrapperMethods.java $
 $LastChangedRevision: 5368 $
 $Author: u1nw $
 $LastChangedDate: 2017-03-29 11:50:28 -0400 (Wed, 29 Mar 2017) $
*/
package com.vanguard.selenium.inner.core.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;

public class SeleniumCoreWrapperMethods extends SeleniumFindElementWrapperMethods{

	/**
	 * Returns the current URL within the driver's window.
	 */
	public String getCurrentUrl(){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
	    return driver.getCurrentUrl();
	}
	/**
	 * Returns the value of the window Title
	 */
	public String getTitle(){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
        return driver.getTitle();
    }
	/**
	 * Navigates to the specified URL
	 */
	public void visit(String url){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		driver.get(url);
	}

	/**
	 * Resizes the Browser to the width and height specified.
	 */
    public void resizeBrowser(int width, int height){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}    	
		Dimension dim = new Dimension(width, height);
		driver.manage().window().setSize(dim);
    }
	
	/** 
	 * Clicks the element found via the byLocator.  If no element is found immediately, an error is logged and the test will continue.
	 * @param byLocator
	 */
	public void click(By byLocator){
	    WebElement element = findElement(byLocator);
	    if(element == null){
	        logErrorForNotFindingElement(byLocator);
	        return;
	    }
	    element.click();
	}

	/** 
	 * Clicks the element passed in.  If the element is null, an error is logged and the test will continue.
	 * @param byLocator
	 */
    public void click(WebElement element){
        if(element==null){
            logErrorForNotFindingElement();
            return;
        }
        element.click();
    }
    
    /**
     * Clicks the element found via the byLocator.  This method will continue looking for the element up to the maxWaitTime.  
     * If no element is found within that time, an error is logged and the test will continue.
     * @param byLocator
     * @param maxWaitTime - In seconds
     */
    public void click(By byLocator, int maxWaitTime){
        WebElement element = findElement(byLocator, maxWaitTime);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return;
        }
        element.click();
    }
	
    /**
     * This will enter the inputText into the element found by the byLocator.  
     * This method will continue looking for the element up to the maxWaitTime.  
     * If no element is found within that time, an error is logged and the test will continue.
     * @param inputText
     * @param byLocator
     * @param maxWaitTime - In seconds
     */
	public void type(String inputText, By byLocator, int maxWaitTime){
	    WebElement element = findElement(byLocator, maxWaitTime);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return;
        }
        element.sendKeys(inputText);
	}
	
    /**
     * This will enter the inputText into the element found by the byLocator.  
     * The element must already be present and enabled on the screen before this method is called.
     * If no element is found immediately, an error is logged and the test will continue.
     * @param inputText
     * @param byLocator
     */
	public void type(String inputText, By byLocator){
	    WebElement element = findElement(byLocator);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return;
        }
        element.sendKeys(inputText);
	}
    /**
     * This will enter the inputText into the element found specified.  
     * The element must already be present and enabled on the screen before this method is called.
     * If the element is null an error is logged and the test will continue.
     * @param inputText
     * @param byLocator
     */
	public void type(String inputText, WebElement element){
        if(element == null){
            logErrorForNotFindingElement();
            return;
        }
        element.sendKeys(inputText);
	}
	
	/**
	 * This will clear the element first and then enter the inputText into the element found by the byLocator.
     * This method will continue looking for the element up to the maxWaitTime.  
     * If no element is found within that time, an error is logged and the test will continue.
	 * @param inputText
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 */
	public void clearAndType(String inputText, By byLocator, int maxWaitTime){
	    clear(byLocator, maxWaitTime);
	    type(inputText, byLocator, maxWaitTime);
	}
	
	/**
	 * This will clear the element first and then enter the inputText into the element found by the byLocator.
	 * The element must already be present and enabled on the screen before this method is called.
     * If no element is found immediately, an error is logged and the test will continue.
	 * @param inputText
	 * @param byLocator
	 */
	public void clearAndType(String inputText, By byLocator){
	    clear(byLocator);
	    type(inputText, byLocator);
	}
	
	/**
	 * This will clear the element first and then enter the inputText into the element.
	 * The element must already be present and enabled on the screen before this method is called.
     * If the element is null, an error is logged and the test will continue.
	 * @param inputText
	 * @param byLocator
	 */
	public void clearAndType(String inputText, WebElement element){
	    clear(element);
	    type(inputText, element);
	}
	
	/**
	 * This will clear the text of an input element found by the byLocator.
     * This method will continue looking for the element up to the maxWaitTime.  
     * If no element is found within that time, an error is logged and the test will continue.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 */
	public void clear(By byLocator, int maxWaitTime){
	    WebElement element = findElement(byLocator, maxWaitTime);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return;
        }
        element.clear();
    }
	
	/**
	 * This will clear the text of an input element found by the byLocator.
	 * The element must already be present and enabled on the screen before this method is called.
     * If no element is found immediately, an error is logged and the test will continue.
	 * @param byLocator
	 */
	public void clear(By byLocator){
	    WebElement element = findElement(byLocator);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return;
        }
        element.clear();
    }
	/**
	 * This will clear the text of the specified element.
	 * The element must already be present and enabled on the screen before this method is called.
     * If the element is null, an error is logged and the test will continue.
	 * @param byLocator
	 */
	public void clear(WebElement element){
        if(element == null){
            logErrorForNotFindingElement();
            return;
        }
        element.clear();
    }
	
	/**
	 * Returns if an element via the byLocator is visibly present on the page at this exact point in time.
	 * @param byLocator
	 * @return
	 */
	public boolean isDisplayed(By byLocator){
		return isElementCurrentlyDisplayed(byLocator);
	}

	//TODO: Refacotr isDisplayed(By byLocator, int maxWaitTime) and isEnabled(By byLocator, int maxWaitTime).
	//TODO: Should use a pattern to have a single method contain the for loop and call which check to use (isElementCurrentlyDisplayed or isElementCurrentlyEnabled).
	
	/**
	 * Returns if an element via the byLocator is visibly present on the page at any point from when this is called to 
	 * up to the maxWaitTime in seconds later.  If the element is visible within that time, as soon as it is, this will return true and continue the test.
	 * If we wait for the entire time and the element has never been visible, this will return false.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public boolean isDisplayed(By byLocator, int maxWaitTime){
		for(int waitSoFar=1; waitSoFar < maxWaitTime; waitSoFar++){
			if(isElementCurrentlyDisplayed(byLocator)){
				return true;
			}
			SeleniumWaitHelper.pause(1);//Wait 1 second and try again.
		}
		if(isElementCurrentlyDisplayed(byLocator)){
			return true;
		}
		return false;
	}

	private boolean isElementCurrentlyDisplayed(By byLocator){
		WebElement element = findElementThatIsPresent(byLocator, 0);
		if((element!=null) && element.isDisplayed()){
			return true;
		}
		return false;
	}
	

	/**
	 * Returns if an element via the byLocator is enabled on the page at this exact point in time.
	 * @param byLocator
	 * @return
	 */
	public boolean isEnabled(By byLocator){
		return isElementCurrentlyEnabled(byLocator);
    }

	/**
	 * Returns if an element via the byLocator is enabled on the page at any point from when this is called to 
	 * up to the maxWaitTime in seconds later.  If the element is enabled within that time, as soon as it is, this will return true and continue the test.
	 * If we wait for the entire time and the element has never been visible, this will return false.
	 * @param byLocator
	 * @param maxWaitTime - In seconds
	 * @return
	 */
	public boolean isEnabled(By byLocator, int maxWaitTime){
		for(int waitSoFar=1; waitSoFar < maxWaitTime; waitSoFar++){
			if(isElementCurrentlyEnabled(byLocator)){
				return true;
			}
			SeleniumWaitHelper.pause(1);//Wait 1 second and try again.
		}
		if(isElementCurrentlyEnabled(byLocator)){
			return true;
		}
		return false;
    }
	
	private boolean isElementCurrentlyEnabled(By byLocator){
		WebElement element = findElementThatIsPresent(byLocator, 0);
		if((element!=null) && element.isEnabled()){
			return true;
		}
		return false;
	}
	
	
	/**
	 * Returns if an element via the byLocator is selected on the page at this exact point in time.
	 * @param byLocator
	 * @return
	 */
	public boolean isSelected(By byLocator){
		WebElement element = findElement(byLocator, 0);
		if((element!=null) && element.isSelected()){
			return true;
		}
        return false;
	}
	
	/**
	 * Finds a hidden element that may or may not be displayed to the user by ID.  Then returns 
	 * the attribute you specify of that element.  If no element is found by the ID passed in immediately 
	 * then an error is logged and the test continues.
	 * @param id
	 * @param attribute
	 * @return
	 * 
	 * Should use getAttribute(By byLocator, String attribute) instead.  You can pass in any byLocator, not just an ID into that method.
	 */
	@Deprecated
	public String getHiddenElementAttribute(String id, String attribute){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
        WebElement element = (WebElement) ((JavascriptExecutor) driver).executeScript("return document.getElementById('" + id + "');");
        if(element == null){
            logErrorForNotFindingElement(By.id(id));
            return "";
        }
        return element.getAttribute(attribute);
    }
	   
	/**
	 * Returns the value of the specified attribute of an element via the byLocator.  If element is not found 
	 * immediately, an error is logged and the test will continue.  This method searches the entire DOM and will 
	 * find an element even if it's not displayed to the user.
	 * @param byLocator
	 * @param attribute
	 * @return
	 */
	public String getAttribute(By byLocator, String attribute){
	    WebElement element = findElementThatIsPresent(byLocator, 0);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return "";
        }
        return element.getAttribute(attribute);
	}
	/**
	 * Returns the value of the specified attribute of an element.  If element is null, 
	 * an error is logged and the test will continue.  If the element you are looking for is within the DOM 
	 * but not visible to the user use method: getHiddenElementAttribute().
	 * @param element
	 * @param attribute
	 * @return
	 */
	public String getAttribute(WebElement element, String attribute){
	    if(element == null){
	    	logErrorForNotFindingElement();
	        return "";
	    }
	    return element.getAttribute(attribute);
    }
	/**
	 * Returns the value of the InnerHTML attribute of an element.  If element is null, 
	 * an error is logged and the test will continue.
	 * @param element
	 * @return
	 */
	public String getInnerHTMLAttribute(WebElement element){
        /*NOTE: As of FF49, innerHTML is only a property that must be retrieved via Javascript.
		* Although past versions allowed us to the the innerHTML attribute of an element, as of FF 49
		* this functionality has been removed and must be retrieved via Javascript.*/
		String innerHTML = "";
        if(element == null){
            logErrorForNotFindingElement();
        } else {
			Object innerHTMLObject = ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML", element);
	
	        if (innerHTMLObject != null) {
	        	innerHTML = innerHTMLObject.toString();
	        } else {
	        	LoggingUtility.logError("Unable to look up innerHTML of element: " + element);
	        }
        }
		return innerHTML;
    }
	
	/**
	 * Returns the text value of an element via the byLocator.  If the element can not be found immediately 
	 * an error is logged and the test will continue.
	 * @param byLocator
	 * @return
	 */
	public String getText(By byLocator){
	    WebElement element = findElementThatIsPresent(byLocator, 0);
        if(element == null){
            logErrorForNotFindingElement(byLocator);
            return "";
        }
        return element.getText();
    }
	/**
	 * Returns the text value of an element.  If the element is null 
	 * an error is logged and the test will continue.
	 * @param element
	 * @return
	 */
	public String getText(WebElement element){
        if(element == null){
            logErrorForNotFindingElement();
            return "";
        }
        return element.getText();
	}
	

}
