/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/RegionProperties.java $
 $LastChangedRevision: 1758 $
 $Author: uz0s $
 $LastChangedDate: 2015-09-02 16:30:15 -0400 (Wed, 02 Sep 2015) $
*/
package com.vanguard.selenium.inner.base;

import java.util.HashMap;
import java.util.Map;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

public enum RegionProperties {

    DEFAULT("defaults.properties"),
    E("e_region.properties"),
    F("f_region.properties"),
    X("x_region.properties"),
    M("m_region.properties"),
    P("p_region.properties"),
    S("s_region.properties"),
    REGRESSION_MULTIMODULE_DEFAULT("regionConfig.properties"),
    REGRESSION_MULTIMODULE_E("regionConfig_e.properties"),
    REGRESSION_MULTIMODULE_F("regionConfig_f.properties"),
    REGRESSION_MULTIMODULE_X("regionConfig_x.properties"),
    REGRESSION_MULTIMODULE_M("regionConfig_m.properties"),
    REGRESSION_MULTIMODULE_P("regionConfig_p.properties"),
    REGRESSION_MULTIMODULE_S("regionConfig_s.properties");

    private String region;

    private RegionProperties(String region){
        this.region = region;
    }
    
    @Override
    public String toString() {
        return region;
    }
    
    public boolean isClassPathFile() {
        if(this.toString().contains("regionConfig")){
            return true;
        }
        return false;
    }
    
    public RegionProperties determinOverrideFileBasedOnRegionFile() {
        RegionProperties overrideFile = null;
        switch (this) {
        case DEFAULT:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_DEFAULT;
            break;
        case E:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_E;
            break;
        case F:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_F;
            break;
        case X:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_X;
            break;
        case M:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_M;
            break;
        case P:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_P;
            break;
        case S:
            overrideFile = RegionProperties.REGRESSION_MULTIMODULE_S;
            break;
        default:
            LoggingUtility.logError("No known Region Property type of: " + this);
            break;
        }
        return overrideFile;
    }
    
    public String getRegionFileName() {
        return region;
    }
    
    @Deprecated
    private static final Map<String, RegionProperties> STRING_TO_ENUM = new HashMap<String, RegionProperties>();
    static{
        for(RegionProperties curEnum : values()){
            STRING_TO_ENUM.put(curEnum.toString(), curEnum);
        }
    }

    /**
     * Use fromRegionString(String region)
     */
    @Deprecated
    public static RegionProperties fromString(String region){
        return STRING_TO_ENUM.get(region);
    }
    
    /**
     * 
     * @param region (i.e. 'e', 'E', 'default, 'DeFaUlt')
     * @return RegionProperties
     */
    public static RegionProperties fromRegionString(String region) {
        return valueOf(region.toUpperCase());
    }
    
}