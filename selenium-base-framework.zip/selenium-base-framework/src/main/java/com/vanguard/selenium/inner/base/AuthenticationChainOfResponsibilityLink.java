/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/AuthenticationChainOfResponsibilityLink.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

/**
 * @author uc4b
 *
 */
public abstract class AuthenticationChainOfResponsibilityLink {
    
    private final AuthenticationChainOfResponsibilityLink nextLinkInChain;
    
    protected AuthenticationService authenticationService = AuthenticationService.getInstance();
    
    public AuthenticationChainOfResponsibilityLink(AuthenticationChainOfResponsibilityLink nextLinkChainLink) {
        this.nextLinkInChain = nextLinkChainLink;
    }
    
    public AuthenticationResponse authenticateChainLink(String username,String password) {
        AuthenticationResponse authenticationResponse = authenticate(username,password);
        if(authenticationResponse.getStatus().equals(AuthenticationStatus.FAILURE)) {
            authenticationResponse = nextLinkInChain.authenticateChainLink(username,password);
        }
        return authenticationResponse;
    }
    
    abstract AuthenticationResponse authenticate(String username, String password);

}
