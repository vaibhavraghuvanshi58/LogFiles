/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/ExpectedConditionBuilder.java $
 $LastChangedRevision: 644 $
 $Author: uz0s $
 $LastChangedDate: 2014-08-19 12:53:27 -0400 (Tue, 19 Aug 2014) $
 */
package com.vanguard.selenium.inner.core.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;


/**
 * Contains a number of methods to create Anonymous ExpectedCondition objects for use in WebDriverWait calls
 * @author utcl
 */
public class ExpectedConditionBuilder {

    static final String CBD_AJAX_PROGRESS_JS = "return cbd.ContentLoader.isRequestInProgress()";

    /**
     * Builds an ExpectedCondition that will check if a WebElement isEnabled.
     * @param elementId
     * @param driver
     * @return
     */
    public ExpectedCondition<Boolean> buildElementEnabledCondition(final String elementId, final WebDriver driver) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                try {
                    return driver.findElement(By.id(elementId)).isEnabled();
                } catch (final StaleElementReferenceException e) {
                    LoggingUtility.logError("Error waiting for element to be enabled.", e);
                    return false;
                }
            }
        };
    }

    /**
     * Builds an ExpectedCondition that enables waiting for an Ajax request to finish processing.
     * 
     * Note: Uses CBD javascript to determine if AJAX is running.
     * 
     * @param driver
     * @return
     */
    public ExpectedCondition<Boolean> buildAjaxCompleteCondition(final WebDriver driver) {
        return new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                try {
                    final String ajaxRunningScript = CBD_AJAX_PROGRESS_JS;
                    final JavascriptExecutor js = (JavascriptExecutor) driver;
                    final Object ajaxRunning = js.executeScript(ajaxRunningScript);

                    if (ajaxRunning != null && ajaxRunning instanceof Boolean) {
                        return !((Boolean) ajaxRunning).booleanValue();
                    } else {
                        return false;
                    }

                } catch (final Exception e) {
                    LoggingUtility.logError("Error waiting for Ajax", e);
                    return false;
                }
            }
        };
    }

    /**
     * NOTE: This method will take the default Selenium time of 30 seconds to tell us if the element is NOT displayed.
     * Builds an ExpectedCondition that checks if a WebElement is displayed.
     * @param element
     * @return
     */
    public ExpectedCondition<Boolean> buildElementDisplayedCondition(final WebElement element) {
        return new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {
                return element.isDisplayed();
            }
        };
    }

    /**
     * Builds an ExpectedCondition that checks if a WebElement is displayed after finding it by id.
     * @param elementId
     * @return
     */
    public ExpectedCondition<Boolean> buildIsDisplayedConditionById(final WebDriver driver, final String elementId) {
        return new ExpectedCondition<Boolean>() {

            public Boolean apply(WebDriver d) {
                return driver.findElement(By.id(elementId)).isDisplayed();
            }
        };
    }

}
