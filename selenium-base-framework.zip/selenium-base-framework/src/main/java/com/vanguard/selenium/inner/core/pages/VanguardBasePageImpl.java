/*
 ****************************************************************************
 *
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/pages/VanguardBasePageImpl.java $
 $LastChangedRevision:7/03/2014
 $Author:utbx

   Interface describing functionality for one "view".
*/
package com.vanguard.selenium.inner.core.pages;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;


public abstract class VanguardBasePageImpl extends SeleniumCoreWrapperMethods implements VanguardBasePageInterface{

	
	public VanguardBasePageImpl(WebDriver driver) {
		this.driver = driver;

		/*TODO: Add initElements in for backward compatibility.  Any 3.x Inner Source pages should
		 * never need this.  However, if your project is declaring to use 3.x Inner Source, and you have 
		 * a dependency on a project that still uses the 2.x Inner Source for their pages, we will need
		 * to call initElements for them.
		 */
		Class<? extends VanguardBasePageImpl> clazz = this.getClass();
		if(isFindByAnnotationPresentInClass(clazz)){
			LoggingUtility.logWarning("Your Page Object class: " + clazz.getSimpleName() + ", is utilizing an old Selenium Standard.\n" + 
									  "WARNING: You should convert this page to use By Locators instead of using @FindBys.\n" + 
									  "Please see documentation: http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Page%20Objects%20(deeper%20dive).aspx");
			PageFactory.initElements(driver, this);
		}
	}
	
	private boolean isFindByAnnotationPresentInClass(Class<? extends VanguardBasePageImpl> clazz) {
		Field[] fields = clazz.getDeclaredFields();
		for (Field field : fields) {
			if(field.isAnnotationPresent(FindBy.class) || field.isAnnotationPresent(FindBys.class)){
				return true;
			}
		}
		return false;
	}

	@Deprecated
	/**This is an old Inner Source 2.x method and should no longer be called.  
	 * Use isCurrentlyLoaded() instead.
	 */
	public boolean isLoadedWithinWaitTime(int maxWaitTimeToCheckInSeconds){
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		boolean returnVal = false;
		for(int waitCounter = -1; waitCounter < maxWaitTimeToCheckInSeconds; waitCounter++){
			try{
				PageFactory.initElements(driver, this);
				if(isCurrentlyLoaded()){
					returnVal = true;
					break;
				}
				SeleniumWaitHelper.pause(1);
			} catch (Exception e) {
				//Do Nothing, Wait 1 second and potentially try again
				SeleniumWaitHelper.pause(1);
			}
		}
		return returnVal;
	}
	

	
	/**
	 * Returns if the element currently in focus matches the same element found via the byLocator.  If no element can be found 
	 * from the byLocator this will return false.
	 * @param byLocator
	 * @return
	 */
	public boolean isElementInFocus(By byLocator) {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
        WebElement elementWithFocus = driver.switchTo().activeElement();
        WebElement pageElement = findElement(byLocator);
        return elementWithFocus.equals(pageElement);
    }
	
	/**
	 * This will close an alert if one is present.  If no alert is present, this will do nothing.
	 */
	public void closeAlert() {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
		if(driver.switchTo().alert() != null)
		{
			Alert alert = driver.switchTo().alert();
			alert.dismiss();
		}
	}
	
    /** Switches focus to the THE other window.  THIS METHOD REQUIRES 
     * EXACTLY 2 WINDOWS TO BE OPEN!<p>
     * 
     * Note: If only 1 window is open, you will be switched to it.  If more 
     * than 2 windows are open, it will remain focus on the original window. 
     * Also Note: This method only works on new windows, NOT tabs.
     */
    public void switchFocusToTheOtherWindow() {
		if(driver==null){
			throwNullPointerExeptionForNullDriver();
		}
        
        String curWindowHandle = "";
        try{
            curWindowHandle = driver.getWindowHandle();
        }catch(Exception e){
            //If we can't get the WindowHandle, it's most likely been closed.
            //Hopefully there's another handle we're switching to below.
        }
        Set<String> handles = driver.getWindowHandles();
        if(handles.size() > 2){
            LoggingUtility.logError("Couldn't switch window focus because we have more than 2 windows open.");
            return;
        }
        for (String handle : handles) {
            if(!handle.equalsIgnoreCase(curWindowHandle)){
                driver.switchTo().window(handle);
                break;
            }
        }
    }
    
    /**
     * THIS SHOULD NEVER BE IN COMMITTED CODE!!  This method is for debugging purposes only. 
     * Even then, in most cases you can use the Console in the Developer Tools of the browser. 
     * As a last resort you can use this method when executing the entire flow to verify Selenium is getting the correct element. 
     * Please visit this site for better ways to look up elements before using this method: 
     * <a href="http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Locators.aspx">http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Locators.aspx</a>
     * @param locator
     */
    public void highlightElementForDebuggingCode(By locator) {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])",
				findElement(locator),
			    "style",
			    "border: 2px solid red; border-style: dashed;");
    }
    /**
     * THIS SHOULD NEVER BE IN COMMITTED CODE!!  This method is for debugging purposes only. 
     * Even then, in most cases you can use the Console in the Developer Tools of the browser. 
     * As a last resort you can use this method when executing the entire flow to verify Selenium is getting the correct element. 
     * Please visit this site for better ways to look up elements before using this method: 
     * <a href="http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Locators.aspx">http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Locators.aspx</a>
     * @param locator
     */
    public void highlightElementForDebuggingCode(WebElement element) {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])",
				element,
			    "style",
			    "border: 2px solid red; border-style: dashed;");
    }
	
	
	//More advanced Utility methods:
    /**
     * This will go through every table on the current page looking for the input textToSearchFor. 
     * Once the text is found, we will return the cell one over to the right of where that text was found.
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getElementInNextCellOverFromCertainText('Billy') => WebElement object containing the text 'billy@test.com'
     * @param textToSearchFor
     * @return
     */
    protected WebElement getElementInNextCellOverFromCertainText(String textToSearchFor)
    {
        List<WebElement> tables = findElements(By.tagName("table"), 3);
        for (WebElement logintable : tables)
        {
            WebElement returnElement = getElementInNextCellOverFromCertainTextOfSpecificTable(textToSearchFor, logintable);
            if(returnElement != null){
                return returnElement;
            }
        }
        return null;
    }
    /**
     * This will go through the specific input table on the current page looking for the input textToSearchFor. 
     * Once the text is found, we will return the cell one over to the right of where that text was found.
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getElementInNextCellOverFromCertainTextOfSpecificTable('Billy', tableObject) => WebElement object containing the text 'billy@test.com'
     * @param textToSearchFor
     * @param table
     * @return
     */
    protected WebElement getElementInNextCellOverFromCertainTextOfSpecificTable(String textToSearchFor, WebElement table) {
        List<WebElement> rows = findElements(table, By.tagName("tr"), 0);
        for (WebElement row : rows) 
        {
            List<WebElement> cell = findElements(row, By.tagName("td"), 0);
            for(int cellPos = 0; cellPos < cell.size(); cellPos++){
                if(textToSearchFor.equalsIgnoreCase(cell.get(cellPos).getText().trim())){
                    return cell.get(cellPos + 1);
                }
            }
        }
        return null;
    }
    /**
     * This will go through every table on the current page looking for the input textToSearchFor. 
     * Once the text is found, we will return the WebElement of the cell where that text was found.
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getCellFromCertainText('Billy') => WebElement object containing the text 'Billy'
     * @param textToSearchFor
     * @return
     */
    protected WebElement getCellFromCertainText(String textToSearchFor)
    {
        List<WebElement> tables = findElements(By.tagName("table"), 3);
        for (WebElement logintable : tables)
        {
            WebElement returnElement = getCellFromCertainTextOfSpecificTable(textToSearchFor, logintable);
            if(returnElement != null){
                return returnElement;
            }
        }
        return null;
    }
    /**
     * This will go through the table specified on the current page looking for the input textToSearchFor. 
     * Once the text is found, we will return the WebElement of the cell where that text was found.<br>
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getCellFromCertainTextOfSpecificTable('Billy', tableObject) => WebElement object containing the text 'Billy'
     * @param textToSearchFor
     * @param table
     * @return
     */
    protected WebElement getCellFromCertainTextOfSpecificTable(String textToSearchFor, WebElement table) {
        List<WebElement> rows = findElements(table, By.tagName("tr"), 0);
        for (WebElement row : rows) 
        {
            List<WebElement> cells = findElements(row, By.tagName("td"), 0);
            for(int cellPos = 0; cellPos < cells.size(); cellPos++){
                WebElement cell = cells.get(cellPos);
                if(cell.getText().equalsIgnoreCase(textToSearchFor)){
                    return cell;
                }
            }
        }
        return null;
    }
    /**
     * This will go through the specific table input on the current page looking a cell that contains the partial input text. 
     * Once that partial text is found, we will return the WebElement of the cell where that text was found.<br>
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getCellFromCertainText('@test', tableObject) => WebElement object containing the text 'billy@test.com'
     * @param textToSearchFor
     * @param table
     * @return
     */
    protected WebElement getCellThatContainsTextOfSpecificTable(String textPartialToSearchFor, WebElement table) {
        List<WebElement> rows = findElements(table, By.tagName("tr"), 0);
        for (WebElement row : rows) 
        {
            List<WebElement> cells = findElements(row, By.tagName("td"), 0);
            for(int cellPos = 0; cellPos < cells.size(); cellPos++){
                WebElement cell = cells.get(cellPos);
                if(cell.getText().toLowerCase().contains(textPartialToSearchFor.toLowerCase())){
                    return cell;
                }
            }
        }
        return null;
    }
    /**
     * This will go through the specific table input on the current page looking a cell that contains the partial input text. 
     * Once that partial text is found, we will return the WebElement of the cell near where that match was found.  
     * We will count (negative to the left, positive to the right) that many cells over from the match and return that cell.<br>
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getCellFromCertainText('@test', -1, tableObject) => WebElement object containing the text 'Billy'
     * getCellFromCertainText('@test', 0, tableObject) => WebElement object containing the text 'billy@test.com'
     * getCellFromCertainText('@test', 1, tableObject) => WebElement object containing the text '111-22-3333'
     * @param textToSearchFor
     * @param table
     * @param numOfCellsOver: negative means to left of match, 0 will return the matched cell, positive means to the right of the match
     * @return
     */
    protected WebElement getCellAnyNumberOfCellsOverFromCellThatContainsTextOfSpecificTable(String textPartialToSearchFor, int numOfCellsOver, WebElement table) {
        List<WebElement> rows = findElements(table, By.tagName("tr"), 0);
        for (WebElement row : rows) 
        {
            List<WebElement> cells = findElements(row, By.tagName("td"), 0);
            for(int cellPos = 0; cellPos < cells.size(); cellPos++){
                WebElement cell = cells.get(cellPos);
                if(cell.getText().toLowerCase().contains(textPartialToSearchFor.toLowerCase())){
                	if( ((cellPos + numOfCellsOver) > 0) || ((cellPos + numOfCellsOver) < cells.size()) ){
                		return cells.get(cellPos + numOfCellsOver);
                	}
                	LoggingUtility.logError("We can't get the cell you specified.  We found a match in the table, but can't move over the numOfCells specified.\n" +
                			"Trying to get cell [" + cellPos + numOfCellsOver  + "] of [" + cells.size() + "] cells in the row.");
                	return null;
                }
            }
        }
        return null;
    }
    /**
     * This will go through the specific input table on the current page looking for the input cell we specify. 
     * Once that cell is found, we will return the cell one over to the right of it.
     * Ex:<br>{@code
     * |Name |Email         |SSN|}<br>{@code
     * |Billy|billy@test.com|111-22-3333|}<br>
     * getElementInNextCellOverFromSpecificCellOfSpecificTable(WebElement pointing to 'Billy', tableObject) => WebElement object containing the text 'billy@test.com'
     * @param textToSearchFor
     * @param table
     * @return
     */
    protected WebElement getElementInNextCellOverFromSpecificCellOfSpecificTable(WebElement cellToLeftOfOneWeWant, WebElement table) {
        List<WebElement> rows = findElements(table, By.tagName("tr"), 0);
        for (WebElement row : rows) 
        {
            List<WebElement> cell = findElements(row, By.tagName("td"), 0);
            for(int cellPos = 0; cellPos < cell.size(); cellPos++){
                if(cellToLeftOfOneWeWant.equals(cell.get(cellPos))){
                    return cell.get(cellPos + 1);
                }
            }
        }
        return null;
    }
    
    
    
    /**
     * Returns true if the element via locator is found immediately and that element contains 
     * at least one item in the matchList (case is NOT sensitive).  If the element can not be 
     * found immediately an error is logged and we return false.  If the element is found but none 
     * of the matchList items are contained in the element's text this returns false.
     * @param locator
     * @param matchList
     * @return
     */
    protected boolean doesElementContainAtLeastOneStringFromList(By locator, String[] matchList){
        WebElement element = findElement(locator);
        if(element == null){
        	logErrorForNotFindingElement();
        	return false;
        }
        for (String matchItem : matchList) {
            if(element.getAttribute("innerHTML").toLowerCase().contains(matchItem.toLowerCase())){
                return true;
            }
        }
        return false;
    }

}
