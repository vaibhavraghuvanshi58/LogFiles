/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/BaseTestWatcher.java $
 $LastChangedRevision: 5583 $
 $Author: uz0s $
 $LastChangedDate: 2017-05-31 13:01:21 -0400 (Wed, 31 May 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.rules.TestWatcher;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.utils.ScreenshotUtils;

/**
 * @author un3k
 * 
 */
public class BaseTestWatcher extends TestWatcher {
    protected void updateSnapshotCsv(String snapshotName, String fileName, Map<String, String> fields) throws IOException {
        boolean needHeaderRow = true;
        String filePathString = getFilePath() + fileName;

        File f = new File(filePathString);
        if (f.exists()) {
            needHeaderRow = false;
        }

        FileWriter pw = new FileWriter(f, true);
        SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy HH:mm");
        String date = formatter.format(new Date());

        if (needHeaderRow) {
            pw.append("Date,");
            for (String field : fields.keySet()) {
                pw.append(field + ",");
            }
            pw.append("SnapshotName");
            pw.append(System.getProperty("line.separator"));
        }

        pw.append(date + ",");
        for (String value : fields.values()) {
            pw.append(value + ",");
        }
        pw.append(snapshotName + ".png");
        pw.append(System.getProperty("line.separator"));
        pw.flush();
        pw.close();
    }

    protected String cleanTextString(String inputString) {

        String invalidChars;
        StringBuffer cleanedName = new StringBuffer();
        if (PropertiesManager.isRunningOnWindows()) {
            invalidChars = "\\/:*?\"<>|";
        } else { // assume Unix
            invalidChars = "/";
        }

        char[] chars = inputString.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (!(invalidChars.indexOf(chars[i]) >= 0) // OS-invalid
                    && !(chars[i] < '\u0020') // ctrls
                    && !(chars[i] > '\u007e' && chars[i] < '\u00a0') // ctrls
            ) {
                cleanedName.append(chars[i]);
            }
        }
        return cleanedName.toString().trim();
    }

    protected void takeScreenShot(String fileName, WebDriver driver) {
        ScreenshotUtils.takeScreenShot(fileName, driver);
    }

    protected String getFilePath() {

        String baseWindowsFilePath = PropertiesManager.getProperty(PropertiesManager.BASE_WINDOWS_FILE_PATH);
        if (PropertiesManager.isRunningOnWindows()) {
            return StringUtils.isNotBlank(baseWindowsFilePath) ? baseWindowsFilePath : "C:\\target\\screenshots\\";
        } else {
            return "target//screenshots//";
        }
    }

}
