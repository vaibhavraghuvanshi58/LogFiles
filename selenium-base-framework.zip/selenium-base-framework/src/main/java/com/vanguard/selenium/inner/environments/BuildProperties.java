/*
 ****************************************************************************
 *
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/BuildProperties.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

public class BuildProperties {

	private String projectName;
	private String buildNumber;
	private String sourceControlRevisionNum;
	private String entireBuildTag;
	
	public BuildProperties(String projectName, String buildNumber, String sourceControlRevisionNum,
			String entireBuildTag) {
		super();
		this.projectName = projectName;
		this.buildNumber = buildNumber;
		this.sourceControlRevisionNum = sourceControlRevisionNum;
		this.entireBuildTag = entireBuildTag;
	}
	
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getBuildNumber() {
		return buildNumber;
	}
	public void setBuildNumber(String buildNumber) {
		this.buildNumber = buildNumber;
	}
	public String getSourceControlRevisionNum() {
		return sourceControlRevisionNum;
	}
	public void setSourceControlRevisionNum(String sourceControlRevisionNum) {
		this.sourceControlRevisionNum = sourceControlRevisionNum;
	}
	public String getEntireBuildTag() {
		return entireBuildTag;
	}
	public void setEntireBuildTag(String entireBuildTag) {
		this.entireBuildTag = entireBuildTag;
	}
	
	@Override
	public boolean equals(Object compareObject) {
	    if (compareObject == null) {
	        return false;
	    }
	    BuildProperties compareProperties = null;
	    try {
	    	compareProperties = (BuildProperties) compareObject;
	    } catch(ClassCastException e) {
	    	return false;
	    }
	    if (isThisPropertyNullButComparePropertyIsNot(this.projectName, compareProperties.getProjectName()) || 
	    		isThisPropertyDifferentThanCompareProperty(this.projectName, compareProperties.getProjectName())) {
	        return false;
	    }
	    if (isThisPropertyNullButComparePropertyIsNot(this.buildNumber, compareProperties.getBuildNumber()) || 
	    		isThisPropertyDifferentThanCompareProperty(this.buildNumber, compareProperties.getBuildNumber())) {
	        return false;
	    }
	    if (isThisPropertyNullButComparePropertyIsNot(this.sourceControlRevisionNum, compareProperties.getSourceControlRevisionNum()) || 
	    		isThisPropertyDifferentThanCompareProperty(this.sourceControlRevisionNum, compareProperties.getSourceControlRevisionNum())) {
	        return false;
	    }
	    if (isThisPropertyNullButComparePropertyIsNot(this.entireBuildTag, compareProperties.getEntireBuildTag()) || 
	    		isThisPropertyDifferentThanCompareProperty(this.entireBuildTag, compareProperties.getEntireBuildTag())) {
	        return false;
	    }
	    return true;
	}

	private boolean isThisPropertyNullButComparePropertyIsNot(String thisProperty, String compareProperty) {
		return (thisProperty==null) && (compareProperty != null);
	}
	
	private boolean isThisPropertyDifferentThanCompareProperty(String thisProperty, String compareProperty) {
		return (thisProperty != null) && (!thisProperty.equals(compareProperty));
	}
}
