/*
 ****************************************************************************
 * 
 * Copyright (c)2016 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/EnvironmentConfiguration.java $
 $LastChangedRevision: 5696 $
 $Author: uz0s $
 $LastChangedDate: 2017-07-10 11:36:19 -0400 (Mon, 10 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author uz0s
 *
 */
public class EnvironmentConfiguration {

    //Properties file Strings
    public static final String BROWSER_TYPE = "BrowserType";
    public static final String BROWSER_VERSION = "BrowserVersion";
    public static final String OS_TYPE = "OSType";
    public static final String OS_VERSION = "OSVersion";
    
    //SAUCELABS Capability values
    public static final String PARENT_TUNNEL = "parent-tunnel";
    public static final String SAUCE_ROOT_ACCT_NAME = "VanguardRoot";
    public static final String SELENIUM_VERSION = "seleniumVersion";
    public static final String VERSION = "version";
    public static final String NAME_OF_TEST = "name";
    public static final String PLATFORM = "platform";
    public static final String CHROME_DRIVER_VERSION = "chromedriverVersion";
    public static final String IE_DRIVER_VERSION = "iedriverVersion";
    public static final String IDLE_TIMEOUT = "idleTimeout";
    public static final String SHOULD_RECORD_VIDEO = "recordVideo";
    public static final String SHOULD_RECORD_SNAPSHOTS = "recordScreenshots";
    public static final String SAUCELABS_BUILD_LABEL = "build";
    public static final String SAUCELABS_TAG_LABELS = "tags";
    public static final String SCREEN_RESOLUTION = "screenResolution";
    public static final String TIME_ZONE = "timeZone";

    
    
    protected DesiredCapabilities environmentCapabilities;
    
    public EnvironmentConfiguration(DesiredCapabilities environmentCapabilities){
        this.environmentCapabilities = environmentCapabilities;
    }
    
    public DesiredCapabilities getDesiredCapabilities() {
        return environmentCapabilities;
    }

    public void addCapability(String capability, String value) {
        environmentCapabilities.setCapability(capability, value);
    }
    
	public String getSpecificCapabilityValue(String propertyName) {
		String capabilityValue = "";
		try {
			capabilityValue = (String) getDesiredCapabilities().getCapability(propertyName);
		} catch(ClassCastException e) {
			LoggingUtility.logError("Can not cast object to string: " + getDesiredCapabilities().getCapability(propertyName));
		} catch (NullPointerException e) {
			LoggingUtility.logError("Can't get capability for property: " + propertyName + ", because capabilities, or propertyName is null");
		}
		return capabilityValue;
	}
}
