/*
 ****************************************************************************
 * 
 * Copyright (c)2011 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/logon/user/TestCrewMemberInformation.java $
 $LastChangedRevision: 3342 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 17:17:12 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.logon.user;

import com.vanguard.selenium.inner.base.Region;

/**
 * @author urkh
 * 
 */
public class TestCrewMemberInformation {

    private String poid;

    private String userId;

    private String password;

    private Region region;

    private String crewType;

    public TestCrewMemberInformation(String poid, String userId) {
        this.poid = poid;
        this.userId = userId;
    }
    
    public TestCrewMemberInformation(String poid, String userId, String password) {
        this.poid = poid;
        this.userId = userId;
        this.password = password;
    }
    
    public TestCrewMemberInformation(InternalUserInformation internalUserInfo) {
        this.poid = internalUserInfo.getPoid();
        this.userId = internalUserInfo.getUserId();
        this.password = internalUserInfo.getPassword();
        this.region = internalUserInfo.getRegion();
        this.crewType = internalUserInfo.getCrewType();
    }

    /**
     * 
     */
    public TestCrewMemberInformation() {

    }

    public String getPoid() {
        return poid;
    }

    public void setPoid(String poid) {
        this.poid = poid;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param region
     */
    public void setRegion(Region region) {
        this.region = region;
    }

    /**
     * @return the crewType
     */
    public String getCrewType() {
        return crewType;
    }

    /**
     * @param crewType
     *            the crewType to set
     */
    public void setCrewType(String crewType) {
        this.crewType = crewType;
    }

    /**
     * @return the region
     */
    public Region getRegion() {
        return region;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
