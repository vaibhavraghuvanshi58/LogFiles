/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/AuthenticationService.java $
 $LastChangedRevision: 5445 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-19 11:58:01 -0400 (Wed, 19 Apr 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;

import sun.net.www.protocol.https.HttpsURLConnectionImpl;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author ubmq
 * 
 */
@SuppressWarnings("restriction")
public class AuthenticationService {
    
    public static final String DEV_INTERNAL_VANGUARD_DOMAIN = "https://devinvestor.vanguard.com:1443/home/";

    public static final String SAT_INTERNAL_VANGUARD_DOMAIN = "https://satinvestor.vanguard.com:1443/home/";

    private static final AuthenticationService AUTHENTICATION_SERVICE = new AuthenticationService();

    private static final int CONNECTION_TIMEOUT_IN_MILLISECONDS = 3000;
    protected static final String SPX_TOKEN_TYPE = "AD";
    
    static final int GLOBAL_LONG_WAIT_TIME = 600000;
    static final int GLOBAL_SHORT_WAIT_TIME = 20000;
    
    static final String ACCESS_DENIED_MESSAGE = ". Access denied.";
    static final String AUTH_FAIL_EXCEPTION_PREFIX = "Authentication failed";
    
    public static final String SUCCESSFUL_STATUS = "0";
    
    static final String PASSWORD_BLANK_EXCEPTION = "Password cannot be blank";

    static final String USER_NAME_BLANK_EXCEPTION = "User Name cannot be blank";
    
    private JSONParserService jsonParserService = new JSONParserService();
    
    public static AuthenticationService getInstance() {
        return AUTHENTICATION_SERVICE;
    }
    private AuthenticationService() {
        
    }
    
    public void navigateToAVanguardDomainSite(WebDriver driver) {
        driver.manage().timeouts().pageLoadTimeout(GLOBAL_SHORT_WAIT_TIME, TimeUnit.MILLISECONDS);
        boolean wasWebdriverGetSuccessful = false;
        try {
            driver.get(SAT_INTERNAL_VANGUARD_DOMAIN);
            wasWebdriverGetSuccessful = true;
        }catch (Exception exception) {
            LoggingUtility.logError("Failure in attempting to get vanguard domain site.  Attempting another :\n" + exception.getMessage());
        }
        if(!wasWebdriverGetSuccessful) {
            try {
                driver.get(DEV_INTERNAL_VANGUARD_DOMAIN);
            } catch (Exception exception) {
                throw new PageNavigationException("Failure in attempting to get a second vanguard domain site. Failing with message:\n" +exception.getMessage());
            }
        }
        driver.manage().timeouts().pageLoadTimeout(GLOBAL_LONG_WAIT_TIME, TimeUnit.MILLISECONDS);
    }


    protected JSONObject getPOSTAuthenticationRequestResponse(AuthenticationUrl authUrl, String userID, String password) throws IOException {
        StringBuffer response = new StringBuffer();
        
        URL authenticationURL = new URL(authUrl.getUrl());
        HttpsURLConnection authenticationConnection = (HttpsURLConnectionImpl) authenticationURL.openConnection();

        authenticationConnection.setRequestMethod("POST");
        authenticationConnection.setRequestProperty("User-Agent", "Super Agent/0.0.1");
        authenticationConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        authenticationConnection.setConnectTimeout(CONNECTION_TIMEOUT_IN_MILLISECONDS);

        String urlParameters = "SPX_TOKEN_TYPE=" + SPX_TOKEN_TYPE + "&SPX_TOKEN_USER=" + userID + "&SPX_TOKEN_PASSWORD=" + password;

        authenticationConnection.setDoOutput(true);
        DataOutputStream authConnectionOutputStream = null;
        try{
            authConnectionOutputStream = new DataOutputStream(authenticationConnection.getOutputStream());
            authConnectionOutputStream.writeBytes(urlParameters);
            authConnectionOutputStream.flush();
        }catch (IOException ioException) {
            LoggingUtility.logError("Unable to get outputstream from authenticatied connection to server.  With message: " + ioException.getMessage());
            throw new IOException(ioException);
        }finally{
            if (authConnectionOutputStream != null) {
                try{
                    authConnectionOutputStream.close();
                }catch(IOException ioExceptionConnectionOutputSteam) {
                    //do nothing
                }
            }            
        }
        
        BufferedReader authConnectionInputStream = null;
        try {
            authConnectionInputStream = new BufferedReader(new InputStreamReader(authenticationConnection.getInputStream()));
            String inputLine;
            
            while ((inputLine = authConnectionInputStream.readLine()) != null) {
                response.append(inputLine);
            }
            
        }catch (IOException ioException) {
            LoggingUtility.logError("Unable to get inputstream from authenticated connection to authentication server.  With message: " + ioException.getMessage());
            throw new IOException(ioException);
        }finally{
            if (authConnectionInputStream != null) {
                try{
                    authConnectionInputStream.close();
                }catch(IOException ioExceptionConnectionInputStream) {
                    //do nothing
                }
            }
        }
        JSONObject jsonAuthenticationResponse = jsonParserService.getJSONObjectFromString(response.toString());
        return jsonAuthenticationResponse;
    }
    
    
    public StatusMessageContainer getJSONResponseFromJSONOject(JSONObject responseObject) {
        String message = jsonParserService.getStringFromJSONObject(responseObject, JSONParserService.MESSAGE);
        String status = jsonParserService.getStringFromJSONObject(responseObject, JSONParserService.STATUS);
        return new StatusMessageContainer(message, status);
    }
    

    protected void verifyValidInputs(String userID, String password) throws IllegalArgumentException{
        if(userID == null || userID.equals("")){
            throw new IllegalArgumentException(USER_NAME_BLANK_EXCEPTION);
        }
        if(password == null || password.equals("")){
            throw new IllegalArgumentException(PASSWORD_BLANK_EXCEPTION);
        }
    }
    
    public class StatusMessageContainer  {
        private final String message;
        private final String status;

        public StatusMessageContainer(String message, String status) {
            this.message = message;
            this.status = status;
        }
        
        public String getMessage() {
            return message;
        }
        
        public String getStatus() {
            return status;
        }
        
        public AuthenticationStatus getAuthenticationStatus() {
            AuthenticationStatus returnStatus = AuthenticationStatus.FAILURE;
            if (SUCCESSFUL_STATUS.equals(status)) {
                returnStatus = AuthenticationStatus.SUCCESS;
            }
            return returnStatus;
        }
    }
    
    
    
}
