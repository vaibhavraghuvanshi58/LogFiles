/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/DriverUtils.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

/**
 * Provides a simple WebDriver for use in Selenium Tests.
 * 
 * Available options are: Firefox Firefox Remote (for Grid) Chrome Chrome Mobile Chrome Remote (for Grid)
 */
@Deprecated
/** Use DriverFactory within selenium-test-data-framework **/
public class DriverUtils {

	public static final String LOCAL_CHROME_DRIVER_DEFAULT_LOCATION = "C:/ChromeDriver/chromedriver.exe";

	private static final String WINDOWS = "windows";
	private static final String OS_NAME = "os.name";
	public static final int DEFAULT_WAIT_TIME_30S = 30;
	public static final String pathToFirefox7 = "/opt/vgi/hudson/browsers/firefox/7.0.1/firefox/firefox";

	public static final String pathToFirefox10 = "/opt/vgi/hudson/browsers/firefox/10.0.1/firefox/firefox";

	public static final String pathToFirefox13 = "/opt/vgi/hudson/browsers/firefox/13.0/firefox/firefox";

	/**
	 * Returns a basic Firefox WebDriver from the default install location. Driver initialized with an implicit wait of 30s.
	 */
	public static WebDriver getFirefoxDriver() {
		WebDriver firefoxDriver = FirefoxDriverWithFastHomepage.getFirefoxDriverWithFasterHomepage();
		firefoxDriver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_TIME_30S, TimeUnit.SECONDS);
		return firefoxDriver;
	}

	/**
	 * Returns a basic remote Firefox WebDriver. Driver initialized with an implicit wait of 30s.
	 * 
	 * @param gridServer
	 * @return
	 */
	public static WebDriver getRemoteFirefoxDriver(String gridServer) {
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		WebDriver driver = null;
		try {
			driver = new RemoteWebDriver(new URL(gridServer), capability);
			driver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_TIME_30S, TimeUnit.SECONDS);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return driver;
	}

	/**
	 * Returns a basic Firefox WebDriver using the binary path specified. Use this method when you want to specify the version of FF you are using.
	 * Driver initialized with an implicit wait of 30s
	 */

	public static WebDriver getFirefoxVersion(String pathToBinary) {
		FirefoxBinary binary = new FirefoxBinary(new File(pathToBinary));
		WebDriver firefoxDriver = new FirefoxDriver(binary, null);
		firefoxDriver.manage().timeouts().implicitlyWait(DEFAULT_WAIT_TIME_30S, TimeUnit.SECONDS);
		return firefoxDriver;
	}

	@Deprecated
	public static WebDriver getFirefox7Driver() {
		return getFirefoxVersion(pathToFirefox7);
	}

	@Deprecated
	public static WebDriver getFirefox10Driver() {
		return getFirefoxVersion(pathToFirefox10);
	}

	@Deprecated
	public static WebDriver getFirefox13Driver() {
		return getFirefoxVersion(pathToFirefox13);
	}

	/**
	 * NOTE: Chrome is currently in an eval status. retryCount = how many times to try to get a driver instance before failing options = options on
	 * the browser instance like user-agent (for mobile)
	 */
	public static WebDriver getChromeDriver(int retryCount, ChromeOptions options) {
		WebDriver driver = null;
		for (int i = 0; i < retryCount; i++) {
			try {
				driver = getChromeDriver(options);
			} catch (WebDriverException e) {
				System.out.println("Unable to open Chrome on attempt " + (i + 1) + ".  Consider lowering the number of tests running in parallel.  The system may be resourced starved.");
			}
			if (driver != null) {
				return driver;
			}
		}
		System.out.println("Could not open Chrome after " + retryCount + " attempts.");
		return driver;
	}

	/**
	 * NOTE: Chrome is currently in an eval status. retryCount = how many times to try to get a driver instance before failing
	 */
	public static WebDriver getChromeDriver(int retryCount) {
		WebDriver driver = null;
		for (int i = 0; i < retryCount; i++) {
			try {
				driver = getChromeDriver();
			} catch (WebDriverException e) {
				System.out.println("Unable to open Chrome on attempt " + (i + 1) + ".  Consider lowering the number of tests running in parallel.  The system may be resourced starved.");
			}
			if (driver != null) {
				return driver;
			}
		}
		System.out.println("Could not open Chrome after " + retryCount + " attempts.");
		return driver;
	}

	/**
	 * Used for simulating Chrome on a mobile device NOTE: Chrome is currently in an eval status. retryCount = how many times to try to get a driver
	 * instance before failing
	 */
	public static WebDriver getChromeMobileDriver(int retryCount) {
		WebDriver driver = null;
		ChromeOptions options = new ChromeOptions();
		options.addArguments("user-data-dir=C:/Users/uz0s/AppData/Local/Google/Chrome/User Data");
		options.addArguments("--user-agent=Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19");
		for (int i = 0; i < retryCount; i++) {
			try {
				driver = getChromeDriver(options);
			} catch (WebDriverException e) {
				System.out.println("Unable to open Chrome on attempt " + (i + 1) + ".  Consider lowering the number of tests running in parallel.  The system may be resourced starved.");
			}
			if (driver != null) {
				return driver;
			}
		}
		System.out.println("Could not open Chrome after " + retryCount + " attempts.");
		return driver;
	}

	/**
	 * Used for Remote WebDrivers like for Selenium Grid. NOTE: Chrome is currently in an eval status. retryCount = how many times to try to get a
	 * driver instance before failing gridServer = URL String of the Grid Server for the Remote Driver
	 * 
	 * @throws MalformedURLException
	 */
	public static WebDriver getChromeRemoteDriver(int retryCount, String gridServer) throws MalformedURLException {
		WebDriver driver = null;
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		for (int i = 0; i < retryCount; i++) {
			try {
				driver = new RemoteWebDriver(new URL(gridServer), capabilities);
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			} catch (WebDriverException e) {
				System.out.println("Unable to open Chrome on attempt " + (i + 1) + ".  Consider lowering the number of tests running in parallel.  The system may be resourced starved.");
			}
			if (driver != null) {
				return driver;
			}
		}
		System.out.println("Could not open Chrome after " + retryCount + " attempts.");
		return driver;
	}

	/*
	 * NOTE: The [--disable-extensions] option is MANDATORY for Chrome with the Vanguard setup. Without this line, you will get a popup for [Loading
	 * of unpacked extensions is disabled by the administrator.] See Haydle question for more details: https://vanguard.haydle.com/questions/2300
	 */
	public static WebDriver getChromeDriver() {
		if (StringUtils.isNullOrEmpty(System.getProperty("webdriver.chrome.driver"))) {
			System.setProperty("webdriver.chrome.driver", LOCAL_CHROME_DRIVER_DEFAULT_LOCATION);
		}
		WebDriver driver;
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
	}

	public static WebDriver getChromeDriver(ChromeOptions options) {
		if (StringUtils.isNullOrEmpty(System.getProperty("webdriver.chrome.driver"))) {
			System.setProperty("webdriver.chrome.driver", LOCAL_CHROME_DRIVER_DEFAULT_LOCATION);
		}
		WebDriver driver;
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
	}

	public static boolean isWindoze() {
		// TODO: Move to another utility at some point.
		return System.getProperty(OS_NAME).toLowerCase().indexOf(WINDOWS) == 0;
	}

}
