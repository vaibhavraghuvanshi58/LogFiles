/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/FirefoxDriverWithFastHomepage.java $
 $LastChangedRevision: 5700 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-13 10:15:22 -0400 (Thu, 13 Jul 2017) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;


public class FirefoxDriverWithFastHomepage {

	private static final String HOMEPAGE_LOCK_PREFERENCE = "lockPref(\"browser.startup.homepage\", \"http://www.vanguard.com/\");";
	private static String CONFIG_PATH = "C:\\Program Files\\Mozilla Firefox\\mozilla.cfg";
	//private static String CONFIG_PATH = "C:\\Program Files (x86)\\Mozilla Firefox\\mozilla.cfg";
	static File CONFIG_FILE = new File(CONFIG_PATH);

	private static LineRemover lineRemover = new LineRemover();
	private static FileBackup fileBackup = new FileBackup();

	static FirefoxDriver getFirefoxDriverWithFasterHomepage() {
		if (CONFIG_FILE.exists()) {
			backup(CONFIG_FILE);

			FirefoxDriver firefoxDriver = new FirefoxDriver(FirefoxDriverWithFastHomepage.getProfileWithFasterHomepage());

			restoreConfigFile();

			return firefoxDriver;
		}

		return new FirefoxDriver();
	}

	private static void restoreConfigFile() {
		try {
			fileBackup.restore();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void backup(File configFile) {
		try {
			fileBackup.backup(configFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	static FirefoxProfile getProfileWithFasterHomepage() {
		FirefoxProfile profile = new FirefoxProfile();

		lineRemover.removeLineFromFile(CONFIG_PATH, HOMEPAGE_LOCK_PREFERENCE);
		profile.setPreference("startup.homepage", "about:blank");

		return profile;
	}

}
