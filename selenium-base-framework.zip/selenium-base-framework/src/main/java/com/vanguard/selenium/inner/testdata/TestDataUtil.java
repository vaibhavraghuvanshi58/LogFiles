/*
 ****************************************************************************
 * 
 * Copyright (c)2012 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/testdata/TestDataUtil.java $
 $LastChangedRevision: 676 $
 $Author: ucud $
 $LastChangedDate: 2014-09-03 09:54:57 -0400 (Wed, 03 Sep 2014) $
*/
package com.vanguard.selenium.inner.testdata;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

/**
 * @author ubmq
 *
 */
public class TestDataUtil {
    
    static final String USER_ID = "userID";

    public static String getTestDataValue(TestCase testCase,  String testName, String testDataAttributeName) {
        String testDataValue = null;
        TestData testData = getTestData(testCase, testName);
        if (testData != null) {
            testDataValue = getAttributeFromTestData(testData, testDataAttributeName);
        }
        
        if (testDataValue == null) {
            testDataValue = getAttributeFromTestCase(testCase, testDataAttributeName);
        }
        return testDataValue;
    }

    private static String getAttributeFromTestCase(TestCase testCase, String testCaseAttributeName) {
        String testDataValue = null;
        if (USER_ID.equalsIgnoreCase(testCaseAttributeName)) {
            testDataValue = testCase.getUserID();
        } else {
            testDataValue = getAttributeValue(testCase.getOtherAttributes(), testCaseAttributeName);
        }
        return testDataValue;
    }
    
    private static String getAttributeFromTestData(TestData testData, String testDataAttributeName) {
        String testDataValue = null;

        testDataValue = getAttributeValue(testData.getOtherAttributes(), testDataAttributeName);
        
        return testDataValue;
    }

    static String getAttributeValue(Map<QName, String> attributes, String attributeName) {
        
        String atttibuteValue = null;
        
        Set<QName> keys = attributes.keySet();
    
        for (QName key : keys){
            if (key.getLocalPart().equalsIgnoreCase(attributeName)){
    
                atttibuteValue = attributes.get(key);                       
            }                  
        }
        return atttibuteValue;
    }
    
    public static TestData getTestData(TestCase testCase, String testName) {
        
        if (testCase != null) {
            List<TestData> testDataList = testCase.getTestData();
            for (TestData testData : testDataList) {
                if (testData.getName().equalsIgnoreCase(testName)) {
                    return testData;
                }
            }
        }
        return null;
    }
}
