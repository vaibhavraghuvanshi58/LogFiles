package com.vanguard.selenium.inner.testdata;

import org.openqa.selenium.WebDriver;


public class TestDataRequest {
	private String testSuitePropertiesFilePath = "JavaSource/com/vanguard/retail/web/viamerge/test/resources/testSuiteProperties.properties";
	private String testCaseClientDataFilepath = "JavaSource/com/vanguard/retail/web/viamerge/test/resources/defaultTestCaseClientData.csv";
	private String localInternalUserDataFilepath = "JavaSource/com/vanguard/retail/web/viamerge/test/resources/defaultLocalInternalUserData.csv";
    private String xmlDataFilepath = "selenium-test-data.xml";
    private String testCaseName = "";
	private WebDriver webDriver;
	
	/**
     * @return the xmlDataFilepath
     */
    public String getXmlDataFilepath() {
        return xmlDataFilepath;
    }

    /**
     * @param xmlDataFilepath the xmlDataFilepath to set
     */
    public void setXmlDataFilepath(String xmlDataFilepath) {
        this.xmlDataFilepath = xmlDataFilepath;
    }

    /**
	 * Filepath for the csv file containing clients to run against the testcase.
	 * 
	 * @return
	 */
	public String getTestCaseClientDataFilepath() {
		return testCaseClientDataFilepath;
	}
	
	/**
	 * Filepath for the csv file containing clients to run against the testcase.
	 * Note: The entire test case will be run for each client defined in this file.
	 * 
	 * @return
	 */
	public void setTestCaseClientDataFilepath(String clientDataFilepath) {
		this.testCaseClientDataFilepath = clientDataFilepath;
	}
	
	/**
	 * Filepath for internal user login.  These settings are only used when testing locally or against a CI machine.
	 * Note: The entire client suite defined in the ClientDataFilepath will be run for each user included in this file
	 * 
	 * @return
	 */
	public String getLocalInternalUserDataFilepath() {
		return localInternalUserDataFilepath;
	}
	
	public void setLocalInternalUserDataFilepath(String internalUserDataFilepath) {
		this.localInternalUserDataFilepath = internalUserDataFilepath;
	}
	
	public WebDriver getWebDriver() {
		return webDriver;
	}
	
	public void setWebDriver(WebDriver webDriver) {
		this.webDriver = webDriver;
	}
	
	/** 
	 * Filepath for the default settings of the entire test suite which includes:
	 * Run against Local Machine or RTE
	 * Region to test (Local will run against whatever server is started)
	 * Release to test (Local will run against the current workspace)
	 * URLs for local host, environet, etc.
	 * 
	 * @return
	 */
	public String getTestSuitePropertiesFilePath() {
		return testSuitePropertiesFilePath;
	}

    /**
     * @return the testCaseName
     */
    public String getTestCaseName() {
        return testCaseName;
    }

    /**
     * @param testCaseName the testCaseName to set
     */
    public void setTestCaseName(String testCaseName) {
        this.testCaseName = testCaseName;
    }
	

}
