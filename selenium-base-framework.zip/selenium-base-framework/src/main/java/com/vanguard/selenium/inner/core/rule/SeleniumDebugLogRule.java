/*
 ****************************************************************************
 * 
 * Copyright (c)2014 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/rule/SeleniumDebugLogRule.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
*/
package com.vanguard.selenium.inner.core.rule;

import java.util.Calendar;

import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

public class SeleniumDebugLogRule extends TestWatcher {
	private long startTimeInMillis;	
    
    protected void starting(Description description) {
    	this.startTimeInMillis = Calendar.getInstance().getTimeInMillis();
        LoggingUtility.logInfo("Starting " + description.getMethodName());        
    }
    
    protected void failed(Throwable e, Description description) {
        LoggingUtility.logInfo("Failed " + description.getMethodName());        
    }
    
    protected void finished(Description description) {
    	long testRunTime = Calendar.getInstance().getTimeInMillis() - startTimeInMillis;
        LoggingUtility.logInfo("Finished " + description.getMethodName() + ". Test took " + testRunTime + " ms.");        
    }
    
    protected void succeeded(Description description) {
        LoggingUtility.logInfo("Succeeded " + description.getMethodName());        
    }
}
