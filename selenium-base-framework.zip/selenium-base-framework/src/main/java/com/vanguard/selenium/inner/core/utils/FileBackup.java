/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/FileBackup.java $
 $LastChangedRevision: 1130 $
 $Author: ubhj $
 $LastChangedDate: 2015-02-10 17:39:18 -0500 (Tue, 10 Feb 2015) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


public class FileBackup {

	String backupString;
	File backupFile;

	public void backup(File file) throws IOException {
		backupString = FileUtils.readFileToString(file);
		backupFile = file;
	}

	public void restore() throws IOException {
		FileUtils.write(backupFile, backupString);
	}
}
