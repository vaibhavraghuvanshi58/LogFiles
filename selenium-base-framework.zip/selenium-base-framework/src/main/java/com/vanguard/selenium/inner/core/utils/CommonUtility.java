/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/CommonUtility.java $
 $LastChangedRevision: 1143 $
 $Author: uz0s $
 $LastChangedDate: 2015-02-19 17:51:37 -0500 (Thu, 19 Feb 2015) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class CommonUtility {

    static final String XPATH_SUFFIX = "')]";
    static final String XPATH_CONTAINS = "//*[contains(.,'";
    static final String INNER_HTML_JS = "return arguments[0].innerHTML";
    static final String GET_ELEMENT_BY_ID_TEXT = "return document.getElementById('";

    public static String getSessionInfoFromCookie(WebDriver driver) {
        final String cookie = (String) ((JavascriptExecutor) driver).executeScript("return document.cookie;");

        return cookie;
    }

    public static void logConfirm(String testCaseName, String confirmNumber) {
        LoggingUtility.logInfo("Completed " + testCaseName + " with confirmation number " + confirmNumber);
    }

    @Deprecated
    public static boolean isRunningOnWindows() {
        return System.getProperty("os.name").contains("Windows");
    }
    @Deprecated
    public static boolean isRunningOnWindowsXP() {
        final String osName = System.getProperty("os.name");
        return osName.contains("Windows") && osName.contains("XP");
    }

	public static int getRandomNumber(int minInclusive, int maxInclusive) {
		Random rand = new Random();
		int randMin = minInclusive;
		int randMax = maxInclusive;
		if(randMin > randMax){
			LoggingUtility.logWarning("You swapped the min and max inputs for getting your random number.  We'll swap them for you and give you a random number between them anyway.");
			int temp = randMax;
			randMax = randMin;
			randMin = temp;
		}
		int randomNumber = rand.nextInt((randMax - randMin) + 1) + randMin;
		return randomNumber;
	}
}
