package com.vanguard.selenium.logCapture;


public class SessionCookieTO {
	private boolean externalFlag;
	private String sessionId;
	
	public boolean isExternalFlag() {
		return externalFlag;
	}
	public void setExternalFlag(boolean externalFlag) {
		this.externalFlag = externalFlag;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}



}
