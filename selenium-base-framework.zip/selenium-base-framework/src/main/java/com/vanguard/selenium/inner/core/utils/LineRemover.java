/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/LineRemover.java $
 $LastChangedRevision: 1130 $
 $Author: ubhj $
 $LastChangedDate: 2015-02-10 17:39:18 -0500 (Tue, 10 Feb 2015) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.commons.io.LineIterator;

public class LineRemover {

	public void removeLineFromFile(String file, String lineToRemove) {
		File inFile = null;
		try {
			inFile = new File(file);

			if (!inFile.isFile()) {
				// Fail silently. This is not a hard stop.
				return;
			}

			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");

			BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
			PrintWriter printWriter = new PrintWriter(new FileWriter(tempFile));

			LineIterator lineIterator = new LineIterator(bufferedReader);

			while (lineIterator.hasNext()) {
				String line = lineIterator.next();
				if (!line.trim().equals(lineToRemove)) {
					printWriter.println(line);
				}
			}

			printWriter.flush();
			printWriter.close();
			bufferedReader.close();

			if (!inFile.delete()) {
				// Fail silently. This is not a hard stop.
				return;
			}

			if (!tempFile.renameTo(inFile)) {
				// Fail silently. This is not a hard stop.
				return;
			}
		} catch (FileNotFoundException ex) {
			// Fail silently. This is not a hard stop.
		} catch (IOException ex) {
			// Fail silently. This is not a hard stop.
		}
	}
}
