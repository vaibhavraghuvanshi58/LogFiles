package com.vanguard.selenium.logCapture;


import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

public class SessionCookieService {
	private WebDriver driver;
	private SessionCookieTO sessionCookieTO;

	public SessionCookieService(WebDriver driver) {
		this.driver = driver;
	}
	
	public SessionCookieTO retrieveSessionCookieTO() {
		populateSessionCookieTO();
		return sessionCookieTO;
	}
	
	private void populateSessionCookieTO() {
		sessionCookieTO = new SessionCookieTO();	
		sessionCookieTO.setExternalFlag( isExternal() );
		sessionCookieTO.setSessionId( getSessionCookieValue() );
	}	
	
	private boolean isExternal() {
		return StringUtils.isNotEmpty(getExternalSessionCookieValue());
	}	
	
	private String getSessionCookieValue() {
		String returnValue = "";
		if( sessionCookieTO.isExternalFlag() ) {
			returnValue = getExternalSessionCookieValue();
		}else {
			returnValue = getInternalCookieValue();
		}
		return returnValue;
	}

	private String getInternalCookieValue() {
		return getCookieValue("oed_IsessionID");
	}

	private String getExternalSessionCookieValue() {
		return getCookieValue("JSESSIONID");
	}

	private String getCookieValue(String cookieName) {
		String cookieValue = null;
		Cookie cookie = getCookie(cookieName);
		if( cookie != null ) {
			cookieValue = cookie.getValue();
			cookieValue = StringUtils.trim(cookieValue);
		}
		return cookieValue;
	}

	private Cookie getCookie(String cookieName) {
		Cookie cookie = null;
		if( driver != null ) {
			cookie = driver.manage().getCookieNamed(cookieName);
		}
		return cookie;
	}
}
