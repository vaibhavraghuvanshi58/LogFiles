/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/HttpClientAuthenticator.java $
 $LastChangedRevision: 682 $
 $Author: uz0s $
 $LastChangedDate: 2014-09-04 12:24:48 -0400 (Thu, 04 Sep 2014) $
*/
package com.vanguard.selenium.inner.base;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.auth.AuthSchemeProvider;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CookieStore;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.impl.auth.KerberosSchemeFactory;
import org.apache.http.impl.auth.NTLMSchemeFactory;
import org.apache.http.impl.auth.SPNegoSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.Cookie;

/**
 * @author utcl
 *
 */
public class HttpClientAuthenticator {
    
    List<Cookie> translateClientCookiesIntoSeleniumCookies(CookieStore cookieStore) {

        List<org.apache.http.cookie.Cookie> cookies = cookieStore.getCookies();
        
        List<Cookie> seleniumCookies = null;

        if (cookies != null && !cookies.isEmpty()) {

            seleniumCookies = new ArrayList<org.openqa.selenium.Cookie>();
            
            for (org.apache.http.cookie.Cookie cookie : cookies) {
                seleniumCookies.add(new org.openqa.selenium.Cookie(cookie.getName(), cookie.getValue(), cookie.getDomain(), cookie.getPath(),
                        cookie.getExpiryDate(), cookie.isSecure()));

            }
        }
        return seleniumCookies;
    }

    void setupClientBuilderWithAuthSchemes(HttpClientBuilder aClientBuilder) {
     
        Registry<AuthSchemeProvider> authSchemeRegistry = RegistryBuilder.<AuthSchemeProvider>create()
        .register(AuthSchemes.NTLM, new NTLMSchemeFactory())
        .register(AuthSchemes.SPNEGO, new SPNegoSchemeFactory())
        .register(AuthSchemes.KERBEROS, new KerberosSchemeFactory())
        .build();

        aClientBuilder.setDefaultAuthSchemeRegistry(authSchemeRegistry);

    }

    void addNtCredentialsToClientBuilder(String localUserName, String localPassword, HttpClientBuilder aClientBuilder) throws UnknownHostException {
        java.net.InetAddress localMachine = InetAddress.getLocalHost();
        String workstation = localMachine.getHostName();
        
        CredentialsProvider credsProvider = new BasicCredentialsProvider();     
        NTCredentials ntlmCredentials = new NTCredentials(localUserName, localPassword, workstation, "vanguard"); 
        credsProvider.setCredentials(AuthScope.ANY, ntlmCredentials);
        
        aClientBuilder.setDefaultCredentialsProvider(credsProvider);
       
    }

}
