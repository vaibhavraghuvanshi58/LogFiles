/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/LoggingUtility.java $
 $LastChangedRevision: 586 $
 $Author: uz0s $
 $LastChangedDate: 2014-07-09 10:48:03 -0400 (Wed, 09 Jul 2014) $
*/
package com.vanguard.selenium.inner.core.utils;


import java.util.logging.Level;
import java.util.logging.Logger;


public class LoggingUtility {

private static Logger logger = Logger.getLogger(LoggingUtility.class.getName());
    
    public static void logError(String message, Throwable t){
    	logger.log(Level.SEVERE, message, t);
    }
    
    public static void logError(String message){
    	logger.severe(message);
    }
    
    public static void logWarning(String message, Throwable t){
        logger.log(Level.WARNING, message, t);
    }
    
    public static void logWarning(String message){
        logger.warning(message);
    }
    
    public static void logInfo(String message, Throwable t){
        logger.log(Level.INFO, message, t);
    }
    
    public static void logInfo(String message){
        logger.info(message);
    }
    
    public static void logDebug(String message, Throwable t){
        logger.log(Level.FINE, message, t);
    }
    
    public static void logDebug(String message){
    	logger.fine(message);
    }
}
