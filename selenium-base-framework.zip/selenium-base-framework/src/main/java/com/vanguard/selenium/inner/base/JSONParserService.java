/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/JSONParserService.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author uc4b
 *
 */
public class JSONParserService {
    
    public static final String STATUS = "Status";
    public static final String MESSAGE = "Message";

    
    protected JSONObject getJSONObjectFromString(String string) {
        try {
            return new JSONObject(string);
        } catch (JSONException e) {
            LoggingUtility.logError("ERROR converting to JSON Object from string: " + string);
            e.printStackTrace();
        }
        return new JSONObject();
    }
    protected JSONArray getJSONArrayFromJSONObject(JSONObject obj, String key){
        try {
            return obj.getJSONArray(key);
        } catch (JSONException e) {
            LoggingUtility.logError("ERROR retrieving JSON ARRAY from key [" + key + "] from JSON Object: " + obj);
            e.printStackTrace();
        }
        return new JSONArray();
    }
    protected String getStringFromJSONObject(JSONObject obj, String key){
        try {
            return obj.getString(key);
        } catch (JSONException e) {
            LoggingUtility.logError("ERROR retrieving key [" + key + "] from JSON Object: " + obj);
            e.printStackTrace();
        }
        return "";
    }
    protected JSONObject getJSONObjectFromJSONArray(JSONArray array, int index){
        try {
            return array.getJSONObject(index);
        } catch (JSONException e) {
            LoggingUtility.logError("ERROR retrieving object of index [" + index + "] from JSON Array: " + array);
            e.printStackTrace();
        }
        return new JSONObject();
    }
}
