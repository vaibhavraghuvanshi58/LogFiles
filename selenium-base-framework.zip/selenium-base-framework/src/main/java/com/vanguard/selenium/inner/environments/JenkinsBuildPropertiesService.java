/*
 ****************************************************************************
 *
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/environments/JenkinsBuildPropertiesService.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
*/
package com.vanguard.selenium.inner.environments;

import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.StringUtils;

public class JenkinsBuildPropertiesService {

	public static BuildProperties getBuildProperties() {
		String projectName = System.getenv("JOB_NAME");
		String buildNumber = System.getenv("BUILD_NUMBER");
		String sourceControlRevisionNum = System.getenv("SVN_REVISION");
		String entireBuildTag = System.getenv("BUILD_TAG");
		return new BuildProperties(projectName, buildNumber, sourceControlRevisionNum, entireBuildTag);
	}
	
    public static void addJenkinsInfoToEnvironmentConfig(EnvironmentConfiguration environmentConfig) {
    	String currentLabel = environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL);
    	String currentTags = environmentConfig.getSpecificCapabilityValue(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
    	BuildProperties buildProperties = getBuildProperties();
    	
    	String labelFromProperties = PropertiesManager.getProperty(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL);
    	if(StringUtils.isNullOrEmpty(currentLabel)) {
    		if(StringUtils.isNullOrEmpty(labelFromProperties)) {
	    		if(!StringUtils.isNullOrEmpty(buildProperties.getProjectName())) {
	    			environmentConfig.addCapability(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, buildProperties.getProjectName());
	    		} else {
	    			LoggingUtility.logWarning("Could not determine project name.  Not sending that info to SauceLabs.");
	    		}
    		} else {
    			environmentConfig.addCapability(EnvironmentConfiguration.SAUCELABS_BUILD_LABEL, labelFromProperties);
    		}
    	}
		String tags = "";
		if(!StringUtils.isNullOrEmpty(currentTags)){
			tags += currentTags;
		}
		String tagsFromProperties = PropertiesManager.getProperty(EnvironmentConfiguration.SAUCELABS_TAG_LABELS);
		if(!StringUtils.isNullOrEmpty(tagsFromProperties)) {
			if(tags != "") {
				tags += ",";
			}
			tags += tagsFromProperties;
		}
		if(!StringUtils.isNullOrEmpty(buildProperties.getBuildNumber()) && !StringUtils.isNullOrEmpty(buildProperties.getSourceControlRevisionNum()) && 
				!StringUtils.isNullOrEmpty(buildProperties.getEntireBuildTag())) {
			if(tags != "") {
				tags += ",";
			}
			tags += "jenkinsBuildNumber=" + buildProperties.getBuildNumber() + ",svnRevision=" + buildProperties.getSourceControlRevisionNum() + ",fullJenkinsID=" + buildProperties.getEntireBuildTag();
		} else {
			LoggingUtility.logWarning("Could not determine buildNum or svnRevision or buildTag.  Not sending that info to SauceLabs.");
		}
		if(tags != "") {
			environmentConfig.addCapability(EnvironmentConfiguration.SAUCELABS_TAG_LABELS, tags);
		}
	}

}
