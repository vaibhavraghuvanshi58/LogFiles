/*
 ****************************************************************************
 *
 * Copyright (c)2015 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/logCapture/LogCaptureService.java $
 $LastChangedRevision: 3357 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-15 11:38:37 -0400 (Wed, 15 Jun 2016) $
*/
package com.vanguard.selenium.logCapture;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.vanguard.selenium.inner.base.PropertiesManager;
import com.vanguard.selenium.inner.core.utils.LoggingUtility;

public class LogCaptureService {
	private LogViewPage logViewPage;
	private WebDriver driver;
	private SessionCookieTO sessionCookieTO;

	public LogCaptureService(WebDriver driver) {
		this.driver = driver;
	}

	public void captureLog() {
		if( driver != null && PropertiesManager.isDefaultSetToRunInRegion() ) {
			sessionCookieTO = getSessionCookieTO();
			logViewPage = new LogViewPage(driver, sessionCookieTO.getSessionId(), sessionCookieTO.isExternalFlag());		
			logViewPage.navigateTo();
			logLogViewSessionMessages();	
		}
	}

	protected SessionCookieTO getSessionCookieTO() {
		SessionCookieService sessionCookieService = new SessionCookieService(driver);
		SessionCookieTO sessionCookieTO = sessionCookieService.retrieveSessionCookieTO();
		return sessionCookieTO;
	}

	protected void logLogViewSessionMessages() {
		List<WebElement> logMessageWebElements = logViewPage.getLogMessageWebElements();
		StringBuilder stringBuilder = new StringBuilder();
		for (WebElement logMessageWebElement : logMessageWebElements) {
			stringBuilder.append("\n");
			stringBuilder.append(logMessageWebElement.getText());
		}
		LoggingUtility.logInfo("Log View Logs - Session ID: " + sessionCookieTO.getSessionId() + " Log View Url: " + logViewPage.getPageUrl());		
		LoggingUtility.logInfo("Log View Logs: " + stringBuilder.toString());
	}
}
