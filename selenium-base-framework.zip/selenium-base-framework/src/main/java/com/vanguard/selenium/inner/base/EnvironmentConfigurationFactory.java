/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/EnvironmentConfigurationFactory.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
 */
package com.vanguard.selenium.inner.base;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.environments.AndroidConfiguration;
import com.vanguard.selenium.inner.environments.BrowserType;
import com.vanguard.selenium.inner.environments.ChromeConfiguration;
import com.vanguard.selenium.inner.environments.EdgeConfiguration;
import com.vanguard.selenium.inner.environments.EnvironmentConfiguration;
import com.vanguard.selenium.inner.environments.FirefoxConfiguration;
import com.vanguard.selenium.inner.environments.InternetExplorerConfiguration;
import com.vanguard.selenium.inner.environments.OperaConfiguration;
import com.vanguard.selenium.inner.environments.SafariConfiguration;
import com.vanguard.selenium.inner.environments.IPadConfiguration;
import com.vanguard.selenium.inner.environments.IPhoneConfiguration;

public class EnvironmentConfigurationFactory {


    public static EnvironmentConfiguration getEnvironment(BrowserType browserType) {
        EnvironmentConfiguration environmentConfiguration = null;
        if(browserType!= null){
            switch (browserType) {
            case FIREFOX:
                environmentConfiguration = new FirefoxConfiguration();
                break;
            case CHROME:
                environmentConfiguration = new ChromeConfiguration();
                break;
            case INTERNET_EXPLORER:
                environmentConfiguration = new InternetExplorerConfiguration();
                break;
            case EDGE:
                environmentConfiguration = new EdgeConfiguration();
                break;
            case SAFARI:
                environmentConfiguration = new SafariConfiguration();
                break;
            case OPERA:
                environmentConfiguration = new OperaConfiguration();
                break;
            case IPHONE:
                environmentConfiguration = new IPhoneConfiguration();
                break;
            case IPAD:
                environmentConfiguration = new IPadConfiguration();
                break;
            case ANDROID:
                environmentConfiguration = new AndroidConfiguration();
                break;
            default:
                LoggingUtility.logError("Invalid value for 'BrowserType'.  Value [" + browserType + "] is not currently supported.  We're going to run the test with Firefox.");
                environmentConfiguration = new FirefoxConfiguration();
                break;
            }
        } else {
            //If not running on SauceLabs (or browserType=null), we're always using Firefox.
            environmentConfiguration = new FirefoxConfiguration();
        }
        return environmentConfiguration;
    }
    
}