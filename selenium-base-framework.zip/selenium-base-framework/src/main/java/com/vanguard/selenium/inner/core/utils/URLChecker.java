/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/core/utils/URLChecker.java $
 $LastChangedRevision: 3339 $
 $Author: uz0s $
 $LastChangedDate: 2016-06-09 16:28:46 -0400 (Thu, 09 Jun 2016) $
 */
package com.vanguard.selenium.inner.core.utils;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.IOUtils;

import com.vanguard.selenium.inner.core.rule.RetryRule;
import com.vanguard.utils.email.EmailUtils;

/**
 * URL monitoring utility.  Can be optionally configured to send emails on failure.
 * Emails lists need to be separated by semicolons: uxxx@vanguard.com;uxxx@vanguard.com
 */
public class URLChecker {

	private String testName = "";
	private String urlToCheck = "";
	private String assertion = "";
	private String response = "";
	private String emailList = "";
	private String message = "";
	private Boolean connectionError = false;
	private Boolean assertionError = false;
	private Boolean timeoutError = false;
	private RetryRule rule;
	private Integer timeout = 5000;
	private Boolean sendEmailOnFailure = false;

	/**
	 * Use this constructor for a simple URL check.
	 */
	public URLChecker(String urlToCheck,String assertion) {
		this.urlToCheck = urlToCheck;
		this.assertion = assertion;
	}

	/**
	 * Use this constructor if you want to send an email if the URL check fails.
	 */
	public URLChecker(String testName, String urlToCheck,
			String assertion, String emailList, String message, RetryRule rule, boolean sendEmailOnFailure) {
		this.testName = testName;
		this.urlToCheck = urlToCheck;
		this.assertion = assertion;
		this.emailList = emailList;
		this.message = message;
		this.rule = rule;
		this.sendEmailOnFailure = sendEmailOnFailure;
	}

	public boolean checkURL(){
		connect();
		return responseContains(assertion);
	}

	protected String connect() {
		HttpClient client = new HttpClient();
		GetMethod method = new GetMethod(urlToCheck);
		method.getParams().setIntParameter("http.socket.timeout", timeout);
		int statusCode;
		try {
			statusCode = client.executeMethod(method);
			if (statusCode != HttpStatus.SC_OK) {
				sendEmail();
			}
			setResponse(IOUtils.toString(method.getResponseBodyAsStream()));
		} catch (HttpException e) {
			setConnectionError(true);
			e.printStackTrace();
		} catch (IOException e) {
			if(e.toString().contains("java.net.SocketTimeoutException")){
				setTimeoutError(true);
			}
			setConnectionError(true);
			e.printStackTrace();
		} catch (IllegalArgumentException e){
			setConnectionError(true);
			e.printStackTrace();
		} finally {
			method.releaseConnection();
		}
		return getResponse();

	}

	protected boolean responseContains(String assertion) {
		if (getResponse() != null && getResponse().contains(assertion)) {
			return true;
		} else {
			setAssertionError(true);
			sendEmail();
			return false;
		}
	}

	public boolean hasErrors(){
		if(getTimeoutError() == true | getConnectionError() == true | getAssertionError() == true){
			return true;
		} else {
			return false;
		}
	}

	protected void sendEmail() {
		if (getSendEmailOnFailure() == true && rule.getMaxRetries().equals(rule.getRetryCount())) { // only send an email after the retries are done
			String [] emailAddresses = emailList.split(";");
			String newLine = "\r\n";
			String subject = generateSubject();
			String body = "This is an automatically generated email.  Please do not reply. " + newLine + newLine + generateCauseOfError() + newLine + newLine + getMessage();
			for (String toEmail : emailAddresses) {
				EmailUtils.sendEmail(toEmail, subject, body);
			}

		}
	}

	protected String generateSubject(){
		String subject = null;
		if (getConnectionError() == false && getAssertionError() == true){
			subject = "Assertion failure for " + getTestName();
		} else if (getTimeoutError() == true){
			subject = "Timeout error for " + getTestName();
		} else {
			subject = "Connection failure for " + getTestName();
		}
		return subject;
	}

	protected String generateCauseOfError(){
		if (getConnectionError() == false && getAssertionError() == true){
			return "Assertion failed for test " + getTestName() + ".  The response did not contain \"" + getAssertion() + "\".";
		} else if (getTimeoutError() == true) {
			return"Test " + getTestName() + " timed out while attempting to connect to " + getUrlToCheck() + " within " + getTimeout() + " milliseconds.";
		} else {
			return "Test " + getTestName() + " failed.  Unable to connect to: " + getUrlToCheck();
		}
	}


	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getUrlToCheck() {
		return urlToCheck;
	}

	public void setUrlToCheck(String urlToCheck) {
		this.urlToCheck = urlToCheck;
	}

	public String getAssertion() {
		return assertion;
	}

	public void setAssertion(String assertion) {
		this.assertion = assertion;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getEmailList() {
		return emailList;
	}

	public void setEmailList(String emailList) {
		this.emailList = emailList;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Boolean getConnectionError() {
		return connectionError;
	}

	public void setConnectionError(Boolean connectionError) {
		this.connectionError = connectionError;
	}

	public Boolean getAssertionError() {
		return assertionError;
	}

	public void setAssertionError(Boolean assertionError) {
		this.assertionError = assertionError;
	}

	public Boolean getSendEmailOnFailure() {
		return sendEmailOnFailure;
	}

	public void setSendEmailOnFailure(Boolean sendEmailOnFailure) {
		this.sendEmailOnFailure = sendEmailOnFailure;
	}

	public RetryRule getRule() {
		return rule;
	}

	public void setRule(RetryRule rule) {
		this.rule = rule;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	public Boolean getTimeoutError() {
		return timeoutError;
	}

	public void setTimeoutError(Boolean timeoutError) {
		this.timeoutError = timeoutError;
	}

}
