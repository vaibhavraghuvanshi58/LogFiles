package com.vanguard.selenium.inner.base;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vanguard.selenium.inner.environments.BrowserType;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface EnvironmentConfigAnnotation {
    
	String tags() default "";
	BrowserType browserType() default BrowserType.FIREFOX;
	String browserVersion() default "";
	String osType() default "";
	String osVersion() default "";
	String chromeDriverVersion() default "";
	String ieDriverVersion() default "";
    String deviceName() default "";
    String deviceOrientation() default "";
    String platformVersion() default "";
    String idleTimeout() default "";
    String screenResolution() default "";
}