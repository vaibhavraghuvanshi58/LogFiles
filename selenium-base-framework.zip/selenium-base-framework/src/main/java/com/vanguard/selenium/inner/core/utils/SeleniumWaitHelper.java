package com.vanguard.selenium.inner.core.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

@Deprecated
/** This class should never be used, please wait for the specific thing you want with an 
 * Inner Source explicit wait method like: isDisplayed(locator, maxTimeToWait), 
 * isEnabled(locator, maxTimeToWait), click(locator, maxTimeToWait), etc.
 */
public class SeleniumWaitHelper {

    public static final int DEFAULT_WAIT_TIME = 30;

    private WebDriver driver;
    private int waitTime = DEFAULT_WAIT_TIME;

    public SeleniumWaitHelper(WebDriver driver) {
        this.driver = driver;
    }

    public SeleniumWaitHelper(WebDriver driver, int customWaitTime) {
        this.driver = driver;
        this.waitTime = customWaitTime;
    }

    public static void pause(double delayTimeInSeconds) {
        final int delay = (int) Math.round(delayTimeInSeconds * 1000);
        try {
            Thread.sleep(delay);
        } catch (final InterruptedException e) {        	
            LoggingUtility.logError("Error while sleeping!", e);
            Thread.currentThread().interrupt(); // restore interrupted status
        }
    }

    public void waitForAjax() {
        new WebDriverWait(driver, waitTime).until(buildExpectedConditionForAjaxWait(driver));
    }

    static ExpectedCondition<Boolean> buildExpectedConditionForAjaxWait(final WebDriver driver) {
        final ExpectedConditionBuilder expectedConditionBuilder = new ExpectedConditionBuilder();
        return expectedConditionBuilder.buildAjaxCompleteCondition(driver);
    }

    public void waitForElementToBeEnabled(final String elementId) {
        new WebDriverWait(driver, waitTime).until(buildExpectedConditionForElementDisplay(elementId, driver));
    }

    static ExpectedCondition<Boolean> buildExpectedConditionForElementDisplay(final String elementId, final WebDriver driver) {
        final ExpectedConditionBuilder expectedConditionBuilder = new ExpectedConditionBuilder();
        return expectedConditionBuilder.buildElementEnabledCondition(elementId, driver);
    }

}
