/*
 ****************************************************************************
 * 
 * Copyright (c)2013 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/SeleniumBaseTest.java $
 $LastChangedRevision: 5583 $
 $Author: uz0s $
 $LastChangedDate: 2017-05-31 13:01:21 -0400 (Wed, 31 May 2017) $
 */
package com.vanguard.selenium.inner.base;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

import com.vanguard.selenium.inner.testdata.TestCase;

/**
 * @author un3k
 * 
 */
@Deprecated
/** Use VanguardBaseTest in selenium-inner-core **/
public abstract class SeleniumBaseTest extends ParameterizedBaseTest {
    public SeleniumBaseTest(TestCase testCase) {
        super(testCase);
    }

    @TestDataAttribute
    protected String channel;

    @TestDataAttribute
    protected String userID;

    @TestDataAttribute
    protected String poid;

    @TestDataAttribute
    protected String testResult;

    @TestDataAttribute
    protected String QCTestSet;

    @TestDataAttribute
    protected String QCTestName;

    @Before
    public abstract void setUp() throws Exception;

    protected boolean isValuePopulated(String value) {
        return value != null && !StringUtils.EMPTY.equalsIgnoreCase(value);
    }

    protected String getTimestamp() {
        SimpleDateFormat formatter = new SimpleDateFormat("MMM-dd-yyyy-HH-mm");
        String string = formatter.format(new Date());
        return string;
    }

    protected String getTestName(String name) {
        int index = name.indexOf("[");
        String testName = name.substring(0, index);
        String testNumber = name.substring(index + 1, index + 2);
        return testName + "-" + testNumber;
    }

    @Rule
    public TestWatcher rule = new BaseTestWatcher() {

        @Override
        public void succeeded(Description description) {
            String snapshotName = getSuccessSnapshotName();
            recordTestResult(snapshotName, description, null);
            if (driver != null) {
                driver.close();
            }
        }

        @Override
        public void failed(Throwable e, Description description) {
            String snapshotName = getFailureSnapshotName();
            recordTestResult(snapshotName, description, e);
            if (driver != null) {
                driver.quit();
            }
        }

        @SuppressWarnings("serial")
        private void recordTestResult(String snapshotName, Description description, Throwable e) {
            try {
                takeScreenShot(snapshotName, driver);
                updateSnapshotCsv(snapshotName, getTestResultsFileName(), new HashMap<String, String>() {
                    {
                        put("Test Set Name", QCTestSet);
                        put("Test Case Name", QCTestName);
                    }
                });
            } catch (IOException ioe) {
                ioe.printStackTrace();
                if (e != null) {
                    e.printStackTrace();
                }
            } catch (Exception ex) {
                System.out.println("Browser closed - cannot get screenshot.");
            }
        }
    };

    protected abstract String getFailureSnapshotName();

    protected abstract String getSuccessSnapshotName();

    protected abstract String getTestResultsFileName();
}
