/*
 ****************************************************************************
 *
 * Copyright (c)2009 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 *
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:

 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/DriverFactory.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
 */
package com.vanguard.selenium.inner.base;

import static org.junit.Assert.assertFalse;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.lang3.StringUtils;
import org.junit.rules.TestName;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;
import com.vanguard.selenium.inner.core.utils.SeleniumWaitHelper;
import com.vanguard.selenium.inner.environments.BrowserType;
import com.vanguard.selenium.inner.environments.ChromeConfiguration;
import com.vanguard.selenium.inner.environments.EnvironmentConfiguration;
import com.vanguard.selenium.inner.environments.FirefoxConfiguration;
import com.vanguard.selenium.inner.environments.NullDriverException;
import com.vanguard.selenium.inner.logon.user.TestCrewMemberInformation;

public class DriverFactory {

    public static final String IN_HOUSE_GRID_URL = "http://cvlna045.vanguard.com:4444/wd/hub";
    private static final String trustedServers = "vgidev01.vanguard.com,vgidev02.vanguard.com,vgisat01.vanguard.com,vgisat02.vanguard.com,vgicat01.vanguard.com,vgiperf01.vanguard.com,devoedesktop.vanguard.com,iwadevn1.vanguard.com,iwaintn1.vanguard.com,iwasatn1.vanguard.com,iwacatn1.vanguard.com";
    
    //Properties file Strings
    public static final String GRID_SERVER_ULR = "gridServerUrl";
    public static final String SELENIUM_GRID_FLAG = "seleniumGrid";
	private static final String ENABLE_FIREFOX_POPUPS = "enableFirefoxPopups";
	protected static final String GECKO_DRIVER_FOLDER_PATH = "C:\\Program Files\\Mozilla Firefox\\GeckoDriver\\";
	private static final String CHROME_DRIVER_FOLDER_PATH = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\ChromeDriver\\";
    
    //TODO: Figure out a better way to optionally add TestName to all public methods.
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test **/
    public static WebDriver getFirefoxDriver() {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteDriver(EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile()));
        }
        return getFirefoxDriver(new FirefoxProfile());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test **/
    public static WebDriver getFirefoxDriver(TestName name) {
        return getDriver(name);
    }
    
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test **/
    public static WebDriver getDriver(TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteDriver(EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile()));
        }
        return getFirefoxDriver(new FirefoxProfile());
    }
    
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test 
     * This method should only be called from within VanguardBaseTest of this project.**/
    public static WebDriver getDriver(EnvironmentConfiguration environmentConfig) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteDriver(environmentConfig);
        }
        return getLocalDriver(environmentConfig);
    }

	protected static WebDriver getRemoteDriver(EnvironmentConfiguration environentConfig) {
    	DesiredCapabilities capabilities = environentConfig.getDesiredCapabilities();
    	if(isRunningOnInHouseGrid()) {
    	    //Ignore anything that may have been set for SauceLabs, since in-house grid only has firefox.
    	    capabilities = DesiredCapabilities.firefox();
    	}
        WebDriver driver = null;

        int retry;
        for (retry = 0; retry<5; retry++) {
            try {
                String url = getGridServerUrl();
                LoggingUtility.logInfo("******* Launching Browser with: " + capabilities);
                LoggingUtility.logInfo("******* Launching on Grid: " + url);
                driver = new RemoteWebDriver(new URL(url), capabilities);
                if(isRunningOnSauceLabs()){
                    logSauceLabsResultsURL((RemoteWebDriver) driver);
                }
                return driver;
            } catch (MalformedURLException e) {
                LoggingUtility.logWarning("Error occured in attempting to get Remote Web Driver.  Tried to use gridServerURL property of ["
                        + getGridServerUrl() + "].  Try #" + retry);
                e.printStackTrace();
                SeleniumWaitHelper.pause(10);//Wait 10 seconds and potentially try again.
            }
        }

        LoggingUtility.logError("Errors occured while getting a Remote Firefox Driver.  We tried [" + retry + "] times but we failed each time.  Returning null.  View stacktrace for more information on prior failures.");
        return null;
    }

    
    protected static void logSauceLabsResultsURL(RemoteWebDriver driver) {
        SessionId sessionId = null;
        sessionId = driver.getSessionId();

        if(sessionId != null)
        {
            String sessionIdString = sessionId.toString();
            LoggingUtility.logInfo("LINK TO SAUCELABS RESULTS OF THIS TEST: https://saucelabs.com/beta/tests/" + sessionIdString);
        }
    }

    
    private static WebDriver getRemoteAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo) {
        WebDriver driver = getRemoteDriver(EnvironmentConfigurationFactory.getEnvironment(BrowserType.getBrowserTypeFromPropertiesFile()));
        return new VgiAuthenticatedWebDriver(driver, associateInfo.getUserId(), associateInfo.getPassword());
    }
    
    
    private static WebDriver getLocalDriver(EnvironmentConfiguration environmentConfig) {
    	if(environmentConfig instanceof FirefoxConfiguration) {
    		return getFirefoxDriver(new FirefoxProfile());
    	}
    	if(environmentConfig instanceof ChromeConfiguration) {
    		return getChromeDriver();
    	}
    	LoggingUtility.logWarning("Invalid environmentConfig.  We only support Firefox or Chrome locally: " + environmentConfig.getDesiredCapabilities());
    	LoggingUtility.logWarning("We are ignoring the environmentConfig you have set, and defaulting back to Firefox for this local run.");
    	return getFirefoxDriver(new FirefoxProfile());
	}
    
	public static WebDriver getFirefoxDriver(FirefoxProfile profile) {
        profile.setEnableNativeEvents(true);
        profile.setPreference("network.automatic-ntlm-auth.allow-proxies", true);
        profile.setPreference("network.automatic-ntlm-auth.trusted-uris", trustedServers);
        profile.setPreference("network.negotiate-auth.trusted-uris", trustedServers);
        String enablePopupValue = PropertiesManager.getProperty(ENABLE_FIREFOX_POPUPS);
        if(enablePopupValue != null) {
        	boolean showPopup = Boolean.valueOf(enablePopupValue);
        	profile.setPreference("dom.disable_open_during_load", !showPopup);
        	profile.setPreference("browser.popups.showPopupBlocker", showPopup);
        	profile.setPreference("browser.history.allowPopState", showPopup);
        	profile.setPreference("privacy.popups.showBrowserMessage", showPopup);
        	profile.setPreference("privacy.popups.usecustom", showPopup);
        }

        disableCompatibilityCheckIfNeeded(profile);
        addFireBugExtensionIfNeeded(profile);

        DesiredCapabilities caps = DesiredCapabilities.firefox();
        caps.setCapability(FirefoxDriver.PROFILE, profile);
        
        String geckoDriverPath = GECKO_DRIVER_FOLDER_PATH + "geckodriver.exe";
        File geckoDriverFile = (new File(geckoDriverPath));

        if((geckoDriverFile!= null) && geckoDriverFile.exists()) {
        	String GECKO_DRIVER_LOCATION = geckoDriverFile.getAbsolutePath();
        	//We're on Firefox 52+, use GeckoDriver with marionette
			System.setProperty("webdriver.gecko.driver", GECKO_DRIVER_LOCATION);
	        caps.setCapability("marionette", true);
        } else {
        	//TODO: Remove this code once everyone is on FF52+ (tentative End of May 2017)
        	//We're on Firefox 46-, Selenium 3 set marionette to false so we don't use it with this old Firefox version.
        	System.setProperty("webdriver.firefox.marionette", "false");
        }
        WebDriver driver = new FirefoxDriver(caps);
        
        //This part of this method is only for local runs.
        //Set the browser size to what it is on the grid for debugging purposes
        driver.manage().window().setPosition(new Point(0,0));
        driver.manage().window().setSize(new Dimension(960,740));
        
        return driver;
    }
    private static WebDriver getChromeDriver() {
    	String chromeDriverFilePath = CHROME_DRIVER_FOLDER_PATH + "chromedriver.exe";
    	File chromeDriverFile = new File(chromeDriverFilePath);
    	if(!chromeDriverFile.exists()) {
    		throw new NullDriverException("You must have a valid chrome driver in this path [" + chromeDriverFilePath + "].  Please see \n"
    				+ "documentation on how to add this properly: http://crewhub.vanguard.com/rs/projects1/selenium/SitePages/Selenium%20Tests%20Running%20On%20Chrome%20Locally.aspx");
    	}
    	if (StringUtils.isBlank(System.getProperty("webdriver.chrome.driver"))) {
			System.setProperty("webdriver.chrome.driver", chromeDriverFilePath);
		}
		WebDriver driver;
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		driver = new ChromeDriver(options);
		
        //This part of this method is only for local runs.
        //Set the browser size to what it is on the grid for debugging purposes
        driver.manage().window().setPosition(new Point(0,0));
        driver.manage().window().setSize(new Dimension(960,740));
        
		return driver;
	}

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, boolean shouldAddPopupBlocker) {
        if (shouldAddPopupBlocker) {
            profile.setPreference("browser.popups.showPopupBlocker", false);
            profile.setPreference("privacy.popups.showBrowserMessage", false);
            return getAuthenticatedFirefoxDriver(associateInfo, profile);
        }
        return getAuthenticatedFirefoxDriver(associateInfo, profile);
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, boolean shouldAddPopupBlocker, TestName name) {
        if (shouldAddPopupBlocker) {
            profile.setPreference("browser.popups.showPopupBlocker", false);
            profile.setPreference("privacy.popups.showBrowserMessage", false);
            return getAuthenticatedFirefoxDriver(associateInfo, profile, name);
        }
        return getAuthenticatedFirefoxDriver(associateInfo, profile, name);
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo) {
        return getAuthenticatedFirefoxDriver(associateInfo, new FirefoxProfile());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, TestName name) {
        return getAuthenticatedFirefoxDriver(associateInfo, new FirefoxProfile(), name);
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, RegionProperties region) {
        return getAuthenticatedFirefoxDriver(associateInfo, new FirefoxProfile(), region);
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, RegionProperties region, TestName name) {
        return getAuthenticatedFirefoxDriver(associateInfo, new FirefoxProfile(), region, name);
    }

    //TODO: Refactor methods below - They are all doing the same thing now:
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, RegionProperties region) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(profile), associateInfo.getUserId(), associateInfo.getPassword());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, RegionProperties region, TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(profile), associateInfo.getUserId(), associateInfo.getPassword());
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(profile), associateInfo.getUserId(), associateInfo.getPassword());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(profile), associateInfo.getUserId(), associateInfo.getPassword());
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri, TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFasFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFasFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri, TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriverForSpecifiedSystem(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri, String internalServerUri) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }
    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedFirefoxDriverForSpecifiedSystem(TestCrewMemberInformation associateInfo, FirefoxProfile profile, String protectedResourceUri, 
            String internalServerUri, TestName name) {
        boolean shouldUseGridServer = Boolean.parseBoolean(PropertiesManager.getProperty(SELENIUM_GRID_FLAG));

        if (shouldUseGridServer) {
            return getRemoteAuthenticatedFirefoxDriver(associateInfo);
        }

        if (PropertiesManager.isRunningOnWindows() == false) {
            // Jenkins work around to not use custom profile
            return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
        }

        setupAuthenticatedFirefoxDriver(associateInfo, profile);

        return new VgiAuthenticatedWebDriver(new FirefoxDriver(), associateInfo.getUserId(), associateInfo.getPassword());
    }

    private static void setupAuthenticatedFirefoxDriver(TestCrewMemberInformation associateInfo, FirefoxProfile profile) {
        profile.setEnableNativeEvents(true);
        if (associateInfo == null
                || (StringUtils.isEmpty(associateInfo.getUserId()) && StringUtils.isEmpty(associateInfo.getPassword()) && StringUtils
                        .isEmpty(associateInfo.getPoid()))) {
            profile.setPreference("network.automatic-ntlm-auth.allow-proxies", true);
            profile.setPreference("network.automatic-ntlm-auth.trusted-uris", trustedServers);
            profile.setPreference("network.negotiate-auth.trusted-uris", trustedServers);
        }

        disableCompatibilityCheckIfNeeded(profile);

        addFireBugExtensionIfNeeded(profile);
    }

    /**
     *
     * This method disables FireFox's compatibility check for addons/extensions
     *
     * @param profile
     */
    private static void disableCompatibilityCheckIfNeeded(FirefoxProfile profile) {

        // TODO Probably should have this driven by properties
        // Would need a value to indicate which FireFox version -- this is currently hardcoded to 24 (see string below")
        if (PropertiesManager.isRunningOnWindows() == true) {
            profile.setPreference("extensions.checkCompatibility.24.0", false);
        }
    }

    private static void addFireBugExtensionIfNeeded(FirefoxProfile profile) {
        if (PropertiesManager.isRunningOnWindows() && shouldAddFirebug()) {
            String firebug64bitPath = "C:\\Program Files (x86)\\Mozilla Firefox\\Add-ons\\firebug-2.0.3-fx.xpi";
            String firebug32bitPath = "C:\\Program Files\\Mozilla Firefox\\Add-ons\\firebug-2.0.3-fx.xpi";
            File firebugXPI;
            try {
                firebugXPI = new File(firebug64bitPath);
                if(firebugXPI.exists()){
                    profile.addExtension(firebugXPI);
                } else {
                    firebugXPI = new File(firebug32bitPath);
                    if(firebugXPI.exists()){
                        profile.addExtension(firebugXPI);
                    }
                }
            } catch (Exception e) {
                LoggingUtility.logError("Failed to enable Firebug", e);
            }
            
            profile.setPreference("extensions.firebug.currentVersion", "2.0.3");
            profile.setPreference("extensions.firebug.console.enableSites", true);
            profile.setPreference("extensions.firebug.script.enableSites", true);
            profile.setPreference("extensions.firebug.largeCommandLine", true);
        }
    }

    private static boolean shouldAddFirebug() {
        return Boolean.TRUE.toString().equalsIgnoreCase(PropertiesManager.getProperty(PropertiesManager.FIREBUG));
    }

    @Deprecated/**Browsers other than Firefox can only be used with SauceLabs and can be retrieved via getDriver() method in this class when 
    * specifying a properties file value of: BrowserType=IE**/
    public static WebDriver getInternetExplorerDriver() {

        WebDriver driver = new InternetExplorerDriver();
        return driver;
    }

    @Deprecated
    /** As of Inner Source 3.x we automatically launch the driver for you at the beginning of every test.
     * Use authenticateForInternal() off the VanguardBaseTest to authenticate the driver that class already provides **/
    public static WebDriver getAuthenticatedInternetExplorerDriver(TestCrewMemberInformation associateInfo) {

        // Not able to add cookies in IE7/8 on windows XP
        assertFalse("Not able to add cookies in IE7/8 on windows XP", PropertiesManager.isRunningOnWindowsXP());

        WebDriver driver = new InternetExplorerDriver();

        return new VgiAuthenticatedWebDriver(driver, associateInfo.getUserId(), associateInfo.getPassword());
    }
    
    
    public static String getGridServerUrl() {
        if(PropertiesManager.getProperty(GRID_SERVER_ULR) != null){
            return PropertiesManager.getProperty(GRID_SERVER_ULR);
        } else {
            return IN_HOUSE_GRID_URL;
        }
    }
    protected static boolean isRunningOnAGrid() {
        return PropertiesManager.getProperty(SELENIUM_GRID_FLAG).equals("true");
    }
    protected static boolean isRunningOnInHouseGrid(){
        return (isRunningOnAGrid() && getGridServerUrl().equals(IN_HOUSE_GRID_URL));
    }
    public static boolean isRunningOnSauceLabs(){
        return (isRunningOnAGrid() && !isRunningOnInHouseGrid());
    }
    
}