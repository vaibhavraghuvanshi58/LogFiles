/*
 ****************************************************************************
 * 
 * Copyright (c)2017 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-test-data-framework/trunk/src/main/java/com/vanguard/selenium/inner/base/CookieService.java $
 $LastChangedRevision: 5431 $
 $Author: uc4b $
 $LastChangedDate: 2017-04-14 18:51:58 -0400 (Fri, 14 Apr 2017) $
*/
package com.vanguard.selenium.inner.base;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.InvalidCookieDomainException;
import org.openqa.selenium.WebDriver;

import com.vanguard.selenium.inner.core.utils.LoggingUtility;

/**
 * @author uc4b
 *
 */
public class CookieService {
    
    protected static final String COOKIE_PATH = "/";
    protected static final String COOKIE_DOMAIN = ".vanguard.com";
    
    protected static final String TOKEN_SET = "TokenSet";
    protected static final String TOKEN_NAME = "TokenName";
    protected static final String TOKEN_VALUE = "TokenValue";
    
    private JSONParserService jsonParserService = new JSONParserService();
    
    protected List<Cookie> getCookies(JSONObject jsonResponse) {
        
        List<Cookie> cookies = new ArrayList<Cookie>();
        JSONArray tokens = jsonParserService.getJSONArrayFromJSONObject(jsonResponse, TOKEN_SET);
        for (int cookieIndex = 0; cookieIndex < tokens.length(); cookieIndex++)
        {
            JSONObject jsonToken = jsonParserService.getJSONObjectFromJSONArray(tokens, cookieIndex);
            String tokenName = jsonParserService.getStringFromJSONObject(jsonToken, TOKEN_NAME);
            String tokenValue = jsonParserService.getStringFromJSONObject(jsonToken, TOKEN_VALUE);
            Date expire = getTomorrow();
            
            Cookie cookie = new Cookie(tokenName, tokenValue, COOKIE_DOMAIN, COOKIE_PATH, expire);
            cookies.add(cookie);
        }
        return cookies;
    }
    
    public void addAllCookiesToDriver(WebDriver driver, List<Cookie> cookies) {
        for (Cookie cookie : cookies) {
            try {
                driver.manage().addCookie(cookie);
            }catch (InvalidCookieDomainException e) {
                LoggingUtility.logInfo("INFO: Could not load cookie due to invalid domain: [" + cookie.getName() + " : " + cookie.getValue() + " ~ " + cookie.getDomain());
            }
        }
    }
    
    protected Date getTomorrow() {
        Calendar c = Calendar.getInstance(); 
        c.add(Calendar.DATE, 1);
        return c.getTime();
    }

}
