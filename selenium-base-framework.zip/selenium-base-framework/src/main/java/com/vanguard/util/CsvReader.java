/*
 ****************************************************************************
 * 
 * Copyright (c)2011 The Vanguard Group of Investment Companies (VGI)
 * All rights reserved.
 * 
 * This source code is CONFIDENTIAL and PROPRIETARY to VGI. Unauthorized
 * distribution, adaptation, or use may be subject to civil and criminal
 * penalties.
 *
 ****************************************************************************
 Module Description:
 
 $HeadURL: http://prdsvnrepo:8080/svn/shared/projects/selenium-base-framework/trunk/src/main/java/com/vanguard/util/CsvReader.java $
 $LastChangedRevision: 5713 $
 $Author: uw2h $
 $LastChangedDate: 2017-07-18 17:11:38 -0400 (Tue, 18 Jul 2017) $
 */
package com.vanguard.util;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.aspose.cells.Cell;
import com.aspose.cells.CellValueType;
import com.aspose.cells.Cells;
import com.aspose.cells.Row;
import com.aspose.cells.Rows;
import com.aspose.cells.Workbook;
import com.aspose.cells.Worksheet;
import com.aspose.cells.Worksheets;

public class CsvReader {

    private String mExcelFilePath;
    
    CsvReader(String excelFilePath) {
        mExcelFilePath = excelFilePath;
    }

    static public Collection<Object[]> getData(String excelFilePath) throws Exception {
        ArrayList<ArrayList<Object>> data = CsvReader.getAppendableData(excelFilePath);
        return convertToObjectArrays(data);
    }
    
    static public Collection<Object[]> getData(String excelFilePath, String requestedColumns[]) throws Exception {
        ArrayList<ArrayList<Object>> data = CsvReader.getAppendableData(excelFilePath, requestedColumns);
        return convertToObjectArrays(data);
    }
    
    static public ArrayList<ArrayList<Object>> getAppendableData(String excelFilePath) throws Exception {
        CsvReader reader = new CsvReader(excelFilePath);
        ArrayList<ArrayList<Object>> data = reader.getAppendableTestData();
        return data;
    }
    
    static public ArrayList<ArrayList<Object>> getAppendableData(String excelFilePath, String requestedColumns[]) throws Exception {
        CsvReader reader = new CsvReader(excelFilePath);
        ArrayList<ArrayList<Object>> data = reader.getAppendableTestData(requestedColumns);
        return data;
    }
    
    ArrayList<ArrayList<Object>> getAppendableTestData() throws Exception {
        return getDataRows(null, null);
    }

    ArrayList<ArrayList<Object>> getAppendableTestData(String[] requestedColumns) throws Exception {
        return getDataRows(requestedColumns, null);
    }

    /**
     * Convert ArrayList<ArrayList<Object>> to Collection<Object[]>, that is each element is a fixed Object array suitable for ParameterizedRunner.
     */

    static public Collection<Object[]> convertToObjectArrays(ArrayList<ArrayList<Object>> appendableData) {
        Collection<Object[]> paramRunnerData = new ArrayList<Object[]>();

        for (ArrayList<Object> row : appendableData) {
            Object newObjectArray[] = new Object[row.size()];
            for (int ii = 0; ii < row.size(); ii++) {
                newObjectArray[ii] = row.get(ii);
            }
            paramRunnerData.add(newObjectArray);
        }

        return (paramRunnerData);
    }

    /**
     * @param string
     * @return
     * @throws Exception
     */
    private Workbook getWorkbook() throws Exception {
        Workbook book = new Workbook();
        book.open(this.mExcelFilePath);
        return book;
    }

    /**
     * Read in all the data rows. If the first column of any rows start with "#", skip them. Data is returned only for the columns named in
     * requestedColumns. If that parameter is null, then all columns identified in the header row are returned. If maxColumns is null, it will return
     * all named columns from the spreadsheet, otherwise it will only return the first maxColumns named columns.
     * 
     */

    private ArrayList<ArrayList<Object>> getDataRows(String[] requestedColumns, Integer maxColumns)
            throws FileNotFoundException, Exception {

        ArrayList<ArrayList<Object>> dataRows = new ArrayList<ArrayList<Object>>();

        Workbook workbook = getWorkbook();

        Worksheets sheets = workbook.getWorksheets();
        Worksheet sheet = sheets.getSheet(0);

        // Return a List of column header elements (name and index) for the columns to be retrieved
        List<HeaderElement> colHeaders = getColumnHeaders(workbook, sheet, requestedColumns, maxColumns);

        Cells cells = sheet.getCells();
        Rows rows = cells.getRows();
        int maxRow = cells.getMaxDataRow();

        for (int rowInx = 0; rowInx <= maxRow; rowInx++) {
            Row row = rows.getRow(rowInx);

            if (isDataRow(workbook, row)) {
                ArrayList<Object> rowData = new ArrayList<Object>();
                for (HeaderElement hdr : colHeaders) {
                    Cell cell = row.getCell(hdr.columnIndex);
                    rowData.add(getCellValue(cell));
                }
                dataRows.add(rowData);
            } else {
                continue;
            }

        }
        return dataRows;
    }

    /**
     * Return list, in order, of column HeaderElements for a given worksheet. If requestedColumns is null, return all the columns up to the (optional)
     * max columns given in maxColumns, otherwise only return the requested ones.
     * 
     */
    private List<HeaderElement> getColumnHeaders(Workbook workbook, Worksheet sheet, String[] requestedColumns, Integer maxColumns) throws Exception {

        List<HeaderElement> colHeaders = new ArrayList<HeaderElement>();
        int cellCount = 0;

        Row headerRow = findHeaderRow(workbook, sheet);

        Iterator<Cell> cellItr = headerRow.getCellIterator();

        while (cellItr.hasNext()) {
            Cell cell = (Cell) cellItr.next();

            String header = cell.getStringValue();
            int columnNumber = cell.getColumnIndex();
            if (ArrayUtils.isEmpty(requestedColumns)) {
                if (maxColumns != null) {
                    if (cellCount <= maxColumns) {
                        HeaderElement hdr = new HeaderElement(header, columnNumber);
                        colHeaders.add(hdr);
                        cellCount++;
                    }
                } else {
                    HeaderElement hdr = new HeaderElement(header, columnNumber);
                    colHeaders.add(hdr);
                }
            } else {
                if (ArrayUtils.contains(requestedColumns, header)) {
                    HeaderElement hdr = new HeaderElement(header, columnNumber);
                    colHeaders.add(hdr);
                }
            }

        }
        return colHeaders;
    }

    /**
     * Get first row, treat as header row
     * 
     * @param workbook
     * @param sheet
     * @return
     */
    private Row findHeaderRow(Workbook workbook, Worksheet sheet) {

        Cells cells = sheet.getCells();
        Rows rows = cells.getRows();
        Row row = rows.getRow(0);

        return row;
    }

    /**
     * Returns true unless first cell is null or starts with # sign.
     * 
     * @param row
     * @return
     */
    private boolean isDataRow(Workbook workbook, Row row) {
        Cell firstCell = row.getCell(0);
        int cellType = firstCell.getValueType();
        boolean isData;

        switch (cellType) {
        case CellValueType.NULL:
            isData = false;
            break;
        case CellValueType.STRING:
            String cellValue = (String) firstCell.getValue();
            if (StringUtils.isBlank(cellValue)) {
                isData = false;
            } else if (cellValue.startsWith("#")) {
                isData = false;
            } else {
                isData = true;
            }
            break;
        default:
            isData = true;
            break;
        }

        return isData;
    }

    private Object getCellValue(final Cell cell) {

        Object returnValue = null;

        int cellType = cell.getValueType();

        switch (cellType) {
        case CellValueType.NULL:
            returnValue = "";
            break;
        case CellValueType.BOOLEAN:
            returnValue = String.valueOf(cell.getValue());
            break;
        case CellValueType.DATETIME:
            returnValue = cell.getDateTimeValue().toString();
            break;
        case CellValueType.STRING:
            returnValue = cell.getStringValue();
            break;
        case CellValueType.INT:
            returnValue = String.valueOf(cell.getIntValue());
            break;
            
        case CellValueType.DOUBLE:
            BigDecimal number = new BigDecimal(cell.getDoubleValue());
            if (number.scale() <= 0) {
                returnValue = number.toBigInteger().toString();
            } else {
                returnValue = number.toPlainString();
            }
            break;
            
        case CellValueType.RICH_TEXT_STRING:
            returnValue = cell.getValue();
            break;
        default:
            returnValue = cell.getValue().toString();
            break;
        }

        return returnValue;

    }

    private class HeaderElement {

        HeaderElement(String title, Integer columnIndex) {
            this.title = title;
            this.columnIndex = columnIndex;
        }

        String title;

        Integer columnIndex;
    }

}
